(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["main"],{

/***/ "./src/$$_lazy_route_resource lazy recursive":
/*!**********************************************************!*\
  !*** ./src/$$_lazy_route_resource lazy namespace object ***!
  \**********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

function webpackEmptyAsyncContext(req) {
	// Here Promise.resolve().then() is used instead of new Promise() to prevent
	// uncaught exception popping up in devtools
	return Promise.resolve().then(function() {
		var e = new Error("Cannot find module '" + req + "'");
		e.code = 'MODULE_NOT_FOUND';
		throw e;
	});
}
webpackEmptyAsyncContext.keys = function() { return []; };
webpackEmptyAsyncContext.resolve = webpackEmptyAsyncContext;
module.exports = webpackEmptyAsyncContext;
webpackEmptyAsyncContext.id = "./src/$$_lazy_route_resource lazy recursive";

/***/ }),

/***/ "./src/app/common/index.ts":
/*!*********************************!*\
  !*** ./src/app/common/index.ts ***!
  \*********************************/
/*! exports provided: Config, RouterModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _utils_index__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./utils/index */ "./src/app/common/utils/index.ts");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "Config", function() { return _utils_index__WEBPACK_IMPORTED_MODULE_0__["Config"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "RouterModule", function() { return _utils_index__WEBPACK_IMPORTED_MODULE_0__["RouterModule"]; });




/***/ }),

/***/ "./src/app/common/utils/Config.ts":
/*!****************************************!*\
  !*** ./src/app/common/utils/Config.ts ***!
  \****************************************/
/*! exports provided: Config */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Config", function() { return Config; });
class Config {
    static get IS_WEB() {
        return Config.PLATFORM_TARGET === Config.PLATFORMS.WEB;
    }
    static get IS_MOBILE_NATIVE() {
        return Config.PLATFORM_TARGET === Config.PLATFORMS.MOBILE_NATIVE;
    }
    static get APP_VERSION() {
        return '1.19.10.28a';
    }
}
// supported platforms
Config.PLATFORMS = {
    WEB: 'web',
    MOBILE_NATIVE: 'mobile_native'
};
// current target (defaults to web)
Config.PLATFORM_TARGET = Config.PLATFORMS.WEB;


/***/ }),

/***/ "./src/app/common/utils/index.ts":
/*!***************************************!*\
  !*** ./src/app/common/utils/index.ts ***!
  \***************************************/
/*! exports provided: Config, RouterModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _Config__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./Config */ "./src/app/common/utils/Config.ts");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "Config", function() { return _Config__WEBPACK_IMPORTED_MODULE_0__["Config"]; });

/* harmony import */ var _router_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./router-module */ "./src/app/common/utils/router-module.ts");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "RouterModule", function() { return _router_module__WEBPACK_IMPORTED_MODULE_1__["RouterModule"]; });





/***/ }),

/***/ "./src/app/common/utils/router-module.ts":
/*!***********************************************!*\
  !*** ./src/app/common/utils/router-module.ts ***!
  \***********************************************/
/*! exports provided: RouterModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "RouterModule", function() { return _angular_router__WEBPACK_IMPORTED_MODULE_0__["RouterModule"]; });




/***/ }),

/***/ "./src/app/fourDAdmin.web.module.ts":
/*!******************************************!*\
  !*** ./src/app/fourDAdmin.web.module.ts ***!
  \******************************************/
/*! exports provided: WebModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "WebModule", function() { return WebModule; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/platform-browser */ "./node_modules/@angular/platform-browser/__ivy_ngcc__/fesm2015/platform-browser.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/http.js");
/* harmony import */ var _fourDAdmin_fourDAdmin_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./fourDAdmin/fourDAdmin.component */ "./src/app/fourDAdmin/fourDAdmin.component.ts");
/* harmony import */ var _fourDAdmin_blankPage__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./fourDAdmin/blankPage */ "./src/app/fourDAdmin/blankPage.ts");
/* harmony import */ var _login_login_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./login/login.component */ "./src/app/login/login.component.ts");
/* harmony import */ var js44d__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! js44d */ "./node_modules/js44d/__ivy_ngcc__/fesm2015/js44d.js");
// angular






// app


// applets


// feature modules



const routerModule = _angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forRoot(_fourDAdmin_fourDAdmin_component__WEBPACK_IMPORTED_MODULE_6__["routes"]);
class WebModule {
}
WebModule.ɵmod = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineNgModule"]({ type: WebModule, bootstrap: [_fourDAdmin_fourDAdmin_component__WEBPACK_IMPORTED_MODULE_6__["FourDAdminComponent"]] });
WebModule.ɵinj = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineInjector"]({ factory: function WebModule_Factory(t) { return new (t || WebModule)(); }, imports: [[
            _angular_platform_browser__WEBPACK_IMPORTED_MODULE_1__["BrowserModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _angular_common__WEBPACK_IMPORTED_MODULE_4__["CommonModule"],
            _angular_common_http__WEBPACK_IMPORTED_MODULE_5__["HttpClientModule"],
            routerModule,
            js44d__WEBPACK_IMPORTED_MODULE_9__["FourDModule"], js44d__WEBPACK_IMPORTED_MODULE_9__["JS44DModule"], js44d__WEBPACK_IMPORTED_MODULE_9__["ModalModule"]
        ],
        js44d__WEBPACK_IMPORTED_MODULE_9__["FourDModule"], js44d__WEBPACK_IMPORTED_MODULE_9__["JS44DModule"], js44d__WEBPACK_IMPORTED_MODULE_9__["ModalModule"]] });
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵsetNgModuleScope"](WebModule, { declarations: [_fourDAdmin_fourDAdmin_component__WEBPACK_IMPORTED_MODULE_6__["FourDAdminComponent"], _fourDAdmin_blankPage__WEBPACK_IMPORTED_MODULE_7__["BlankPage"], _login_login_component__WEBPACK_IMPORTED_MODULE_8__["LoginComponent"]], imports: [_angular_platform_browser__WEBPACK_IMPORTED_MODULE_1__["BrowserModule"],
        _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
        _angular_common__WEBPACK_IMPORTED_MODULE_4__["CommonModule"],
        _angular_common_http__WEBPACK_IMPORTED_MODULE_5__["HttpClientModule"], _angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"], js44d__WEBPACK_IMPORTED_MODULE_9__["FourDModule"], js44d__WEBPACK_IMPORTED_MODULE_9__["JS44DModule"], js44d__WEBPACK_IMPORTED_MODULE_9__["ModalModule"]], exports: [js44d__WEBPACK_IMPORTED_MODULE_9__["FourDModule"], js44d__WEBPACK_IMPORTED_MODULE_9__["JS44DModule"], js44d__WEBPACK_IMPORTED_MODULE_9__["ModalModule"]] }); })();
/*@__PURE__*/ (function () { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](WebModule, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["NgModule"],
        args: [{
                imports: [
                    _angular_platform_browser__WEBPACK_IMPORTED_MODULE_1__["BrowserModule"],
                    _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
                    _angular_common__WEBPACK_IMPORTED_MODULE_4__["CommonModule"],
                    _angular_common_http__WEBPACK_IMPORTED_MODULE_5__["HttpClientModule"],
                    routerModule,
                    js44d__WEBPACK_IMPORTED_MODULE_9__["FourDModule"], js44d__WEBPACK_IMPORTED_MODULE_9__["JS44DModule"], js44d__WEBPACK_IMPORTED_MODULE_9__["ModalModule"]
                ],
                declarations: [_fourDAdmin_fourDAdmin_component__WEBPACK_IMPORTED_MODULE_6__["FourDAdminComponent"], _fourDAdmin_blankPage__WEBPACK_IMPORTED_MODULE_7__["BlankPage"], _login_login_component__WEBPACK_IMPORTED_MODULE_8__["LoginComponent"]
                ],
                exports: [js44d__WEBPACK_IMPORTED_MODULE_9__["FourDModule"], js44d__WEBPACK_IMPORTED_MODULE_9__["JS44DModule"], js44d__WEBPACK_IMPORTED_MODULE_9__["ModalModule"]],
                entryComponents: [_login_login_component__WEBPACK_IMPORTED_MODULE_8__["LoginComponent"]],
                bootstrap: [_fourDAdmin_fourDAdmin_component__WEBPACK_IMPORTED_MODULE_6__["FourDAdminComponent"]]
            }]
    }], null, null); })();


/***/ }),

/***/ "./src/app/fourDAdmin/blankPage.ts":
/*!*****************************************!*\
  !*** ./src/app/fourDAdmin/blankPage.ts ***!
  \*****************************************/
/*! exports provided: BlankPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "BlankPage", function() { return BlankPage; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");


class BlankPage {
}
BlankPage.ɵfac = function BlankPage_Factory(t) { return new (t || BlankPage)(); };
BlankPage.ɵcmp = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({ type: BlankPage, selectors: [["sd-blank"]], decls: 1, vars: 0, template: function BlankPage_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](0, "div");
    } }, encapsulation: 2 });
/*@__PURE__*/ (function () { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](BlankPage, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"],
        args: [{
                moduleId: module.i,
                selector: 'sd-blank',
                template: '<div></div>'
            }]
    }], null, null); })();


/***/ }),

/***/ "./src/app/fourDAdmin/fourDAdmin.component.ts":
/*!****************************************************!*\
  !*** ./src/app/fourDAdmin/fourDAdmin.component.ts ***!
  \****************************************************/
/*! exports provided: routes, FourDAdminComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "routes", function() { return routes; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "FourDAdminComponent", function() { return FourDAdminComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _common_index__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../common/index */ "./src/app/common/index.ts");
/* harmony import */ var _login_login_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../login/login.component */ "./src/app/login/login.component.ts");
/* harmony import */ var js44d__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! js44d */ "./node_modules/js44d/__ivy_ngcc__/fesm2015/js44d.js");
/* harmony import */ var _blankPage__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./blankPage */ "./src/app/fourDAdmin/blankPage.ts");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");











function FourDAdminComponent_a_8_Template(rf, ctx) { if (rf & 1) {
    const _r95 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "a", 9);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function FourDAdminComponent_a_8_Template_a_click_0_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r95); const menuItem_r93 = ctx.$implicit; const ctx_r94 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](); return ctx_r94.openApp(menuItem_r93); });
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} if (rf & 2) {
    const menuItem_r93 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](menuItem_r93.title);
} }
const routes = [
    { path: 'login', component: _blankPage__WEBPACK_IMPORTED_MODULE_5__["BlankPage"] },
    { path: 'browseTable', loadChildren: () => __webpack_require__.e(/*! import() | app-browseTable-browseTable-module */ "app-browseTable-browseTable-module").then(__webpack_require__.bind(null, /*! app/browseTable/browseTable.module */ "./src/app/browseTable/browseTable.module.ts")).then(m => m.BrowseTableModule) },
    { path: 'listEditor', loadChildren: () => __webpack_require__.e(/*! import() | app-listEditor-listEditor-module */ "app-listEditor-listEditor-module").then(__webpack_require__.bind(null, /*! app/listEditor/listEditor.module */ "./src/app/listEditor/listEditor.module.ts")).then(m => m.ListEditorModule) },
    { path: '**', component: _blankPage__WEBPACK_IMPORTED_MODULE_5__["BlankPage"] }
];
class FourDAdminComponent {
    constructor(router, modal, viewref) {
        this.router = router;
        this.modal = modal;
        this.viewref = viewref;
        this.menuList = [
            {
                routePath: '/browseTable',
                title: 'Browse Table'
            },
            {
                routePath: '/listEditor',
                title: 'List Editor'
            },
        ];
        if (window.location.hostname === 'localhost' && window.location.port === '4200') {
            js44d__WEBPACK_IMPORTED_MODULE_4__["FourDInterface"].fourDUrl = 'http://bestportal.simple-url.com:8181';
            // FourDInterface.fourDUrl = 'http://localhost:8080';
            // FourDInterface.fourDUrl = 'http://10.211.55.8:8181';
        }
        else {
            js44d__WEBPACK_IMPORTED_MODULE_4__["FourDInterface"].fourDUrl = window.location.origin;
        }
        js44d__WEBPACK_IMPORTED_MODULE_4__["Modal"].hostViewRef = this.viewref;
    }
    get currentUser() {
        return (js44d__WEBPACK_IMPORTED_MODULE_4__["FourDInterface"].authentication) ? js44d__WEBPACK_IMPORTED_MODULE_4__["FourDInterface"].currentUser : '?';
    }
    ngAfterContentInit() {
        // no predefined user, login...
        if (_common_index__WEBPACK_IMPORTED_MODULE_2__["Config"].PLATFORM_TARGET === _common_index__WEBPACK_IMPORTED_MODULE_2__["Config"].PLATFORMS.WEB) {
            this.showLoginDialog();
        }
    }
    userHasLoggedIn() {
        // load current profile user functions
        if (this.userIsLoggedIn) {
            js44d__WEBPACK_IMPORTED_MODULE_4__["FourDInterface"].runningInsideWorkspace = true; // we are indeed running inside the workspace
        }
    }
    get userIsLoggedIn() { return js44d__WEBPACK_IMPORTED_MODULE_4__["FourDInterface"].authentication !== undefined && js44d__WEBPACK_IMPORTED_MODULE_4__["FourDInterface"].authentication !== null; }
    doLogin() {
        js44d__WEBPACK_IMPORTED_MODULE_4__["FourDInterface"].authentication = null;
        this.router.navigate(['/login'], { skipLocationChange: true });
        if (_common_index__WEBPACK_IMPORTED_MODULE_2__["Config"].PLATFORM_TARGET === _common_index__WEBPACK_IMPORTED_MODULE_2__["Config"].PLATFORMS.WEB) {
            this.showLoginDialog();
        }
    }
    showLoginDialog() {
        this.modal.openInside(_login_login_component__WEBPACK_IMPORTED_MODULE_3__["LoginComponent"], this.viewref, null, _login_login_component__WEBPACK_IMPORTED_MODULE_3__["LoginComponent"]['dialogConfig'])
            .then((result) => {
            this.userHasLoggedIn();
        });
    }
    openApp(menu) {
        if (js44d__WEBPACK_IMPORTED_MODULE_4__["FourDInterface"].authentication) {
            this.router.navigate([menu.routePath], { skipLocationChange: true });
        }
    }
}
FourDAdminComponent.ɵfac = function FourDAdminComponent_Factory(t) { return new (t || FourDAdminComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_1__["Router"]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](js44d__WEBPACK_IMPORTED_MODULE_4__["Modal"]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_0__["ViewContainerRef"])); };
FourDAdminComponent.ɵcmp = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({ type: FourDAdminComponent, selectors: [["sd-fourdadmin"]], features: [_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵProvidersFeature"]([js44d__WEBPACK_IMPORTED_MODULE_4__["Modal"], js44d__WEBPACK_IMPORTED_MODULE_4__["FourDInterface"]])], decls: 12, vars: 3, consts: [["platform", ""], [3, "hidden"], [2, "height", "100px"], ["src", "./assets/icons/LogoPascal.png", 2, "display", "inline-block", "vertical-align", "top", "margin-right", "20px", "height", "100%"], [2, "display", "inline-block", "padding-left", "40px", "height", "100%"], [1, "fieldPromptBold", 2, "font-size", "32pt"], [2, "margin", "-5px"], [3, "click", 4, "ngFor", "ngForOf"], [2, "padding-left", "50px", 3, "click"], [3, "click"]], template: function FourDAdminComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "header", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](2, "div", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](3, "img", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](4, "span", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](5, "label", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](6);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](7, "nav", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](8, FourDAdminComponent_a_8_Template, 2, 1, "a", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](9, "a", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function FourDAdminComponent_Template_a_click_9_listener() { return ctx.doLogin(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](10, "Logout");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](11, "router-outlet");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("hidden", !ctx.userIsLoggedIn);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate1"]("Welcome ", ctx.currentUser, "");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngForOf", ctx.menuList);
    } }, directives: [_angular_common__WEBPACK_IMPORTED_MODULE_6__["NgForOf"], _angular_router__WEBPACK_IMPORTED_MODULE_1__["RouterOutlet"]], styles: ["nav[_ngcontent-%COMP%]   a[_ngcontent-%COMP%] {\n  color: #106cc8;\n  font-size: 14px;\n  font-weight: 500;\n  line-height: 48px;\n  margin-right: 20px;\n  text-decoration: none;\n  vertical-align: middle;\n}\n\nnav[_ngcontent-%COMP%]   a[_ngcontent-%COMP%]:hover, nav[_ngcontent-%COMP%]   a[_ngcontent-%COMP%]:focus {\n    color: #23527c;\n    font-size: 15px;\n    font-weight: 900;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvZm91ckRBZG1pbi9mb3VyREFkbWluLmNvbXBvbmVudC5jc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSxjQUFjO0VBQ2QsZUFBZTtFQUNmLGdCQUFnQjtFQUNoQixpQkFBaUI7RUFDakIsa0JBQWtCO0VBQ2xCLHFCQUFxQjtFQUNyQixzQkFBc0I7QUFDeEI7O0FBRUE7O0lBRUksY0FBYztJQUNkLGVBQWU7SUFDZixnQkFBZ0I7QUFDcEIiLCJmaWxlIjoic3JjL2FwcC9mb3VyREFkbWluL2ZvdXJEQWRtaW4uY29tcG9uZW50LmNzcyIsInNvdXJjZXNDb250ZW50IjpbIm5hdiBhIHtcbiAgY29sb3I6ICMxMDZjYzg7XG4gIGZvbnQtc2l6ZTogMTRweDtcbiAgZm9udC13ZWlnaHQ6IDUwMDtcbiAgbGluZS1oZWlnaHQ6IDQ4cHg7XG4gIG1hcmdpbi1yaWdodDogMjBweDtcbiAgdGV4dC1kZWNvcmF0aW9uOiBub25lO1xuICB2ZXJ0aWNhbC1hbGlnbjogbWlkZGxlO1xufVxuXG5uYXYgYTpob3Zlcixcbm5hdiBhOmZvY3VzIHtcbiAgICBjb2xvcjogIzIzNTI3YztcbiAgICBmb250LXNpemU6IDE1cHg7XG4gICAgZm9udC13ZWlnaHQ6IDkwMDtcbn1cbiJdfQ== */"] });
/*@__PURE__*/ (function () { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](FourDAdminComponent, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"],
        args: [{
                moduleId: module.i,
                selector: 'sd-fourdadmin',
                providers: [js44d__WEBPACK_IMPORTED_MODULE_4__["Modal"], js44d__WEBPACK_IMPORTED_MODULE_4__["FourDInterface"]],
                templateUrl: 'fourDAdmin.component.html',
                styleUrls: ['fourDAdmin.component.css']
            }]
    }], function () { return [{ type: _angular_router__WEBPACK_IMPORTED_MODULE_1__["Router"] }, { type: js44d__WEBPACK_IMPORTED_MODULE_4__["Modal"] }, { type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["ViewContainerRef"] }]; }, null); })();


/***/ }),

/***/ "./src/app/login/login.component.ts":
/*!******************************************!*\
  !*** ./src/app/login/login.component.ts ***!
  \******************************************/
/*! exports provided: LoginComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LoginComponent", function() { return LoginComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _common_index__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../common/index */ "./src/app/common/index.ts");
/* harmony import */ var js44d__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! js44d */ "./node_modules/js44d/__ivy_ngcc__/fesm2015/js44d.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");







class LoginComponent {
    constructor(dialog, fourD) {
        this.dialog = dialog;
        this.fourD = fourD;
        this.username = '';
        this.password = '';
        this.showError = false;
        this.fourDVersion = '';
        this.webAppVersion = _common_index__WEBPACK_IMPORTED_MODULE_1__["Config"].APP_VERSION;
        this.fourD.call4DRESTMethod('REST_GetApplicationVersion', {}, { responseType: 'text' })
            .subscribe((v) => { this.fourDVersion = v; });
    }
    login() {
        const md5pwd = js44d__WEBPACK_IMPORTED_MODULE_2__["MD5"].md5(this.password);
        this.fourD.signIn(this.username, md5pwd.toUpperCase())
            .then((authentication) => {
            if (js44d__WEBPACK_IMPORTED_MODULE_2__["FourDInterface"].authentication) {
                this.showError = false;
                this.dialog.close('loggedin');
            }
            else {
                console.log('oops');
                this.showError = true;
            }
        })
            .catch((e) => {
            console.log(e);
            this.showError = true;
        });
    }
}
LoginComponent.dialogConfig = {
    size: 'sm',
    selfCentered: true,
    isResizable: false,
    isModal: true,
    isBlocking: true,
    title: 'Login',
    width: 1063, height: 667
};
LoginComponent.ɵfac = function LoginComponent_Factory(t) { return new (t || LoginComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](js44d__WEBPACK_IMPORTED_MODULE_2__["ModalDialogInstance"]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](js44d__WEBPACK_IMPORTED_MODULE_2__["FourDInterface"])); };
LoginComponent.ɵcmp = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({ type: LoginComponent, selectors: [["log-in"]], inputs: { username: "username", password: "password", showError: "showError", fourDVersion: "fourDVersion", webAppVersion: "webAppVersion" }, decls: 18, vars: 5, consts: [[1, "login", "container"], ["role", "form", 1, "form-vertical", 3, "submit"], [2, "padding-bottom", "40px", "font-size", "32pt", "font-weight", "bold", "color", "#7F7F6F"], [1, "form-group", 2, "margin-left", "20px"], ["for", "username", 1, "fieldPrompt", 2, "font-weight", "bold", "width", "90px"], ["type", "text", "id", "username", "name", "username", "placeholder", "Username", 1, "fieldEntry", 2, "width", "300px", 3, "ngModel", "ngModelChange", "focus"], ["for", "password", 1, "fieldPrompt", 2, "font-weight", "bold", "width", "90px"], ["type", "password", "id", "password", "name", "password", "placeholder", "Password", 1, "fieldEntry", 2, "width", "300px", 3, "ngModel", "ngModelChange"], ["type", "submit", 1, "regularButton", 2, "width", "100px", "margin-left", "30px"], [1, "alert", "alert-warning", 2, "width", "500px", 3, "hidden"], [2, "color", "green", "margin-top", "100px"]], template: function LoginComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "form", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("submit", function LoginComponent_Template_form_submit_1_listener() { return ctx.login(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](2, "label", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](3, "Welcome to FourD Admin");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](4, "div", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](5, "label", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](6, "User Name");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](7, "input", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("ngModelChange", function LoginComponent_Template_input_ngModelChange_7_listener($event) { return ctx.username = $event; })("focus", function LoginComponent_Template_input_focus_7_listener() { return ctx.showError = false; });
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](8, "div", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](9, "label", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](10, "Password");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](11, "input", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("ngModelChange", function LoginComponent_Template_input_ngModelChange_11_listener($event) { return ctx.password = $event; });
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](12, "button", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](13, "Login");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](14, "div", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](15, "Sorry, the username and/or password was incorrect");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](16, "div", 10);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](17);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](7);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngModel", ctx.username);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](4);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngModel", ctx.password);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("hidden", !ctx.showError);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate2"]("4D: ", ctx.fourDVersion, ", web: ", ctx.webAppVersion, "");
    } }, directives: [_angular_forms__WEBPACK_IMPORTED_MODULE_3__["ɵangular_packages_forms_forms_y"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["NgControlStatusGroup"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["NgForm"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["DefaultValueAccessor"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["NgControlStatus"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["NgModel"]], styles: [".login[_ngcontent-%COMP%] {\n    width: 1070px !important;\n    background: url('login_splash.png');\n    background-repeat: no-repeat;\n    height: 670px !important;\n    padding-left: 200px;\n    padding-top: 200px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvbG9naW4vbG9naW4uY29tcG9uZW50LmNzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtJQUNJLHdCQUF3QjtJQUN4QixtQ0FBc0Q7SUFDdEQsNEJBQTRCO0lBQzVCLHdCQUF3QjtJQUN4QixtQkFBbUI7SUFDbkIsa0JBQWtCO0FBQ3RCIiwiZmlsZSI6InNyYy9hcHAvbG9naW4vbG9naW4uY29tcG9uZW50LmNzcyIsInNvdXJjZXNDb250ZW50IjpbIi5sb2dpbiB7XG4gICAgd2lkdGg6IDEwNzBweCAhaW1wb3J0YW50O1xuICAgIGJhY2tncm91bmQ6IHVybChcIi4uLy4uL2Fzc2V0cy9pY29ucy9sb2dpbl9zcGxhc2gucG5nXCIpO1xuICAgIGJhY2tncm91bmQtcmVwZWF0OiBuby1yZXBlYXQ7XG4gICAgaGVpZ2h0OiA2NzBweCAhaW1wb3J0YW50O1xuICAgIHBhZGRpbmctbGVmdDogMjAwcHg7XG4gICAgcGFkZGluZy10b3A6IDIwMHB4O1xufVxuIl19 */"] });
/*@__PURE__*/ (function () { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](LoginComponent, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"],
        args: [{
                selector: 'log-in',
                moduleId: module.i,
                templateUrl: 'login.component.html',
                styleUrls: ['login.component.css']
            }]
    }], function () { return [{ type: js44d__WEBPACK_IMPORTED_MODULE_2__["ModalDialogInstance"] }, { type: js44d__WEBPACK_IMPORTED_MODULE_2__["FourDInterface"] }]; }, { username: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }], password: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }], showError: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }], fourDVersion: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }], webAppVersion: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }] }); })();


/***/ }),

/***/ "./src/environments/environment.ts":
/*!*****************************************!*\
  !*** ./src/environments/environment.ts ***!
  \*****************************************/
/*! exports provided: environment */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "environment", function() { return environment; });
// The file contents for the current environment will overwrite these during build.
// The build system defaults to the dev environment which uses `environment.ts`, but if you do
// `ng build --env=prod` then `environment.prod.ts` will be used instead.
// The list of which env maps to which file can be found in `.angular-cli.json`.
const environment = {
    production: false
};


/***/ }),

/***/ "./src/main.ts":
/*!*********************!*\
  !*** ./src/main.ts ***!
  \*********************/
/*! no exports provided */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./environments/environment */ "./src/environments/environment.ts");
/* harmony import */ var _app_fourDAdmin_web_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./app/fourDAdmin.web.module */ "./src/app/fourDAdmin.web.module.ts");
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/platform-browser */ "./node_modules/@angular/platform-browser/__ivy_ngcc__/fesm2015/platform-browser.js");




if (_environments_environment__WEBPACK_IMPORTED_MODULE_1__["environment"].production) {
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["enableProdMode"])();
}
_angular_platform_browser__WEBPACK_IMPORTED_MODULE_3__["platformBrowser"]().bootstrapModule(_app_fourDAdmin_web_module__WEBPACK_IMPORTED_MODULE_2__["WebModule"]);


/***/ }),

/***/ 0:
/*!***************************!*\
  !*** multi ./src/main.ts ***!
  \***************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(/*! /FourDAdmin/src/main.ts */"./src/main.ts");


/***/ })

},[[0,"runtime","vendor"]]]);
//# sourceMappingURL=main-es2015.js.map