(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["app-listEditor-listEditor-module"],{

/***/ "./src/app/listEditor/listEditor.component.ts":
/*!****************************************************!*\
  !*** ./src/app/listEditor/listEditor.component.ts ***!
  \****************************************************/
/*! exports provided: ListEditorComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ListEditorComponent", function() { return ListEditorComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var js44d__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! js44d */ "./node_modules/js44d/__ivy_ngcc__/fesm2015/js44d.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");






function ListEditorComponent_tr_10_Template(rf, ctx) { if (rf & 1) {
    const _r85 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "tr", 19);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function ListEditorComponent_tr_10_Template_tr_click_0_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r85); const list_r83 = ctx.$implicit; const ctx_r84 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](); return ctx_r84.selectList($event, list_r83); });
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "td", 20);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} if (rf & 2) {
    const list_r83 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](list_r83);
} }
function ListEditorComponent_tr_16_Template(rf, ctx) { if (rf & 1) {
    const _r88 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "tr", 21);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function ListEditorComponent_tr_16_Template_tr_click_0_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r88); const item_r86 = ctx.$implicit; const ctx_r87 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](); return ctx_r87.selectItem($event, item_r86); })("drop", function ListEditorComponent_tr_16_Template_tr_drop_0_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r88); const ctx_r89 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](); return ctx_r89.handleDrop($event); })("dragstart", function ListEditorComponent_tr_16_Template_tr_dragstart_0_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r88); const ctx_r90 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](); return ctx_r90.startDrag($event, "column"); })("dragleave", function ListEditorComponent_tr_16_Template_tr_dragleave_0_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r88); const ctx_r91 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](); return ctx_r91.disableDrop($event); });
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "td", 20);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} if (rf & 2) {
    const item_r86 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](item_r86);
} }
class ListEditorComponent {
    constructor(fourD /*, private logger: LogService*/) {
        this.fourD = fourD;
        this.listCount = 0;
        this.listNames = [];
        this.selectedListName = '';
        this.listItems = [];
        this.selectedItemIndex = -1;
        this.selectedItemValue = '';
    }
    ngAfterContentInit() {
        this.fourD.call4DRESTMethod('REST_GetListOf4DLists', {})
            .subscribe(resultJSON => {
            this.listCount = resultJSON.listCount;
            this.listNames = resultJSON.listNames;
        });
    }
    selectList(event, list) {
        if (this.selectedList) {
            this.selectedList.classList.remove('selectedItem');
        }
        if (this.selectedItem) {
            this.selectedItem.classList.remove('selectedItem');
            this.selectedItemValue = '';
            this.selectedItemIndex = -1;
        }
        this.selectedList = event.target;
        this.selectedListName = list;
        this.fourD.get4DList(this.selectedListName)
            .then((values) => {
            this.selectedList.classList.add('selectedItem');
            this.listItems = values;
            this.selectedItem = null;
            this.selectedItemIndex = -1;
        });
    }
    selectItem(event, item) {
        if (this.selectedItem) {
            this.selectedItem.classList.remove('selectedItem');
        }
        this.selectedItemValue = item;
        this.selectedItemIndex = event.currentTarget.rowIndex;
        this.selectedItem = event.target;
        this.selectedItem.classList.add('selectedItem');
    }
    addItem() {
        if (this.selectedItemValue !== '') {
            this.listItems.push(this.selectedItemValue);
            this.update4DList();
        }
    }
    changeItem() {
        if (this.selectedItemIndex >= 0) {
            this.listItems[this.selectedItemIndex] = this.selectedItemValue;
            this.update4DList();
        }
    }
    deleteItem() {
        if (this.selectedItemIndex >= 0) {
            this.listItems.splice(this.selectedItemIndex, 1);
            this.update4DList();
        }
    }
    update4DList() {
        this.fourD.update4DList(this.selectedListName, this.listItems);
    }
    startDrag(event, type) {
        event.effectAllowed = 'copy';
        event.dataTransfer.setData('row', event.currentTarget.rowIndex);
    }
    allowDrop(event) {
        if (event.preventDefault) {
            event.preventDefault();
        } // Necessary. Allows us to drop.
        if (event.stopPropagation) {
            event.stopPropagation();
        }
        if (event.type === 'dragenter') {
            event.target.classList.add('droppable');
            event.dataTransfer.dropEffect = 'copy'; // See the section on the DataTransfer object.
        }
        return false;
    }
    disableDrop(event) {
        if (event.stopPropagation) {
            event.stopPropagation();
        }
        event.target.classList.remove('droppable');
    }
    handleDrop(event) {
        if (event.stopPropagation) {
            event.stopPropagation();
        }
        this.disableDrop(event);
        const row = event.dataTransfer.getData('row');
        const moveToIndex = event.currentTarget.rowIndex;
        const item = this.listItems.splice(row, 1);
        if (row < moveToIndex) {
            // moving up...
            this.listItems.splice(event.currentTarget.rowIndex - 1, 0, item[0]);
        }
        else {
            // moving down
            this.listItems.splice(event.currentTarget.rowIndex, 0, item[0]);
        }
        this.update4DList();
    }
}
ListEditorComponent.dialogConfig = {
    actions: ['Maximize', 'Minimize', 'Close'], position: { top: 100, left: 150 }, selfCentered: true,
    title: '4D List Editor',
    isResizable: true,
    width: 1100, height: 510
};
ListEditorComponent.ɵfac = function ListEditorComponent_Factory(t) { return new (t || ListEditorComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](js44d__WEBPACK_IMPORTED_MODULE_1__["FourDInterface"])); };
ListEditorComponent.ɵcmp = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({ type: ListEditorComponent, selectors: [["list-editor"]], decls: 34, vars: 8, consts: [[2, "padding-left", "10px"], [1, "container-fluid", 2, "margin-left", "10px", "height", "calc(100% - 65px)"], [1, "row"], [1, "col-sm-2", 2, "border-style", "solid", "border-width", "thin", "padding-bottom", "4px"], [1, "listTable", 2, "height", "350px"], [1, "listBody"], [3, "click", 4, "ngFor", "ngForOf"], [1, "col-sm-3", 2, "border-style", "solid", "border-width", "thin", "padding-bottom", "4px"], [1, "listBody", 3, "dragenter", "dragover", "dragend", "dragleave", "drop"], ["draggable", "true", 3, "click", "drop", "dragstart", "dragleave", 4, "ngFor", "ngForOf"], [1, "col-sm-5", 2, "border-style", "solid", "border-width", "thin", "padding-bottom", "4px", 3, "hidden"], [1, "form-horizontal", "listTable", 2, "height", "348px"], [1, "form-group", 2, "padding-top", "10px"], ["for", "field", 1, "control-label", "col-sm-2"], [1, "col-sm-6"], ["name", "listitem", "type", "text", 1, "form-control", 3, "ngModel", "ngModelChange"], [1, "form-group"], [1, "col-sm-offset-2", "col-sm-10"], [1, "regularButton", 2, "width", "70px", "padding-right", "5px", 3, "disabled", "click"], [3, "click"], [1, "listItem"], ["draggable", "true", 3, "click", "drop", "dragstart", "dragleave"]], template: function ListEditorComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "web-application");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "h2", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](2, "List Editor");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](3, "div", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](4, "div", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](5, "div", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](6, "h4");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](7, "Select List");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](8, "table", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](9, "tbody", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](10, ListEditorComponent_tr_10_Template, 3, 1, "tr", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](11, "div", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](12, "h4");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](13);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](14, "table", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](15, "tbody", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("dragenter", function ListEditorComponent_Template_tbody_dragenter_15_listener($event) { return ctx.allowDrop($event); })("dragover", function ListEditorComponent_Template_tbody_dragover_15_listener($event) { return ctx.allowDrop($event); })("dragend", function ListEditorComponent_Template_tbody_dragend_15_listener($event) { return ctx.disableDrop($event); })("dragleave", function ListEditorComponent_Template_tbody_dragleave_15_listener($event) { return ctx.disableDrop($event); })("drop", function ListEditorComponent_Template_tbody_drop_15_listener($event) { return ctx.handleDrop($event); });
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](16, ListEditorComponent_tr_16_Template, 3, 1, "tr", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](17, "div", 10);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](18, "h4");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](19, "List Item Info");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](20, "form", 11);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](21, "div", 12);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](22, "label", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](23, "List Item Value:");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](24, "div", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](25, "input", 15);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("ngModelChange", function ListEditorComponent_Template_input_ngModelChange_25_listener($event) { return ctx.selectedItemValue = $event; });
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](26, "div", 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](27, "div", 17);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](28, "button", 18);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function ListEditorComponent_Template_button_click_28_listener() { return ctx.addItem(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](29, "Add");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](30, "button", 18);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function ListEditorComponent_Template_button_click_30_listener() { return ctx.changeItem(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](31, "Change");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](32, "button", 18);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function ListEditorComponent_Template_button_click_32_listener() { return ctx.deleteItem(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](33, "Delete");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](10);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngForOf", ctx.listNames);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate1"]("", ctx.selectedListName, " items");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngForOf", ctx.listItems);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("hidden", !ctx.selectedList);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](8);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngModel", ctx.selectedItemValue);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("disabled", ctx.selectedItemValue === "");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("disabled", !ctx.selectedItem);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("disabled", !ctx.selectedItem);
    } }, directives: [js44d__WEBPACK_IMPORTED_MODULE_1__["WebAppContainer"], _angular_common__WEBPACK_IMPORTED_MODULE_2__["NgForOf"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["ɵangular_packages_forms_forms_y"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["NgControlStatusGroup"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["NgForm"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["DefaultValueAccessor"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["NgControlStatus"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["NgModel"]], styles: [".listTable[_ngcontent-%COMP%] {\n    border: 1px solid black;\n    border-collapse: collapse;\n    width: 100%;\n    height: 250px;;\n}\n\n.listBody[_ngcontent-%COMP%] {\n    overflow: auto;\n    display: block;\n    height: 100%;\n}\n\n.listItem[_ngcontent-%COMP%] {\n    padding-left: 3px;\n    border-style: none;\n}\n\n.selectedItem[_ngcontent-%COMP%] {\n    background: brown;\n    color: white;\n}\n\n.droppable[_ngcontent-%COMP%] {\n    border: 2px dashed gray;\n}\n\n\n\nul#navigation[_ngcontent-%COMP%] {\n    margin:0px auto;\n    position:relative;\n    float:left;\n}\n\nul#navigation[_ngcontent-%COMP%]   li[_ngcontent-%COMP%] {\n    display:inline;\n    float:left;\n\n}\n\nul#navigation[_ngcontent-%COMP%]   li[_ngcontent-%COMP%]   h5[_ngcontent-%COMP%] {\n    padding:5px 5px 5px 15px;\n    display:inline-block;\n    margin: 5px 0 0 0;\n    width: 100%;\n}\n\nul#navigation[_ngcontent-%COMP%]   li[_ngcontent-%COMP%]   h5[_ngcontent-%COMP%]:hover {\n    background:#f8f8f8;\n    color:#282828;\n}\n\nul#navigation[_ngcontent-%COMP%]   li[_ngcontent-%COMP%]:hover    > a[_ngcontent-%COMP%] {\n    background:#fff;\n}\n\n\n\nul#navigation[_ngcontent-%COMP%]   li[_ngcontent-%COMP%]:hover    > ul[_ngcontent-%COMP%]\n{\n\n    visibility:visible;\n    opacity:1;\n}\n\nul#navigation[_ngcontent-%COMP%]   ul[_ngcontent-%COMP%], ul#navigation[_ngcontent-%COMP%]   ul[_ngcontent-%COMP%]   li[_ngcontent-%COMP%]   ul[_ngcontent-%COMP%] {\n    list-style: none;\n    margin-left: 10px;\n    padding: 0;\n\n    visibility:hidden;\n    opacity:0;\n    position: absolute;\n    z-index: 99999;\n    width:180px;\n    background:#ddd;\n    box-shadow:1px 1px 3px #ccc;\n\n    transition:opacity 0.2s linear, visibility 0.2s linear;\n}\n\nul#navigation[_ngcontent-%COMP%]   ul[_ngcontent-%COMP%] {\n    top: 25px;\n    left: 10px;\n}\n\nul#navigation[_ngcontent-%COMP%]   ul[_ngcontent-%COMP%]   li[_ngcontent-%COMP%]   ul[_ngcontent-%COMP%] {\n    top: 0;\n    left: 181px; \n}\n\nul#navigation[_ngcontent-%COMP%]   ul[_ngcontent-%COMP%]   li[_ngcontent-%COMP%] {\n    clear:both;\n    width:100%;\n    border:0 none;\n    border-bottom:1px solid #c9c9c9;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvbGlzdEVkaXRvci9saXN0RWRpdG9yLmNvbXBvbmVudC5jc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7SUFDSSx1QkFBdUI7SUFDdkIseUJBQXlCO0lBQ3pCLFdBQVc7SUFDWCxhQUFhO0FBQ2pCOztBQUVBO0lBQ0ksY0FBYztJQUNkLGNBQWM7SUFDZCxZQUFZO0FBQ2hCOztBQUVBO0lBQ0ksaUJBQWlCO0lBQ2pCLGtCQUFrQjtBQUN0Qjs7QUFFQTtJQUNJLGlCQUFpQjtJQUNqQixZQUFZO0FBQ2hCOztBQUVBO0lBQ0ksdUJBQXVCO0FBQzNCOztBQUVBLG9CQUFvQjs7QUFHcEI7SUFDSSxlQUFlO0lBQ2YsaUJBQWlCO0lBQ2pCLFVBQVU7QUFDZDs7QUFFQTtJQUNJLGNBQWM7SUFDZCxVQUFVOztBQUVkOztBQUVBO0lBQ0ksd0JBQXdCO0lBQ3hCLG9CQUFvQjtJQUNwQixpQkFBaUI7SUFDakIsV0FBVztBQUNmOztBQUVBO0lBQ0ksa0JBQWtCO0lBQ2xCLGFBQWE7QUFDakI7O0FBSUE7SUFDSSxlQUFlO0FBQ25COztBQUNBLHlCQUF5Qjs7QUFDekI7O0FBRUE7NERBQzREO0lBQ3hELGtCQUFrQjtJQUNsQixTQUFTO0FBQ2I7O0FBRUE7SUFDSSxnQkFBZ0I7SUFDaEIsaUJBQWlCO0lBQ2pCLFVBQVU7QUFDZDt3REFDd0Q7SUFDcEQsaUJBQWlCO0lBQ2pCLFNBQVM7SUFDVCxrQkFBa0I7SUFDbEIsY0FBYztJQUNkLFdBQVc7SUFDWCxlQUFlO0lBQ2YsMkJBQTJCO0FBQy9CLDZDQUE2QztJQUl6QyxzREFBc0Q7QUFDMUQ7O0FBRUE7SUFDSSxTQUFTO0lBQ1QsVUFBVTtBQUNkOztBQUVBO0lBQ0ksTUFBTTtJQUNOLFdBQVcsRUFBRSw4Q0FBOEM7QUFDL0Q7O0FBRUE7SUFDSSxVQUFVO0lBQ1YsVUFBVTtJQUNWLGFBQWE7SUFDYiwrQkFBK0I7QUFDbkMiLCJmaWxlIjoic3JjL2FwcC9saXN0RWRpdG9yL2xpc3RFZGl0b3IuY29tcG9uZW50LmNzcyIsInNvdXJjZXNDb250ZW50IjpbIi5saXN0VGFibGUge1xuICAgIGJvcmRlcjogMXB4IHNvbGlkIGJsYWNrO1xuICAgIGJvcmRlci1jb2xsYXBzZTogY29sbGFwc2U7XG4gICAgd2lkdGg6IDEwMCU7XG4gICAgaGVpZ2h0OiAyNTBweDs7XG59XG5cbi5saXN0Qm9keSB7XG4gICAgb3ZlcmZsb3c6IGF1dG87XG4gICAgZGlzcGxheTogYmxvY2s7XG4gICAgaGVpZ2h0OiAxMDAlO1xufVxuXG4ubGlzdEl0ZW0ge1xuICAgIHBhZGRpbmctbGVmdDogM3B4O1xuICAgIGJvcmRlci1zdHlsZTogbm9uZTtcbn1cblxuLnNlbGVjdGVkSXRlbSB7XG4gICAgYmFja2dyb3VuZDogYnJvd247XG4gICAgY29sb3I6IHdoaXRlO1xufVxuXG4uZHJvcHBhYmxlIHtcbiAgICBib3JkZXI6IDJweCBkYXNoZWQgZ3JheTtcbn1cblxuLyogTWFpbiBOYXZpZ2F0aW9uICovXG5cbiBcbnVsI25hdmlnYXRpb24ge1xuICAgIG1hcmdpbjowcHggYXV0bztcbiAgICBwb3NpdGlvbjpyZWxhdGl2ZTtcbiAgICBmbG9hdDpsZWZ0O1xufVxuIFxudWwjbmF2aWdhdGlvbiBsaSB7XG4gICAgZGlzcGxheTppbmxpbmU7XG4gICAgZmxvYXQ6bGVmdDtcblxufVxuIFxudWwjbmF2aWdhdGlvbiBsaSBoNSB7XG4gICAgcGFkZGluZzo1cHggNXB4IDVweCAxNXB4O1xuICAgIGRpc3BsYXk6aW5saW5lLWJsb2NrO1xuICAgIG1hcmdpbjogNXB4IDAgMCAwO1xuICAgIHdpZHRoOiAxMDAlO1xufVxuIFxudWwjbmF2aWdhdGlvbiBsaSBoNTpob3ZlciB7XG4gICAgYmFja2dyb3VuZDojZjhmOGY4O1xuICAgIGNvbG9yOiMyODI4Mjg7XG59XG4gXG5cbiBcbnVsI25hdmlnYXRpb24gbGk6aG92ZXIgPiBhIHtcbiAgICBiYWNrZ3JvdW5kOiNmZmY7XG59XG4vKiBEcm9wLURvd24gTmF2aWdhdGlvbiAqL1xudWwjbmF2aWdhdGlvbiBsaTpob3ZlciA+IHVsXG57XG4vKnRoZXNlIDIgc3R5bGVzIGFyZSB2ZXJ5IGltcG9ydGFudCxcbmJlaW5nIHRoZSBvbmVzIHdoaWNoIG1ha2UgdGhlIGRyb3AtZG93biB0byBhcHBlYXIgb24gaG92ZXIgKi9cbiAgICB2aXNpYmlsaXR5OnZpc2libGU7XG4gICAgb3BhY2l0eToxO1xufVxuIFxudWwjbmF2aWdhdGlvbiB1bCwgdWwjbmF2aWdhdGlvbiB1bCBsaSB1bCB7XG4gICAgbGlzdC1zdHlsZTogbm9uZTtcbiAgICBtYXJnaW4tbGVmdDogMTBweDtcbiAgICBwYWRkaW5nOiAwO1xuLyp0aGUgbmV4dCAyIHN0eWxlcyBhcmUgdmVyeSBpbXBvcnRhbnQsXG5iZWluZyB0aGUgb25lcyB3aGljaCBtYWtlIHRoZSBkcm9wLWRvd24gdG8gc3RheSBoaWRkZW4gKi9cbiAgICB2aXNpYmlsaXR5OmhpZGRlbjtcbiAgICBvcGFjaXR5OjA7XG4gICAgcG9zaXRpb246IGFic29sdXRlO1xuICAgIHotaW5kZXg6IDk5OTk5O1xuICAgIHdpZHRoOjE4MHB4O1xuICAgIGJhY2tncm91bmQ6I2RkZDtcbiAgICBib3gtc2hhZG93OjFweCAxcHggM3B4ICNjY2M7XG4vKiBjc3MzIHRyYW5zaXRpb25zIGZvciBzbW9vdGggaG92ZXIgZWZmZWN0ICovXG4gICAgLXdlYmtpdC10cmFuc2l0aW9uOm9wYWNpdHkgMC4ycyBsaW5lYXIsIHZpc2liaWxpdHkgMC4ycyBsaW5lYXI7XG4gICAgLW1vei10cmFuc2l0aW9uOm9wYWNpdHkgMC4ycyBsaW5lYXIsIHZpc2liaWxpdHkgMC4ycyBsaW5lYXI7XG4gICAgLW8tdHJhbnNpdGlvbjpvcGFjaXR5IDAuMnMgbGluZWFyLCB2aXNpYmlsaXR5IDAuMnMgbGluZWFyO1xuICAgIHRyYW5zaXRpb246b3BhY2l0eSAwLjJzIGxpbmVhciwgdmlzaWJpbGl0eSAwLjJzIGxpbmVhcjtcbn1cbiBcbnVsI25hdmlnYXRpb24gdWwge1xuICAgIHRvcDogMjVweDtcbiAgICBsZWZ0OiAxMHB4O1xufVxuIFxudWwjbmF2aWdhdGlvbiB1bCBsaSB1bCB7XG4gICAgdG9wOiAwO1xuICAgIGxlZnQ6IDE4MXB4OyAvKiBzdHJvbmcgcmVsYXRlZCB0byB3aWR0aDoxODBweDsgZnJvbSBhYm92ZSAqL1xufVxuIFxudWwjbmF2aWdhdGlvbiB1bCBsaSB7XG4gICAgY2xlYXI6Ym90aDtcbiAgICB3aWR0aDoxMDAlO1xuICAgIGJvcmRlcjowIG5vbmU7XG4gICAgYm9yZGVyLWJvdHRvbToxcHggc29saWQgI2M5YzljOTtcbn1cbiJdfQ== */"] });
/*@__PURE__*/ (function () { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](ListEditorComponent, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"],
        args: [{
                moduleId: module.i,
                selector: 'list-editor',
                templateUrl: 'listEditor.component.html',
                styleUrls: ['listEditor.component.css']
            }]
    }], function () { return [{ type: js44d__WEBPACK_IMPORTED_MODULE_1__["FourDInterface"] }]; }, null); })();


/***/ }),

/***/ "./src/app/listEditor/listEditor.module.ts":
/*!*************************************************!*\
  !*** ./src/app/listEditor/listEditor.module.ts ***!
  \*************************************************/
/*! exports provided: ListEditorRoutes, ListEditorModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ListEditorRoutes", function() { return ListEditorRoutes; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ListEditorModule", function() { return ListEditorModule; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _listEditorDialog_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./listEditorDialog.component */ "./src/app/listEditor/listEditorDialog.component.ts");
/* harmony import */ var _listEditor_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./listEditor.component */ "./src/app/listEditor/listEditor.component.ts");
/* harmony import */ var js44d__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! js44d */ "./node_modules/js44d/__ivy_ngcc__/fesm2015/js44d.js");






// feature modules





const ListEditorRoutes = [
    {
        path: '',
        component: _listEditorDialog_component__WEBPACK_IMPORTED_MODULE_4__["ListEditorDialog"]
    }
];
class ListEditorModule {
}
ListEditorModule.ɵmod = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineNgModule"]({ type: ListEditorModule });
ListEditorModule.ɵinj = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineInjector"]({ factory: function ListEditorModule_Factory(t) { return new (t || ListEditorModule)(); }, imports: [[
            _angular_common__WEBPACK_IMPORTED_MODULE_1__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormsModule"],
            _angular_router__WEBPACK_IMPORTED_MODULE_3__["RouterModule"].forChild(ListEditorRoutes),
            js44d__WEBPACK_IMPORTED_MODULE_6__["FourDModule"], js44d__WEBPACK_IMPORTED_MODULE_6__["JS44DModule"], js44d__WEBPACK_IMPORTED_MODULE_6__["ModalModule"]
        ]] });
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵsetNgModuleScope"](ListEditorModule, { declarations: [_listEditorDialog_component__WEBPACK_IMPORTED_MODULE_4__["ListEditorDialog"], _listEditor_component__WEBPACK_IMPORTED_MODULE_5__["ListEditorComponent"]], imports: [_angular_common__WEBPACK_IMPORTED_MODULE_1__["CommonModule"],
        _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormsModule"], _angular_router__WEBPACK_IMPORTED_MODULE_3__["RouterModule"], js44d__WEBPACK_IMPORTED_MODULE_6__["FourDModule"], js44d__WEBPACK_IMPORTED_MODULE_6__["JS44DModule"], js44d__WEBPACK_IMPORTED_MODULE_6__["ModalModule"]] }); })();
/*@__PURE__*/ (function () { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](ListEditorModule, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["NgModule"],
        args: [{
                imports: [
                    _angular_common__WEBPACK_IMPORTED_MODULE_1__["CommonModule"],
                    _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormsModule"],
                    _angular_router__WEBPACK_IMPORTED_MODULE_3__["RouterModule"].forChild(ListEditorRoutes),
                    js44d__WEBPACK_IMPORTED_MODULE_6__["FourDModule"], js44d__WEBPACK_IMPORTED_MODULE_6__["JS44DModule"], js44d__WEBPACK_IMPORTED_MODULE_6__["ModalModule"]
                ],
                declarations: [_listEditorDialog_component__WEBPACK_IMPORTED_MODULE_4__["ListEditorDialog"], _listEditor_component__WEBPACK_IMPORTED_MODULE_5__["ListEditorComponent"]],
                entryComponents: [_listEditor_component__WEBPACK_IMPORTED_MODULE_5__["ListEditorComponent"]],
            }]
    }], null, null); })();


/***/ }),

/***/ "./src/app/listEditor/listEditorDialog.component.ts":
/*!**********************************************************!*\
  !*** ./src/app/listEditor/listEditorDialog.component.ts ***!
  \**********************************************************/
/*! exports provided: ListEditorDialog */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ListEditorDialog", function() { return ListEditorDialog; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var js44d__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! js44d */ "./node_modules/js44d/__ivy_ngcc__/fesm2015/js44d.js");
/* harmony import */ var _listEditor_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./listEditor.component */ "./src/app/listEditor/listEditor.component.ts");







class ListEditorDialog {
    constructor(modal, router, elementRef, viewRef) {
        this.modal = modal;
        this.router = router;
        this.elementRef = elementRef;
        this.viewRef = viewRef;
    }
    /**
     * AFter our view gets initialized, subscribe to various events on the Query band and the Grid
     */
    ngAfterContentInit() {
        this.router.navigate(['/blank'], { skipLocationChange: true });
        this.modal.openDialog(_listEditor_component__WEBPACK_IMPORTED_MODULE_3__["ListEditorComponent"], {}); // open edit dialog
    }
}
ListEditorDialog.ɵfac = function ListEditorDialog_Factory(t) { return new (t || ListEditorDialog)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](js44d__WEBPACK_IMPORTED_MODULE_2__["Modal"]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_1__["Router"]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_0__["ElementRef"]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_0__["ViewContainerRef"])); };
ListEditorDialog.ɵcmp = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({ type: ListEditorDialog, selectors: [["browse-table-dialog"]], features: [_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵProvidersFeature"]([js44d__WEBPACK_IMPORTED_MODULE_2__["Modal"]])], decls: 1, vars: 0, template: function ListEditorDialog_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](0, "div");
    } }, encapsulation: 2 });
/*@__PURE__*/ (function () { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](ListEditorDialog, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"],
        args: [{
                selector: 'browse-table-dialog',
                template: '<div></div>',
                providers: [js44d__WEBPACK_IMPORTED_MODULE_2__["Modal"]]
            }]
    }], function () { return [{ type: js44d__WEBPACK_IMPORTED_MODULE_2__["Modal"] }, { type: _angular_router__WEBPACK_IMPORTED_MODULE_1__["Router"] }, { type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["ElementRef"] }, { type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["ViewContainerRef"] }]; }, null); })();


/***/ })

}]);
//# sourceMappingURL=app-listEditor-listEditor-module-es2015.js.map