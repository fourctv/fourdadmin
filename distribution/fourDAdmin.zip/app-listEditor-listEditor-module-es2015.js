(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["app-listEditor-listEditor-module"],{

/***/ "./node_modules/raw-loader/index.js!./src/app/listEditor/listEditor.component.html":
/*!********************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/listEditor/listEditor.component.html ***!
  \********************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<web-application>\n    <h2 style=\"padding-left: 10px;\">List Editor</h2>\n\n    <div class=\"container-fluid\" style=\"margin-left:10px; height: calc(100% - 65px)\">\n        <div class=\"row\" >\n            <div class=\"col-sm-2\" style=\"border-style: solid; border-width: thin; padding-bottom: 4px;\">\n                <h4>Select List</h4>\n                <table  class=\"listTable\" style=\"height: 350px;\">\n                    <tbody class=\"listBody\">\n                        <tr *ngFor='let list of listNames' (click)=\"selectList($event,list)\">\n                            <td class=\"listItem\">{{list}}</td>\n                        </tr>\n                    </tbody>\n                </table>\n            </div>\n            <div class=\"col-sm-3\" style=\"border-style: solid; border-width: thin; padding-bottom: 4px;\">\n                <h4>{{selectedListName}} items</h4>\n                <table class=\"listTable\" style=\"height: 350px;\">\n                    <tbody class=\"listBody\" (dragenter)=\"allowDrop($event)\" (dragover)=\"allowDrop($event)\" (dragend)=\"disableDrop($event)\" (dragleave)=\"disableDrop($event)\" (drop)=\"handleDrop($event)\">\n                        <tr *ngFor='let item of listItems' (click)=\"selectItem($event,item)\" draggable=\"true\" (drop)=\"handleDrop($event)\" (dragstart)=\"startDrag($event,'column')\" (dragleave)=\"disableDrop($event)\">\n                            <td class=\"listItem\">{{item}}</td>\n                        </tr>\n                    </tbody>\n                </table>\n            </div>\n\n            <div class=\"col-sm-5\" style=\"border-style: solid; border-width: thin; padding-bottom: 4px;\" [hidden]=\"!selectedList\">\n                <h4>List Item Info</h4>\n                <form  class=\"form-horizontal listTable\" style=\"height: 348px;\">\n                    <div class=\"form-group\" style=\"padding-top: 10px;\">\n                        <label for=\"field\" class=\"control-label col-sm-2\">List Item Value:</label>\n                        <div class=\"col-sm-6\">\n                            <input name=\"listitem\" type=\"text\" class=\"form-control\" [(ngModel)]=\"selectedItemValue\">\n                        </div>\n                    </div>\n \n                     <div class=\"form-group\"> \n                        <div class=\"col-sm-offset-2 col-sm-10\">\n                            <button class=\"regularButton\" style=\"width: 70px;padding-right: 5px;\" (click)=\"addItem()\" [disabled]=\"selectedItemValue === ''\">Add</button>\n                            <button class=\"regularButton\" style=\"width: 70px;padding-right: 5px;\" (click)=\"changeItem()\" [disabled]=\"!selectedItem\">Change</button>\n                            <button class=\"regularButton\" style=\"width: 70px;padding-right: 5px;\" (click)=\"deleteItem()\" [disabled]=\"!selectedItem\">Delete</button>\n                        </div>\n                    </div>\n                 </form>\n            </div>\n\n        </div>        \n\n    </div>\n</web-application>\n"

/***/ }),

/***/ "./src/app/listEditor/listEditor.component.css":
/*!*****************************************************!*\
  !*** ./src/app/listEditor/listEditor.component.css ***!
  \*****************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".listTable {\n    border: 1px solid black;\n    border-collapse: collapse;\n    width: 100%;\n    height: 250px;;\n}\n\n.listBody {\n    overflow: auto;\n    display: block;\n    height: 100%;\n}\n\n.listItem {\n    padding-left: 3px;\n    border-style: none;\n}\n\n.selectedItem {\n    background: brown;\n    color: white;\n}\n\n.droppable {\n    border: 2px dashed gray;\n}\n\n/* Main Navigation */\n\nul#navigation {\n    margin:0px auto;\n    position:relative;\n    float:left;\n}\n\nul#navigation li {\n    display:inline;\n    float:left;\n\n}\n\nul#navigation li h5 {\n    padding:5px 5px 5px 15px;\n    display:inline-block;\n    margin: 5px 0 0 0;\n    width: 100%;\n}\n\nul#navigation li h5:hover {\n    background:#f8f8f8;\n    color:#282828;\n}\n\nul#navigation li:hover > a {\n    background:#fff;\n}\n\n/* Drop-Down Navigation */\n\nul#navigation li:hover > ul\n{\n/*these 2 styles are very important,\nbeing the ones which make the drop-down to appear on hover */\n    visibility:visible;\n    opacity:1;\n}\n\nul#navigation ul, ul#navigation ul li ul {\n    list-style: none;\n    margin-left: 10px;\n    padding: 0;\n/*the next 2 styles are very important,\nbeing the ones which make the drop-down to stay hidden */\n    visibility:hidden;\n    opacity:0;\n    position: absolute;\n    z-index: 99999;\n    width:180px;\n    background:#ddd;\n    box-shadow:1px 1px 3px #ccc;\n/* css3 transitions for smooth hover effect */\n    -webkit-transition:opacity 0.2s linear, visibility 0.2s linear;\n    transition:opacity 0.2s linear, visibility 0.2s linear;\n}\n\nul#navigation ul {\n    top: 25px;\n    left: 10px;\n}\n\nul#navigation ul li ul {\n    top: 0;\n    left: 181px; /* strong related to width:180px; from above */\n}\n\nul#navigation ul li {\n    clear:both;\n    width:100%;\n    border:0 none;\n    border-bottom:1px solid #c9c9c9;\n}\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvbGlzdEVkaXRvci9saXN0RWRpdG9yLmNvbXBvbmVudC5jc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7SUFDSSx1QkFBdUI7SUFDdkIseUJBQXlCO0lBQ3pCLFdBQVc7SUFDWCxhQUFhO0FBQ2pCOztBQUVBO0lBQ0ksY0FBYztJQUNkLGNBQWM7SUFDZCxZQUFZO0FBQ2hCOztBQUVBO0lBQ0ksaUJBQWlCO0lBQ2pCLGtCQUFrQjtBQUN0Qjs7QUFFQTtJQUNJLGlCQUFpQjtJQUNqQixZQUFZO0FBQ2hCOztBQUVBO0lBQ0ksdUJBQXVCO0FBQzNCOztBQUVBLG9CQUFvQjs7QUFHcEI7SUFDSSxlQUFlO0lBQ2YsaUJBQWlCO0lBQ2pCLFVBQVU7QUFDZDs7QUFFQTtJQUNJLGNBQWM7SUFDZCxVQUFVOztBQUVkOztBQUVBO0lBQ0ksd0JBQXdCO0lBQ3hCLG9CQUFvQjtJQUNwQixpQkFBaUI7SUFDakIsV0FBVztBQUNmOztBQUVBO0lBQ0ksa0JBQWtCO0lBQ2xCLGFBQWE7QUFDakI7O0FBSUE7SUFDSSxlQUFlO0FBQ25COztBQUNBLHlCQUF5Qjs7QUFDekI7O0FBRUE7NERBQzREO0lBQ3hELGtCQUFrQjtJQUNsQixTQUFTO0FBQ2I7O0FBRUE7SUFDSSxnQkFBZ0I7SUFDaEIsaUJBQWlCO0lBQ2pCLFVBQVU7QUFDZDt3REFDd0Q7SUFDcEQsaUJBQWlCO0lBQ2pCLFNBQVM7SUFDVCxrQkFBa0I7SUFDbEIsY0FBYztJQUNkLFdBQVc7SUFDWCxlQUFlO0lBQ2YsMkJBQTJCO0FBQy9CLDZDQUE2QztJQUN6Qyw4REFBOEQ7SUFHOUQsc0RBQXNEO0FBQzFEOztBQUVBO0lBQ0ksU0FBUztJQUNULFVBQVU7QUFDZDs7QUFFQTtJQUNJLE1BQU07SUFDTixXQUFXLEVBQUUsOENBQThDO0FBQy9EOztBQUVBO0lBQ0ksVUFBVTtJQUNWLFVBQVU7SUFDVixhQUFhO0lBQ2IsK0JBQStCO0FBQ25DIiwiZmlsZSI6InNyYy9hcHAvbGlzdEVkaXRvci9saXN0RWRpdG9yLmNvbXBvbmVudC5jc3MiLCJzb3VyY2VzQ29udGVudCI6WyIubGlzdFRhYmxlIHtcbiAgICBib3JkZXI6IDFweCBzb2xpZCBibGFjaztcbiAgICBib3JkZXItY29sbGFwc2U6IGNvbGxhcHNlO1xuICAgIHdpZHRoOiAxMDAlO1xuICAgIGhlaWdodDogMjUwcHg7O1xufVxuXG4ubGlzdEJvZHkge1xuICAgIG92ZXJmbG93OiBhdXRvO1xuICAgIGRpc3BsYXk6IGJsb2NrO1xuICAgIGhlaWdodDogMTAwJTtcbn1cblxuLmxpc3RJdGVtIHtcbiAgICBwYWRkaW5nLWxlZnQ6IDNweDtcbiAgICBib3JkZXItc3R5bGU6IG5vbmU7XG59XG5cbi5zZWxlY3RlZEl0ZW0ge1xuICAgIGJhY2tncm91bmQ6IGJyb3duO1xuICAgIGNvbG9yOiB3aGl0ZTtcbn1cblxuLmRyb3BwYWJsZSB7XG4gICAgYm9yZGVyOiAycHggZGFzaGVkIGdyYXk7XG59XG5cbi8qIE1haW4gTmF2aWdhdGlvbiAqL1xuXG4gXG51bCNuYXZpZ2F0aW9uIHtcbiAgICBtYXJnaW46MHB4IGF1dG87XG4gICAgcG9zaXRpb246cmVsYXRpdmU7XG4gICAgZmxvYXQ6bGVmdDtcbn1cbiBcbnVsI25hdmlnYXRpb24gbGkge1xuICAgIGRpc3BsYXk6aW5saW5lO1xuICAgIGZsb2F0OmxlZnQ7XG5cbn1cbiBcbnVsI25hdmlnYXRpb24gbGkgaDUge1xuICAgIHBhZGRpbmc6NXB4IDVweCA1cHggMTVweDtcbiAgICBkaXNwbGF5OmlubGluZS1ibG9jaztcbiAgICBtYXJnaW46IDVweCAwIDAgMDtcbiAgICB3aWR0aDogMTAwJTtcbn1cbiBcbnVsI25hdmlnYXRpb24gbGkgaDU6aG92ZXIge1xuICAgIGJhY2tncm91bmQ6I2Y4ZjhmODtcbiAgICBjb2xvcjojMjgyODI4O1xufVxuIFxuXG4gXG51bCNuYXZpZ2F0aW9uIGxpOmhvdmVyID4gYSB7XG4gICAgYmFja2dyb3VuZDojZmZmO1xufVxuLyogRHJvcC1Eb3duIE5hdmlnYXRpb24gKi9cbnVsI25hdmlnYXRpb24gbGk6aG92ZXIgPiB1bFxue1xuLyp0aGVzZSAyIHN0eWxlcyBhcmUgdmVyeSBpbXBvcnRhbnQsXG5iZWluZyB0aGUgb25lcyB3aGljaCBtYWtlIHRoZSBkcm9wLWRvd24gdG8gYXBwZWFyIG9uIGhvdmVyICovXG4gICAgdmlzaWJpbGl0eTp2aXNpYmxlO1xuICAgIG9wYWNpdHk6MTtcbn1cbiBcbnVsI25hdmlnYXRpb24gdWwsIHVsI25hdmlnYXRpb24gdWwgbGkgdWwge1xuICAgIGxpc3Qtc3R5bGU6IG5vbmU7XG4gICAgbWFyZ2luLWxlZnQ6IDEwcHg7XG4gICAgcGFkZGluZzogMDtcbi8qdGhlIG5leHQgMiBzdHlsZXMgYXJlIHZlcnkgaW1wb3J0YW50LFxuYmVpbmcgdGhlIG9uZXMgd2hpY2ggbWFrZSB0aGUgZHJvcC1kb3duIHRvIHN0YXkgaGlkZGVuICovXG4gICAgdmlzaWJpbGl0eTpoaWRkZW47XG4gICAgb3BhY2l0eTowO1xuICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgICB6LWluZGV4OiA5OTk5OTtcbiAgICB3aWR0aDoxODBweDtcbiAgICBiYWNrZ3JvdW5kOiNkZGQ7XG4gICAgYm94LXNoYWRvdzoxcHggMXB4IDNweCAjY2NjO1xuLyogY3NzMyB0cmFuc2l0aW9ucyBmb3Igc21vb3RoIGhvdmVyIGVmZmVjdCAqL1xuICAgIC13ZWJraXQtdHJhbnNpdGlvbjpvcGFjaXR5IDAuMnMgbGluZWFyLCB2aXNpYmlsaXR5IDAuMnMgbGluZWFyO1xuICAgIC1tb3otdHJhbnNpdGlvbjpvcGFjaXR5IDAuMnMgbGluZWFyLCB2aXNpYmlsaXR5IDAuMnMgbGluZWFyO1xuICAgIC1vLXRyYW5zaXRpb246b3BhY2l0eSAwLjJzIGxpbmVhciwgdmlzaWJpbGl0eSAwLjJzIGxpbmVhcjtcbiAgICB0cmFuc2l0aW9uOm9wYWNpdHkgMC4ycyBsaW5lYXIsIHZpc2liaWxpdHkgMC4ycyBsaW5lYXI7XG59XG4gXG51bCNuYXZpZ2F0aW9uIHVsIHtcbiAgICB0b3A6IDI1cHg7XG4gICAgbGVmdDogMTBweDtcbn1cbiBcbnVsI25hdmlnYXRpb24gdWwgbGkgdWwge1xuICAgIHRvcDogMDtcbiAgICBsZWZ0OiAxODFweDsgLyogc3Ryb25nIHJlbGF0ZWQgdG8gd2lkdGg6MTgwcHg7IGZyb20gYWJvdmUgKi9cbn1cbiBcbnVsI25hdmlnYXRpb24gdWwgbGkge1xuICAgIGNsZWFyOmJvdGg7XG4gICAgd2lkdGg6MTAwJTtcbiAgICBib3JkZXI6MCBub25lO1xuICAgIGJvcmRlci1ib3R0b206MXB4IHNvbGlkICNjOWM5Yzk7XG59XG4iXX0= */"

/***/ }),

/***/ "./src/app/listEditor/listEditor.component.ts":
/*!****************************************************!*\
  !*** ./src/app/listEditor/listEditor.component.ts ***!
  \****************************************************/
/*! exports provided: ListEditorComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ListEditorComponent", function() { return ListEditorComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var js44d__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! js44d */ "./node_modules/js44d/fesm2015/js44d.js");



let ListEditorComponent = class ListEditorComponent {
    constructor(fourD /*, private logger: LogService*/) {
        this.fourD = fourD;
        this.listCount = 0;
        this.listNames = [];
        this.selectedListName = '';
        this.listItems = [];
        this.selectedItemIndex = -1;
        this.selectedItemValue = '';
    }
    ngAfterContentInit() {
        this.fourD.call4DRESTMethod('REST_GetListOf4DLists', {})
            .subscribe(resultJSON => {
            this.listCount = resultJSON.listCount;
            this.listNames = resultJSON.listNames;
        });
    }
    selectList(event, list) {
        if (this.selectedList) {
            this.selectedList.classList.remove('selectedItem');
        }
        if (this.selectedItem) {
            this.selectedItem.classList.remove('selectedItem');
            this.selectedItemValue = '';
            this.selectedItemIndex = -1;
        }
        this.selectedList = event.target;
        this.selectedListName = list;
        this.fourD.get4DList(this.selectedListName)
            .then((values) => {
            this.selectedList.classList.add('selectedItem');
            this.listItems = values;
            this.selectedItem = null;
            this.selectedItemIndex = -1;
        });
    }
    selectItem(event, item) {
        if (this.selectedItem) {
            this.selectedItem.classList.remove('selectedItem');
        }
        this.selectedItemValue = item;
        this.selectedItemIndex = event.currentTarget.rowIndex;
        this.selectedItem = event.target;
        this.selectedItem.classList.add('selectedItem');
    }
    addItem() {
        if (this.selectedItemValue !== '') {
            this.listItems.push(this.selectedItemValue);
            this.update4DList();
        }
    }
    changeItem() {
        if (this.selectedItemIndex >= 0) {
            this.listItems[this.selectedItemIndex] = this.selectedItemValue;
            this.update4DList();
        }
    }
    deleteItem() {
        if (this.selectedItemIndex >= 0) {
            this.listItems.splice(this.selectedItemIndex, 1);
            this.update4DList();
        }
    }
    update4DList() {
        this.fourD.update4DList(this.selectedListName, this.listItems);
    }
    startDrag(event, type) {
        event.effectAllowed = 'copy';
        event.dataTransfer.setData('row', event.currentTarget.rowIndex);
    }
    allowDrop(event) {
        if (event.preventDefault) {
            event.preventDefault();
        } // Necessary. Allows us to drop.
        if (event.stopPropagation) {
            event.stopPropagation();
        }
        if (event.type === 'dragenter') {
            event.target.classList.add('droppable');
            event.dataTransfer.dropEffect = 'copy'; // See the section on the DataTransfer object.
        }
        return false;
    }
    disableDrop(event) {
        if (event.stopPropagation) {
            event.stopPropagation();
        }
        event.target.classList.remove('droppable');
    }
    handleDrop(event) {
        if (event.stopPropagation) {
            event.stopPropagation();
        }
        this.disableDrop(event);
        const row = event.dataTransfer.getData('row');
        const moveToIndex = event.currentTarget.rowIndex;
        const item = this.listItems.splice(row, 1);
        if (row < moveToIndex) {
            // moving up...
            this.listItems.splice(event.currentTarget.rowIndex - 1, 0, item[0]);
        }
        else {
            // moving down
            this.listItems.splice(event.currentTarget.rowIndex, 0, item[0]);
        }
        this.update4DList();
    }
};
ListEditorComponent.dialogConfig = {
    actions: ['Maximize', 'Minimize', 'Close'], position: { top: 100, left: 150 }, selfCentered: true,
    title: '4D List Editor',
    isResizable: true,
    width: 1100, height: 510
};
ListEditorComponent.ctorParameters = () => [
    { type: js44d__WEBPACK_IMPORTED_MODULE_2__["FourDInterface"] /*, private logger: LogService*/ }
];
ListEditorComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'list-editor',
        template: __webpack_require__(/*! raw-loader!./listEditor.component.html */ "./node_modules/raw-loader/index.js!./src/app/listEditor/listEditor.component.html"),
        styles: [__webpack_require__(/*! ./listEditor.component.css */ "./src/app/listEditor/listEditor.component.css")]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [js44d__WEBPACK_IMPORTED_MODULE_2__["FourDInterface"] /*, private logger: LogService*/])
], ListEditorComponent);



/***/ }),

/***/ "./src/app/listEditor/listEditor.module.ts":
/*!*************************************************!*\
  !*** ./src/app/listEditor/listEditor.module.ts ***!
  \*************************************************/
/*! exports provided: ListEditorRoutes, ListEditorModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ListEditorRoutes", function() { return ListEditorRoutes; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ListEditorModule", function() { return ListEditorModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm2015/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _listEditorDialog_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./listEditorDialog.component */ "./src/app/listEditor/listEditorDialog.component.ts");
/* harmony import */ var _listEditor_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./listEditor.component */ "./src/app/listEditor/listEditor.component.ts");
/* harmony import */ var js44d__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! js44d */ "./node_modules/js44d/fesm2015/js44d.js");







// feature modules



const ListEditorRoutes = [
    {
        path: '',
        component: _listEditorDialog_component__WEBPACK_IMPORTED_MODULE_5__["ListEditorDialog"]
    }
];
let ListEditorModule = class ListEditorModule {
};
ListEditorModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"].forChild(ListEditorRoutes),
            js44d__WEBPACK_IMPORTED_MODULE_7__["FourDModule"], js44d__WEBPACK_IMPORTED_MODULE_7__["JS44DModule"], js44d__WEBPACK_IMPORTED_MODULE_7__["ModalModule"]
        ],
        declarations: [_listEditorDialog_component__WEBPACK_IMPORTED_MODULE_5__["ListEditorDialog"], _listEditor_component__WEBPACK_IMPORTED_MODULE_6__["ListEditorComponent"]],
        entryComponents: [_listEditor_component__WEBPACK_IMPORTED_MODULE_6__["ListEditorComponent"]],
    })
], ListEditorModule);



/***/ }),

/***/ "./src/app/listEditor/listEditorDialog.component.ts":
/*!**********************************************************!*\
  !*** ./src/app/listEditor/listEditorDialog.component.ts ***!
  \**********************************************************/
/*! exports provided: ListEditorDialog */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ListEditorDialog", function() { return ListEditorDialog; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var js44d__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! js44d */ "./node_modules/js44d/fesm2015/js44d.js");
/* harmony import */ var _listEditor_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./listEditor.component */ "./src/app/listEditor/listEditor.component.ts");





let ListEditorDialog = class ListEditorDialog {
    constructor(modal, router, elementRef, viewRef) {
        this.modal = modal;
        this.router = router;
        this.elementRef = elementRef;
        this.viewRef = viewRef;
    }
    /**
     * AFter our view gets initialized, subscribe to various events on the Query band and the Grid
     */
    ngAfterContentInit() {
        this.router.navigate(['/blank'], { skipLocationChange: true });
        this.modal.openDialog(_listEditor_component__WEBPACK_IMPORTED_MODULE_4__["ListEditorComponent"], {}); // open edit dialog
    }
};
ListEditorDialog.ctorParameters = () => [
    { type: js44d__WEBPACK_IMPORTED_MODULE_3__["Modal"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"] },
    { type: _angular_core__WEBPACK_IMPORTED_MODULE_1__["ElementRef"] },
    { type: _angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewContainerRef"] }
];
ListEditorDialog = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'browse-table-dialog',
        template: '<div></div>',
        providers: [js44d__WEBPACK_IMPORTED_MODULE_3__["Modal"]]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [js44d__WEBPACK_IMPORTED_MODULE_3__["Modal"], _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["ElementRef"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewContainerRef"]])
], ListEditorDialog);



/***/ })

}]);
//# sourceMappingURL=app-listEditor-listEditor-module-es2015.js.map