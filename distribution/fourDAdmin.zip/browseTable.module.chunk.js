webpackJsonp(["browseTable.module"],{

/***/ "../../../../../src/app/browseTable/browseFieldDialog.component.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return BrowseFieldDialog; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("../../../core/esm5/core.js");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};

var BrowseFieldDialog = /** @class */ (function () {
    function BrowseFieldDialog() {
    }
    BrowseFieldDialog = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["n" /* Component */])({
            moduleId: module.i,
            selector: 'field-content',
            template: ""
        })
    ], BrowseFieldDialog);
    return BrowseFieldDialog;
}());



/***/ }),

/***/ "../../../../../src/app/browseTable/browseFormDialog.component.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return BrowseFormDialog; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("../../../core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_js44d__ = __webpack_require__("../../../../js44d/js44d.es5.js");
var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};


var BrowseFormDialog = /** @class */ (function (_super) {
    __extends(BrowseFormDialog, _super);
    function BrowseFormDialog() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    BrowseFormDialog.prototype.ngAfterViewInit = function () {
        var _this = this;
        this.dialog.setTitle('Edit Record: ' + this.currentRecord.tableName);
        /**
         * as I'm dealing with a fake FourDModel instance, I need to populate
         * the model's attributes so data modification gets properly flagged
         */
        this.currentRecord.fields.forEach(function (element) {
            _this.currentRecord.set(element.name, _this.currentRecord[element.name]);
        });
        this.currentRecord.clearRecordDirtyFlag();
    };
    BrowseFormDialog.dialogConfig = {
        actions: ['Maximize', 'Minimize', 'Close'], position: { top: 100, left: 100 }, selfCentered: true,
        title: 'Record Details',
        isResizable: true,
        width: 950, height: 500
    };
    BrowseFormDialog = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["n" /* Component */])({
            moduleId: module.i,
            selector: 'modal-content',
            template: "\n    <div style=\"display:flex;flex-direction:column;height:calc(100% - 20px);\">\n                <form style=\"display:grid;overflow:scroll;margin:20px 20px 5px 20px;padding-left:10px;border-style:outset\">\n                    <browse-inputfield *ngFor='let field of currentRecord.fields' [inputField]= \"field\" [currentRecord]=\"currentRecord\"></browse-inputfield>                    \n                </form>\n                <div class=\"buttonBar\" style=\"align-self:flex-end\">\n                    <button class=\"regularButton\" style=\"width:90px;\" (click)=\"dialog.close('cancel')\">Cancel</button>\n                    <button class=\"regularButton\" style=\"margin-left:20px;width:90px;\" (click)=\"saveRecord()\">SAVE</button>\n                </div>\n    </div>\n            "
        })
    ], BrowseFormDialog);
    return BrowseFormDialog;
}(__WEBPACK_IMPORTED_MODULE_1_js44d__["j" /* RecordEditWindow */]));



/***/ }),

/***/ "../../../../../src/app/browseTable/browseInputField.component.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return BrowseInputField; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("../../../core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__browseTable_component__ = __webpack_require__("../../../../../src/app/browseTable/browseTable.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_js44d__ = __webpack_require__("../../../../js44d/js44d.es5.js");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};



/* tslint:disable */
var BrowseInputField = /** @class */ (function () {
    /* tslint:denable */
    function BrowseInputField() {
    }
    Object.defineProperty(BrowseInputField.prototype, "stringField", {
        /**
         * Here I have to use a trick to deal with the fact that I'm using a fake FourDModel
         * which has not get/set methods for each property
         * so I'm using generic typed variables that do the get/set functions I need
         */
        get: function () {
            return this.currentRecord.get(this.inputField.name);
        },
        set: function (v) {
            this.currentRecord.set(this.inputField.name, v);
            this.currentRecord[this.inputField.name] = v;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(BrowseInputField.prototype, "numberField", {
        get: function () {
            return this.currentRecord.get(this.inputField.name);
        },
        set: function (v) {
            this.currentRecord.set(this.inputField.name, v);
            this.currentRecord[this.inputField.name] = v;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(BrowseInputField.prototype, "booleanField", {
        get: function () {
            return this.currentRecord.get(this.inputField.name);
        },
        set: function (v) {
            this.currentRecord.set(this.inputField.name, v);
            this.currentRecord[this.inputField.name] = v;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(BrowseInputField.prototype, "dateField", {
        get: function () {
            // need to deal with how browsers handle 'date' input fields, which is not really supported, so we treat it as a string input for now
            var value;
            var dateValue = this.currentRecord[this.inputField.name];
            if (typeof (dateValue) === 'string') {
                value = dateValue;
            }
            else {
                value = dateValue.getFullYear().toString() + '-';
                if (dateValue.getMonth() < 9)
                    value += '0';
                value += (dateValue.getMonth() + 1).toString() + '-';
                if (dateValue.getDate() < 10)
                    value += '0';
                value += dateValue.getDate().toString();
            }
            return value;
        },
        set: function (v) {
            this.currentRecord.set(this.inputField.name, new Date(v.replace(/-/g, '\/')));
            this.currentRecord[this.inputField.name] = this.currentRecord.get(this.inputField.name);
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(BrowseInputField.prototype, "objectField", {
        get: function () {
            return JSON.stringify(this.currentRecord.get(this.inputField.name));
        },
        set: function (v) {
            this.currentRecord.set(this.inputField.name, JSON.parse(v));
            this.currentRecord[this.inputField.name] = JSON.parse(v);
        },
        enumerable: true,
        configurable: true
    });
    __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["E" /* Input */])(),
        __metadata("design:type", __WEBPACK_IMPORTED_MODULE_1__browseTable_component__["b" /* FieldDescription */])
    ], BrowseInputField.prototype, "inputField", void 0);
    __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["E" /* Input */])(),
        __metadata("design:type", __WEBPACK_IMPORTED_MODULE_2_js44d__["c" /* FourDModel */])
    ], BrowseInputField.prototype, "currentRecord", void 0);
    __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["E" /* Input */])(),
        __metadata("design:type", String),
        __metadata("design:paramtypes", [String])
    ], BrowseInputField.prototype, "stringField", null);
    __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["E" /* Input */])(),
        __metadata("design:type", Number),
        __metadata("design:paramtypes", [Number])
    ], BrowseInputField.prototype, "numberField", null);
    __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["E" /* Input */])(),
        __metadata("design:type", Boolean),
        __metadata("design:paramtypes", [Boolean])
    ], BrowseInputField.prototype, "booleanField", null);
    __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["E" /* Input */])(),
        __metadata("design:type", String),
        __metadata("design:paramtypes", [String])
    ], BrowseInputField.prototype, "dateField", null);
    __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["E" /* Input */])(),
        __metadata("design:type", String),
        __metadata("design:paramtypes", [String])
    ], BrowseInputField.prototype, "objectField", null);
    BrowseInputField = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["n" /* Component */])({
            moduleId: module.i,
            selector: 'browse-inputfield',
            template: "<div style=\"display:inline-block;margin:15px;width:calc(100% - 30px)\">\n                <label class=\"formHeaderSmall\" [attr.for]=\"inputField.name\" style=\"margin-right:10px;width:180px;vertical-align:top\">{{inputField.title}}:&nbsp;&nbsp;</label>\n                    <span [ngSwitch]=\"inputField.type\">\n                        <span *ngSwitchCase=\"'string'\">\n                            <fourd-dropdown *ngIf=\"inputField.choiceList != ''\" listName=\"{{inputField.choiceList}}\" [(selectedValue)]=\"stringField\" (change)=\"stringField = $event.target.value\"></fourd-dropdown>\n                            <textarea *ngIf=\"inputField.length > 0 && inputField.choiceList == ''\" [maxlength]=\"inputField.length\" [name]=\"inputField.name\" type=\"text\" class=\"fieldEntry\"  cols=\"90\" style=\"resize:vertical;width:75%\" [(ngModel)]=\"stringField\"></textarea>\n                            <textarea *ngIf=\"!inputField.length && inputField.choiceList == ''\"  [name]=\"inputField.name\" type=\"text\" class=\"fieldEntry\"  cols=\"90\" style=\"resize:vertical;width:75%\" [(ngModel)]=\"stringField\" [disabled]=\"inputField.readonly\"></textarea>\n                        </span>\n                        <input *ngSwitchCase=\"'Date'\"  [name]=\"inputField.name\" type=\"date\" class=\"fieldEntry\"  style=\"width:125px;height:20px;\" [(ngModel)]=\"dateField\" [disabled]=\"inputField.readonly\"/>\n                        <input *ngSwitchCase=\"'Time'\"  [name]=\"inputField.name\" type=\"time\" class=\"fieldEntry\"  style=\"width:100px;height:20px;\" [(ngModel)]=\"stringField\" [disabled]=\"inputField.readonly\"/>\n                        <input *ngSwitchCase=\"'number'\"  [name]=\"inputField.name\" type=\"number\" class=\"fieldEntry\"  style=\"width:80px;height:20px;text-align:right;\" [(ngModel)]=\"numberField\" [disabled]=\"inputField.readonly\"/>\n                        <input *ngSwitchCase=\"'float'\"  [name]=\"inputField.name\" type=\"number\" class=\"fieldEntry\"  style=\"width:80px;height:20px;\" [(ngModel)]=\"numberField\" [disabled]=\"inputField.readonly\"/>\n                        <input *ngSwitchCase=\"'boolean'\"  [name]=\"inputField.name\" type=\"checkbox\" class=\"fieldEntry\" style=\"height:30px;width:50px;margin-top:-6px;\" [(ngModel)]=\"booleanField\" [disabled]=\"inputField.readonly\"/>\n                        <textarea *ngSwitchCase=\"'json'\"  [name]=\"inputField.name\" type=\"text\" class=\"fieldEntry\"  cols=\"90\" style=\"resize:vertical;width:75%\" [(ngModel)]=\"objectField\" disabled></textarea>\n                        <img *ngSwitchCase=\"'picture'\" [src]=\"stringField | base64ImageRef\" style=\"height:300px;\"/>\n                     </span>    \n               \n                </div>\n \n            "
        })
        /* tslint:denable */
    ], BrowseInputField);
    return BrowseInputField;
}());



/***/ }),

/***/ "../../../../../src/app/browseTable/browseQuery.component.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return BrowseQueryBand; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("../../../core/esm5/core.js");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};

var BrowseQueryBand = /** @class */ (function () {
    function BrowseQueryBand() {
        this.queryData = {};
    }
    Object.defineProperty(BrowseQueryBand.prototype, "currentQuery", {
        //
        // build 4C-TV query based on items from query band
        //
        get: function () {
            var _this = this;
            var currQuery = [];
            this.queryFields.forEach(function (field) {
                if (field.quickQuery) {
                    switch (field.type) {
                        case 'string':
                            if (_this.queryData[field.name] && _this.queryData[field.name] !== '') {
                                currQuery.push(field.field + ';contains;' + _this.queryData[field.name] + ';AND');
                            }
                            break;
                        case 'number':
                        case 'float':
                        case 'boolean':
                        case 'Time':
                            if (_this.queryData[field.name] && _this.queryData[field.name] !== '') {
                                currQuery.push(field.field + ';=;' + _this.queryData[field.name] + ';AND');
                            }
                            break;
                        case 'Date':
                            if (_this.queryData[field.name] && _this.queryData[field.name] !== '') {
                                currQuery.push(field.field + ';=;' + (_this.queryData[field.name]).replace(/-/g, '') + ';AND');
                            }
                            break;
                    }
                }
            });
            return (currQuery.length > 0) ? { query: currQuery } : null; // {query:['all']};
        },
        enumerable: true,
        configurable: true
    });
    __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["E" /* Input */])(),
        __metadata("design:type", Array)
    ], BrowseQueryBand.prototype, "queryFields", void 0);
    __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["E" /* Input */])(),
        __metadata("design:type", Object)
    ], BrowseQueryBand.prototype, "queryData", void 0);
    BrowseQueryBand = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["n" /* Component */])({
            moduleId: module.i,
            selector: 'browse-queryband',
            template: "\n                <form style=\"display:flex;overflow:auto\">\n                    <div *ngFor='let field of queryFields'  style=\"float: left;height: 100%; margin-right: 10px;\">\n                        <browse-queryfield *ngIf='field.quickQuery' [queryField]= \"field\" [queryData]=\"queryData\"></browse-queryfield>\n                    </div>\n                </form>\n            "
        })
    ], BrowseQueryBand);
    return BrowseQueryBand;
}());



/***/ }),

/***/ "../../../../../src/app/browseTable/browseQueryField.component.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return BrowseQueryField; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("../../../core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__browseTable_component__ = __webpack_require__("../../../../../src/app/browseTable/browseTable.component.ts");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};


var BrowseQueryField = /** @class */ (function () {
    function BrowseQueryField() {
        this.queryData = {};
    }
    __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["E" /* Input */])(),
        __metadata("design:type", __WEBPACK_IMPORTED_MODULE_1__browseTable_component__["b" /* FieldDescription */])
    ], BrowseQueryField.prototype, "queryField", void 0);
    __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["E" /* Input */])(),
        __metadata("design:type", Object)
    ], BrowseQueryField.prototype, "queryData", void 0);
    BrowseQueryField = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["n" /* Component */])({
            moduleId: module.i,
            selector: 'browse-queryfield',
            template: "\n                <label class=\"fieldPrompt\" [attr.for]=\"queryField.name\" style=\"margin-right:10px;\">{{queryField.title}}:&nbsp;&nbsp;\n                    <div [ngSwitch]=\"queryField.type\">\n                        <input *ngSwitchCase=\"'string'\"  [name]=\"queryField.name\" type=\"text\" class=\"fieldEntry\"  style=\"width:180px;height:20px;\" [(ngModel)]=\"queryData[queryField.name]\"/>\n                        <input *ngSwitchCase=\"'Date'\"  [name]=\"queryField.name\" type=\"date\" class=\"fieldEntry\"  style=\"width:125px;height:20px;\" [(ngModel)]=\"queryData[queryField.name]\"/>\n                        <input *ngSwitchCase=\"'Time'\"  [name]=\"queryField.name\" type=\"time\" class=\"fieldEntry\"  style=\"width:100px;height:20px;\" [(ngModel)]=\"queryData[queryField.name]\"/>\n                        <input *ngSwitchCase=\"'number'\"  [name]=\"queryField.name\" type=\"number\" class=\"fieldEntry\"  style=\"width:80px;height:20px;\" [(ngModel)]=\"queryData[queryField.name]\"/>\n                        <input *ngSwitchCase=\"'float'\"  [name]=\"queryField.name\" type=\"number\" class=\"fieldEntry\"  style=\"width:80px;height:20px;\" [(ngModel)]=\"queryData[queryField.name]\"/>\n                        <input *ngSwitchCase=\"'boolean'\"  [name]=\"queryField.name\" type=\"checkbox\" class=\"fieldEntry\"  style=\"width:80px;height:20px;\" [(ngModel)]=\"queryData[queryField.name]\"/>\n                     </div>    \n                </label>\n \n            "
        })
    ], BrowseQueryField);
    return BrowseQueryField;
}());



/***/ }),

/***/ "../../../../../src/app/browseTable/browseTable.component.css":
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__("../../../../css-loader/lib/css-base.js")(false);
// imports


// module
exports.push([module.i, ".block {\n    border-style: solid; \n    border-width: thin; \n    padding-bottom: 4px; \n    display:-webkit-box; \n    display:-ms-flexbox; \n    display:flex; \n    -webkit-box-orient: vertical; \n    -webkit-box-direction: normal; \n        -ms-flex-direction: column; \n            flex-direction: column; \n    height: 289px;\n}\n\n.listTable {\n    border: 1px solid black;\n    border-collapse: collapse;\n    width: 100%;\n    height: 250px;;\n}\n\n.listBody {\n    overflow: auto;\n    display: block;\n    height: 100%;\n}\n\n.listItem {\n    padding-left: 3px;\n    border-style: none;\n}\n\n.selectedItem {\n    background: brown;\n    color: white;\n}\n\n\n.highlight {\n    background-color: #00FF00;\n}\n\n.droppable {\n    border: 2px dashed gray;\n}\n\n.icon {\n    font-family: FontAwesome, fontawesome;\n    font-size: 24;\n }\n \n/* Main Navigation */\n\n \nul#navigation {\n    margin:0px auto;\n    position:relative;\n    float:left;\n}\n \nul#navigation li {\n    display:inline;\n    float:left;\n\n}\n \nul#navigation li h5 {\n    padding:5px 5px 5px 15px;\n    display:inline-block;\n    margin: 5px 0 0 0;\n    width: 100%;\n}\n \nul#navigation li h5:hover {\n    background:#f8f8f8;\n    color:#282828;\n}\n \n\n \nul#navigation li:hover > a {\n    background:#fff;\n}\n/* Drop-Down Navigation */\nul#navigation li:hover > ul\n{\n/*these 2 styles are very important,\nbeing the ones which make the drop-down to appear on hover */\n    visibility:visible;\n    opacity:1;\n}\n \nul#navigation ul, ul#navigation ul li ul {\n    list-style: none;\n    margin-left: 10px;\n    padding: 0;\n/*the next 2 styles are very important,\nbeing the ones which make the drop-down to stay hidden */\n    visibility:hidden;\n    opacity:0;\n    position: absolute;\n    z-index: 99999;\n    width:180px;\n    background:#ddd;\n    box-shadow:1px 1px 3px #ccc;\n/* css3 transitions for smooth hover effect */\n    transition:opacity 0.2s linear, visibility 0.2s linear;\n}\n \nul#navigation ul {\n    top: 25px;\n    left: 10px;\n}\n \nul#navigation ul li ul {\n    top: 0;\n    left: 181px; /* strong related to width:180px; from above */\n}\n \nul#navigation ul li {\n    clear:both;\n    width:100%;\n    border:0 none;\n    border-bottom:1px solid #c9c9c9;\n}\n", ""]);

// exports


/*** EXPORTS FROM exports-loader ***/
module.exports = module.exports.toString();

/***/ }),

/***/ "../../../../../src/app/browseTable/browseTable.component.html":
/***/ (function(module, exports) {

module.exports = "<web-application>\n    <h2 style=\"text-align: center\">Browse Table</h2>\n    <div style=\"display: inline-flex; width:100%;z-index:5; position:absolute; top:35px;padding-left:10px;\">\n        <span title=\"collapse browse config\"><h4 style=\"background:#eaeef1;border-style: solid; border-width: 1px; border-radius: 5px;\" (click)=\"hideConfig()\" [hidden]=\"hideBrowseConfig\">&#8648;&#8648;&#8648;</h4></span>\n        <span title=\"expand browse config\"><h4 style=\"background:#eaeef1;border-style: solid; border-width: 1px; border-radius: 5px;\" (click)=\"showConfig()\" [hidden]=\"!hideBrowseConfig\">&#8650;&#8650;&#8650;</h4></span>\n    </div>\n    <div class=\"container-fluid\" style=\"margin-left:10px; height: calc(100% - 65px)\">\n        <div class=\"row\" [hidden]=\"hideBrowseConfig\">\n            <div class=\"col-sm-2 block\">\n                <h4>Select Table</h4>\n                <table  class=\"listTable\">\n                    <tbody class=\"listBody\">\n                        <tr *ngFor='let table of listOfTables' (click)=\"selectTable($event)\">\n                            <td class=\"listItem\">{{table}}</td>\n                        </tr>\n                    </tbody>\n                </table>\n            </div>\n            <div class=\"col-sm-2 block\">\n                <nav id=\"nav\">\n                    <ul id=\"navigation\">\n                        <li style=\"margin-left: -40px;\"><h4>{{listedTable}}&nbsp;<span *ngIf=\"listedTable.length > 0\">&raquo;</span></h4>\n                            <ul>\n                                <li *ngFor='let relatedTable of relatedOneTables' (click)=\"showRelatedTable($event)\"><h5>{{relatedTable}}</h5></li>\n                            </ul>\n                        </li>\n                    </ul>\n                </nav>\n                <table class=\"listTable\">\n                    <tbody class=\"listBody\">\n                        <tr *ngFor='let field of listOfFields' draggable=\"true\" style=\"cursor: move;\" (dragstart)=\"startDrag($event,'field')\">\n                            <td class=\"listItem\">{{field.name}}</td>\n                        </tr>\n                    </tbody>\n                </table>\n            </div>\n            <div class=\"col-sm-2 block\">\n                <h4>Columns</h4>\n                <table class=\"listTable\" style=\"height: 210px;\">\n                    <tbody class=\"listBody\" (dragenter)=\"allowDrop($event)\" (dragover)=\"allowDrop($event)\" (dragend)=\"disableDrop($event)\" (dragleave)=\"disableDrop($event)\" (drop)=\"handleDrop($event)\">\n                        <tr *ngFor='let column of listOfColumns' (click)=\"selectColumn($event)\" draggable=\"true\" (drop)=\"handleDrop($event)\" (dragstart)=\"startDrag($event,'column')\" (dragleave)=\"disableDrop($event)\">\n                            <td class=\"listItem\">{{column.name}}</td>\n                        </tr>\n                    </tbody>\n                </table>\n                <div style=\"margin-top: 10px;margin-bottom: 5px; display: flex; justify-content: space-around;\">\n                    <button class=\"regularButton\" (click)=\"loadConfig()\" [disabled]=\"noTableSelected()\">Load Config</button>\n                    <button class=\"regularButton\" (click)=\"saveConfig()\" [disabled]=\"noTableSelected()\">Save Config</button>\n                </div>\n            </div>\n            <div class=\"col-sm-4\" style=\"border-style: solid; border-width: thin; padding-bottom: 4px;\" [hidden]=\"!currentField.name\">\n                <h4>Column Info</h4>\n                <form  class=\"form-horizontal\" style=\"height: 250px;\">\n                    <div class=\"form-group\">\n                        <label for=\"field\" class=\"control-label col-sm-2\">Field:</label>\n                        <div class=\"col-sm-6\">\n                            <input name=\"fieldName\" type=\"text\" class=\"form-control\" disabled [(ngModel)]=\"currentField.name\">\n                        </div>\n                    </div>\n                    <div class=\"form-group\">\n                        <label for=\"pwd\" class=\"control-label col-sm-2\">Title:</label>\n                        <div class=\"col-sm-6\">\n                            <input name=\"title\" type=\"text\" class=\"form-control\" id=\"title\" [(ngModel)]=\"currentField.title\" (change)=\"mapColumnsToGrid()\">\n                        </div>\n                    </div>\n                    <div class=\"form-group\"> \n                        <div class=\"col-sm-offset-2 col-sm-10\">\n                            <div class=\"checkbox\">\n                                <label><input name=\"indexed\" type=\"checkbox\" [(ngModel)]=\"currentField.quickQuery\" (change)=\"mapColumnsToGrid()\">is present on Quick Query</label>\n                            </div>\n                        </div>\n                    </div>\n                    <div class=\"form-group\"> \n                        <div class=\"col-sm-offset-2 col-sm-10\">\n                            <button (click)=\"deleteField()\">Delete</button>\n                        </div>\n                    </div>\n                 </form>\n            </div>\n        </div>\n        \n        <div class=\"row\" style=\"border-style: solid; border-width: thin; padding-bottom: 4px;\" [style.height]=\"currentGridHeight\" [hidden]=\"currentTable === ''\">   \n            <record-list [editWindow]=\"editWindow\" [dialogInstance]=\"dialog\">\n                <query-band [enableSort]=\"true\" [enableQBE]=\"true\" [enableButtonBar]=\"true\" [enableAddRecord]=\"false\" [enableDeleteRecord]=\"true\" [enableExportGrid]=\"false\">\n                    <queryband class=\"form-group\">\n                        <browse-queryband  #customQueryBand [queryFields]=\"listOfColumns\" [(queryData)]=\"queryData\">\n                        </browse-queryband>\n                    </queryband>\n                    <custombuttonbar>\n                        <button class=\"regularButton\" style=\"width:70px;\" (click)=\"addRecord()\">Add</button>\n                    </custombuttonbar>\n                </query-band>\n                <datagrid\n                        [model]=\"model\" \n                        [selectionMode]=\"'multiple,row'\"\n                        [columns]=\"columnDefs\"\n                        [useLazyLoading]=\"true\"\n                        [optimizeGridLoading]=\"true\"\n                        [pageSize]=\"50\"\n                        [excelFilename]=\"'RecordList.xlsx'\"\n                        >\n                </datagrid>\n            </record-list>\n        </div>\n\n    </div>\n</web-application>\n"

/***/ }),

/***/ "../../../../../src/app/browseTable/browseTable.component.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "b", function() { return FieldDescription; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return BrowseTableComponent; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("../../../core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__angular_common_http__ = __webpack_require__("../../../common/esm5/http.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_js44d__ = __webpack_require__("../../../../js44d/js44d.es5.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__browseFormDialog_component__ = __webpack_require__("../../../../../src/app/browseTable/browseFormDialog.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4_base_64__ = __webpack_require__("../../../../base-64/base64.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4_base_64___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_4_base_64__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5_utf8_utf8__ = __webpack_require__("../../../../utf8/utf8.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5_utf8_utf8___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_5_utf8_utf8__);
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};









var FieldDescription = /** @class */ (function () {
    function FieldDescription() {
    }
    return FieldDescription;
}());

var BrowseTableComponent = /** @class */ (function () {
    function BrowseTableComponent(http, fourD, modal, viewref) {
        var _this = this;
        this.http = http;
        this.fourD = fourD;
        this.modal = modal;
        this.viewref = viewref;
        this.numOfTables = 0;
        this.listOfTables = [];
        this.currentTable = '';
        this.listedTable = '';
        this.listOfFields = [];
        this.listOfColumns = [];
        this.relatedOneTables = [];
        this.currentField = new FieldDescription();
        this.queryData = {};
        this.hideBrowseConfig = false;
        this.currentGridHeight = 'calc(100% - 330px)';
        // Declare Program edit Window
        //
        this.editWindow = __WEBPACK_IMPORTED_MODULE_3__browseFormDialog_component__["a" /* BrowseFormDialog */];
        // the columns for the datagrid
        this.columnDefs = [
            { title: 'Record ID', field: 'RecordID', width: '' }
        ];
        //
        // Declare Datagrid properties
        //
        this.model = __WEBPACK_IMPORTED_MODULE_2_js44d__["c" /* FourDModel */]; // the record datamodel to use 
        this.selectedRow = null;
        this.selectedColumn = null;
        this.selectedColumnIndex = -1;
        this.totalRecordCount = 0;
        this.models = [];
        /* tslint:disable */
        // need to disable lint here otw if'll flag variable before method rule, but I'm puting this at the button
        // on purpose, to have it out of the way
        //
        // define the dataSource used to populate/handle the grid's interface to 4D
        //
        this.dataSource = new kendo.data.DataSource({
            /* tslint:enabe */
            transport: {
                read: function (options) {
                    // console.log(options);
                    var newModel = new __WEBPACK_IMPORTED_MODULE_2_js44d__["c" /* FourDModel */]();
                    newModel.tableName = _this.currentTable;
                    var start = (options.data.pageSize && options.data.pageSize > 0) ? options.data.skip : 0;
                    var numrecs = (options.data.pageSize && options.data.pageSize > 0) ? options.data.pageSize : -1;
                    // now build filter if set
                    var filter = [];
                    if (options.data.filter) {
                        options.data.filter.filters.forEach(function (item) {
                            var comparator = '=';
                            switch (item.operator) {
                                case 'eq':
                                    comparator = '=';
                                    break;
                                case 'neq':
                                    comparator = '#';
                                    break;
                                case 'startswith':
                                    comparator = 'begins with';
                                    break;
                                case 'endswith':
                                    comparator = 'ends with';
                                    break;
                                case 'isempty':
                                    comparator = '=';
                                    item.value = '';
                                    break;
                                case 'isnotempty':
                                    comparator = '#';
                                    item.value = '';
                                    break;
                                default:
                                    comparator = item.operator;
                                    break;
                            }
                            filter.push(newModel.tableName + '.' + item.field + ';' + comparator + ';' + item.value + ';' + options.data.filter.logic);
                        });
                    }
                    var orderby = '';
                    if (options.data.sort && options.data.sort.length > 0) {
                        options.data.sort.forEach(function (item) {
                            orderby += (item.dir === 'asc') ? '>' : '<';
                            orderby += newModel.tableName + '.' + item.field + '%';
                        });
                    }
                    var query = _this.theGrid.getDataProvider().queryString;
                    var body = { Username: __WEBPACK_IMPORTED_MODULE_2_js44d__["b" /* FourDInterface */].currentUser };
                    body.TableName = newModel.tableName;
                    body.StartRec = start;
                    body.NumRecs = numrecs;
                    body.QueryString = JSON.stringify(query);
                    body.Columns = __WEBPACK_IMPORTED_MODULE_4_base_64__["encode"](__WEBPACK_IMPORTED_MODULE_5_utf8_utf8__["encode"](JSON.stringify(_this.listOfColumns)));
                    if (filter.length > 0) {
                        body.FilterOptions = JSON.stringify({ query: filter });
                    }
                    if (orderby) {
                        body.OrderBy = orderby;
                    }
                    _this.fourD.call4DRESTMethod('REST_GetRecords', body)
                        .subscribe(function (resultJSON) {
                        _this.totalRecordCount = 0;
                        _this.models = [];
                        if (resultJSON && resultJSON['selected'] && resultJSON['records']) {
                            _this.totalRecordCount = resultJSON['selected'];
                            var recList = resultJSON['records'];
                            recList.forEach(function (record) {
                                var theModel = new __WEBPACK_IMPORTED_MODULE_2_js44d__["c" /* FourDModel */]();
                                theModel.populateModelData(record);
                                _this.models.push(theModel);
                            });
                        }
                        _this.theGrid.getDataProvider().models = _this.models;
                        options.success(_this.models);
                    }, function (error) {
                        console.log('error:' + JSON.stringify(error));
                    });
                },
                destroy: function (options) {
                    console.log('delete', options);
                },
                update: function (options) {
                    console.log('update', options);
                },
                create: function (options) {
                    console.log('create', options);
                },
                parameterMap: function (options, operation) {
                    console.log('map', options);
                    if (operation !== 'read' && options.models) {
                        return { models: kendo.stringify(options.models) };
                    }
                    else {
                        return options;
                    }
                }
            },
            schema: {
                total: function (response) {
                    // console.log('total');
                    return _this.totalRecordCount;
                }
            },
            serverPaging: true,
            serverSorting: true,
            serverFiltering: true,
            serverGrouping: true,
            pageSize: 50
        });
    }
    BrowseTableComponent.prototype.ngAfterContentInit = function () {
        var _this = this;
        this.fourD.call4DRESTMethod('REST_GetListOfTables', {})
            .subscribe(function (resultJSON) {
            _this.numOfTables = resultJSON.tableCount;
            _this.listOfTables = resultJSON.tableList;
            _this.listOfTables.sort();
            _this.recordList.queryBand.switchState();
        });
    };
    BrowseTableComponent.prototype.hideConfig = function () {
        this.hideBrowseConfig = true;
        this.currentGridHeight = 'calc(100% - 30px)';
        this.recordList.theGrid.resize();
        this.recordList.refreshGrid();
    };
    BrowseTableComponent.prototype.showConfig = function () {
        this.hideBrowseConfig = false;
        this.currentGridHeight = 'calc(100% - 330px)';
        this.recordList.theGrid.resize();
        this.recordList.refreshGrid();
    };
    BrowseTableComponent.prototype.saveConfig = function () {
        if (this.currentTable !== '') {
            localStorage.setItem('4Dbrowse' + this.currentTable, JSON.stringify(this.listOfColumns));
        }
    };
    BrowseTableComponent.prototype.loadConfig = function () {
        if (this.currentTable !== '') {
            var config = localStorage.getItem('4Dbrowse' + this.currentTable);
            if (config && config !== '') {
                // we have a saved configuration, use it...
                this.listOfColumns = JSON.parse(config);
                this.mapColumnsToGrid(); // update grid then
            }
        }
    };
    BrowseTableComponent.prototype.selectTable = function (event) {
        var _this = this;
        if (this.selectedRow) {
            this.selectedRow.classList.remove('selectedItem');
        }
        var selectRow = event.currentTarget.rowIndex;
        if (selectRow < this.numOfTables) {
            this.selectedRow = event.target;
            this.currentTable = this.listOfTables[selectRow];
            this.listedTable = this.currentTable;
            this.fourD.call4DRESTMethod('REST_GetFieldsInTable', { TableName: this.listOfTables[selectRow] })
                .subscribe(function (resultJSON) {
                _this.listOfFields = resultJSON.fieldList;
                _this.selectedRow.classList.add('selectedItem');
                _this.model.prototype.tableName = _this.currentTable;
                _this.model.prototype.fields = _this.listOfFields;
                _this.model.prototype.primaryKey_ = resultJSON.primaryKey;
                // set default columns
                _this.listOfColumns = [];
                _this.relatedOneTables = [_this.currentTable];
                _this.queryData = {};
                for (var index = 0; index < _this.listOfFields.length; index++) {
                    var element = _this.listOfFields[index];
                    element.field = element.longname;
                    element.title = element.name;
                    if (element.indexed) {
                        element.quickQuery = true;
                        _this.listOfColumns.push(element);
                    }
                    else {
                        element.quickQuery = false;
                    }
                    if (element.relatesTo && element.relatesTo !== '') {
                        _this.relatedOneTables.push(element.relatesTo.split('.')[0]);
                    }
                }
                _this.mapColumnsToGrid(); // update datagrid columns
            });
        }
    };
    BrowseTableComponent.prototype.selectColumn = function (event) {
        if (this.selectedColumn) {
            this.selectedColumn.classList.remove('selectedItem');
        }
        this.selectedColumnIndex = event.currentTarget.rowIndex;
        if (this.selectedColumnIndex < this.listOfColumns.length) {
            this.selectedColumn = event.target;
            this.selectedColumn.classList.add('selectedItem');
            this.currentField = this.listOfColumns[this.selectedColumnIndex];
        }
        else {
            this.selectedColumnIndex = -1;
        }
    };
    BrowseTableComponent.prototype.startDrag = function (event, type) {
        event.effectAllowed = 'copy';
        event.dataTransfer.setData('type', type);
        event.dataTransfer.setData('row', event.currentTarget.rowIndex);
    };
    BrowseTableComponent.prototype.allowDrop = function (event) {
        if (event.preventDefault) {
            event.preventDefault();
        } // Necessary. Allows us to drop.
        if (event.stopPropagation) {
            event.stopPropagation();
        }
        if (event.type === 'dragenter') {
            event.target.classList.add('droppable');
            event.dataTransfer.dropEffect = 'copy'; // See the section on the DataTransfer object.
        }
        return false;
    };
    BrowseTableComponent.prototype.disableDrop = function (event) {
        if (event.stopPropagation) {
            event.stopPropagation();
        }
        event.target.classList.remove('droppable');
    };
    BrowseTableComponent.prototype.handleDrop = function (event) {
        if (event.stopPropagation) {
            event.stopPropagation();
        }
        this.disableDrop(event);
        var source = event.dataTransfer.getData('type');
        var row = event.dataTransfer.getData('row');
        var element = this.listOfFields[row];
        element.quickQuery = false;
        if (event.currentTarget.localName === 'tbody') {
            if (source === 'field') {
                this.listOfColumns.push(element);
            }
            else {
                this.listOfColumns.push(element);
                this.listOfColumns.splice(row, 1);
            }
        }
        else {
            if (source === 'field') {
                this.listOfColumns.splice(event.currentTarget.rowIndex, 0, element);
            }
            else {
                var moveToIndex = event.currentTarget.rowIndex;
                var item = this.listOfColumns.splice(row, 1);
                if (row < moveToIndex) {
                    // moving up...
                    this.listOfColumns.splice(event.currentTarget.rowIndex - 1, 0, item[0]);
                }
                else {
                    // moving down
                    this.listOfColumns.splice(event.currentTarget.rowIndex, 0, item[0]);
                }
            }
        }
        this.mapColumnsToGrid(); // update datagrid columns
    };
    BrowseTableComponent.prototype.deleteField = function () {
        if (this.selectedColumnIndex >= 0) {
            this.listOfColumns.splice(this.selectedColumnIndex, 1);
            this.selectedColumnIndex = -1;
            this.selectedColumn = null;
            this.currentField = new FieldDescription();
            this.mapColumnsToGrid();
        }
    };
    BrowseTableComponent.prototype.mapColumnsToGrid = function () {
        var _this = this;
        this.columnDefs = [];
        for (var index = 0; index < this.listOfColumns.length; index++) {
            var element = this.listOfColumns[index];
            this.columnDefs.push({ title: element.title, field: element.name, width: (element['width']) ? element['width'] : '' });
        }
        // this.theGrid.setColumnConfig(this.columnDefs);
        this.theGrid.setExternalDataSource(this.dataSource, this.columnDefs);
        this.recordList.clearQuery(); // clear any previous query
        this.theGrid.loadData(); // and clear the grid
        this.theGrid.gridObject.bind('columnResize', function () { _this.saveColumnConfig(); });
    };
    BrowseTableComponent.prototype.showRelatedTable = function (event) {
        var _this = this;
        this.listedTable = event.target.textContent;
        this.fourD.call4DRESTMethod('REST_GetFieldsInTable', { TableName: this.listedTable })
            .subscribe(function (resultJSON) {
            _this.listOfFields = resultJSON.fieldList;
            for (var index = 0; index < _this.listOfFields.length; index++) {
                var element = _this.listOfFields[index];
                element.field = element.longname;
                element.title = element.name;
                element.quickQuery = false;
            }
        });
    };
    BrowseTableComponent.prototype.addRecord = function () {
        var newModel = new __WEBPACK_IMPORTED_MODULE_2_js44d__["c" /* FourDModel */]();
        newModel.tableName = this.currentTable;
        newModel.fields = this.listOfFields;
        newModel.clearRecord();
        this.modal.openInside(this.editWindow, this.viewref, newModel, this.editWindow['dialogConfig']); // open edit dialog
    };
    BrowseTableComponent.prototype.noTableSelected = function () { return this.currentTable === ''; };
    BrowseTableComponent.prototype.saveColumnConfig = function () {
        if (this.currentTable !== '') {
            for (var i = 0; i < this.listOfColumns.length; i++) {
                if (this.theGrid.gridObject.columns[i]['width'] && this.theGrid.gridObject.columns[i]['width'] > 0) {
                    this.listOfColumns[i]['width'] = this.theGrid.gridObject.columns[i]['width'];
                }
            }
        }
    };
    BrowseTableComponent.dialogConfig = {
        actions: ['Maximize', 'Minimize', 'Close'], position: { top: 100, left: 50 }, selfCentered: true,
        title: 'Browse Table',
        isResizable: true,
        width: 1200, height: 800, minWidth: 1200, minHeight: 700
    };
    __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["E" /* Input */])(),
        __metadata("design:type", Object)
    ], BrowseTableComponent.prototype, "numOfTables", void 0);
    __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["E" /* Input */])(),
        __metadata("design:type", Array)
    ], BrowseTableComponent.prototype, "listOfTables", void 0);
    __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["E" /* Input */])(),
        __metadata("design:type", Object)
    ], BrowseTableComponent.prototype, "currentTable", void 0);
    __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["E" /* Input */])(),
        __metadata("design:type", Object)
    ], BrowseTableComponent.prototype, "listedTable", void 0);
    __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["E" /* Input */])(),
        __metadata("design:type", Array)
    ], BrowseTableComponent.prototype, "listOfFields", void 0);
    __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["E" /* Input */])(),
        __metadata("design:type", Array)
    ], BrowseTableComponent.prototype, "listOfColumns", void 0);
    __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["E" /* Input */])(),
        __metadata("design:type", Array)
    ], BrowseTableComponent.prototype, "relatedOneTables", void 0);
    __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["E" /* Input */])(),
        __metadata("design:type", FieldDescription)
    ], BrowseTableComponent.prototype, "currentField", void 0);
    __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["E" /* Input */])(),
        __metadata("design:type", Object)
    ], BrowseTableComponent.prototype, "queryData", void 0);
    __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["E" /* Input */])(),
        __metadata("design:type", Object)
    ], BrowseTableComponent.prototype, "hideBrowseConfig", void 0);
    __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["E" /* Input */])(),
        __metadata("design:type", Object)
    ], BrowseTableComponent.prototype, "currentGridHeight", void 0);
    __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["_11" /* ViewChild */])(__WEBPACK_IMPORTED_MODULE_2_js44d__["k" /* RecordList */]),
        __metadata("design:type", __WEBPACK_IMPORTED_MODULE_2_js44d__["k" /* RecordList */])
    ], BrowseTableComponent.prototype, "recordList", void 0);
    __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["_11" /* ViewChild */])(__WEBPACK_IMPORTED_MODULE_2_js44d__["a" /* DataGrid */]),
        __metadata("design:type", __WEBPACK_IMPORTED_MODULE_2_js44d__["a" /* DataGrid */])
    ], BrowseTableComponent.prototype, "theGrid", void 0);
    BrowseTableComponent = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["n" /* Component */])({
            moduleId: module.i,
            selector: 'sd-browse-table',
            template: __webpack_require__("../../../../../src/app/browseTable/browseTable.component.html"),
            styles: [__webpack_require__("../../../../../src/app/browseTable/browseTable.component.css")],
            providers: [__WEBPACK_IMPORTED_MODULE_1__angular_common_http__["a" /* HttpClient */], __WEBPACK_IMPORTED_MODULE_2_js44d__["b" /* FourDInterface */], __WEBPACK_IMPORTED_MODULE_2_js44d__["g" /* Modal */]]
        }),
        __metadata("design:paramtypes", [__WEBPACK_IMPORTED_MODULE_1__angular_common_http__["a" /* HttpClient */], __WEBPACK_IMPORTED_MODULE_2_js44d__["b" /* FourDInterface */], __WEBPACK_IMPORTED_MODULE_2_js44d__["g" /* Modal */], __WEBPACK_IMPORTED_MODULE_0__angular_core__["_12" /* ViewContainerRef */]])
    ], BrowseTableComponent);
    return BrowseTableComponent;
}());



/***/ }),

/***/ "../../../../../src/app/browseTable/browseTable.module.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "BrowseRoutes", function() { return BrowseRoutes; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "BrowseTableModule", function() { return BrowseTableModule; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("../../../core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__angular_common__ = __webpack_require__("../../../common/esm5/common.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__angular_forms__ = __webpack_require__("../../../forms/esm5/forms.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__angular_router__ = __webpack_require__("../../../router/esm5/router.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__angular_common_http__ = __webpack_require__("../../../common/esm5/http.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__browseTableDialog_component__ = __webpack_require__("../../../../../src/app/browseTable/browseTableDialog.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6__browseTable_component__ = __webpack_require__("../../../../../src/app/browseTable/browseTable.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_7__browseQuery_component__ = __webpack_require__("../../../../../src/app/browseTable/browseQuery.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_8__browseQueryField_component__ = __webpack_require__("../../../../../src/app/browseTable/browseQueryField.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_9__browseInputField_component__ = __webpack_require__("../../../../../src/app/browseTable/browseInputField.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_10__browseFormDialog_component__ = __webpack_require__("../../../../../src/app/browseTable/browseFormDialog.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_11__browseFieldDialog_component__ = __webpack_require__("../../../../../src/app/browseTable/browseFieldDialog.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_12_js44d__ = __webpack_require__("../../../../js44d/js44d.es5.js");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};












// feature modules



var BrowseRoutes = [
    {
        path: '',
        component: __WEBPACK_IMPORTED_MODULE_5__browseTableDialog_component__["a" /* BrowseTableDialog */]
    }
];
var BrowseTableModule = /** @class */ (function () {
    function BrowseTableModule() {
    }
    BrowseTableModule = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["J" /* NgModule */])({
            imports: [
                __WEBPACK_IMPORTED_MODULE_1__angular_common__["b" /* CommonModule */],
                __WEBPACK_IMPORTED_MODULE_2__angular_forms__["b" /* FormsModule */],
                __WEBPACK_IMPORTED_MODULE_4__angular_common_http__["b" /* HttpClientModule */],
                __WEBPACK_IMPORTED_MODULE_3__angular_router__["b" /* RouterModule */].forChild(BrowseRoutes),
                __WEBPACK_IMPORTED_MODULE_12_js44d__["d" /* FourDModule */], __WEBPACK_IMPORTED_MODULE_12_js44d__["e" /* JS44DModule */], __WEBPACK_IMPORTED_MODULE_12_js44d__["i" /* ModalModule */]
            ],
            providers: [__WEBPACK_IMPORTED_MODULE_4__angular_common_http__["a" /* HttpClient */]],
            declarations: [__WEBPACK_IMPORTED_MODULE_5__browseTableDialog_component__["a" /* BrowseTableDialog */], __WEBPACK_IMPORTED_MODULE_6__browseTable_component__["a" /* BrowseTableComponent */], __WEBPACK_IMPORTED_MODULE_7__browseQuery_component__["a" /* BrowseQueryBand */], __WEBPACK_IMPORTED_MODULE_8__browseQueryField_component__["a" /* BrowseQueryField */],
                __WEBPACK_IMPORTED_MODULE_10__browseFormDialog_component__["a" /* BrowseFormDialog */], __WEBPACK_IMPORTED_MODULE_9__browseInputField_component__["a" /* BrowseInputField */], __WEBPACK_IMPORTED_MODULE_11__browseFieldDialog_component__["a" /* BrowseFieldDialog */]],
            entryComponents: [__WEBPACK_IMPORTED_MODULE_10__browseFormDialog_component__["a" /* BrowseFormDialog */], __WEBPACK_IMPORTED_MODULE_6__browseTable_component__["a" /* BrowseTableComponent */], __WEBPACK_IMPORTED_MODULE_11__browseFieldDialog_component__["a" /* BrowseFieldDialog */]]
        })
    ], BrowseTableModule);
    return BrowseTableModule;
}());



/***/ }),

/***/ "../../../../../src/app/browseTable/browseTableDialog.component.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return BrowseTableDialog; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("../../../core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__angular_router__ = __webpack_require__("../../../router/esm5/router.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_js44d__ = __webpack_require__("../../../../js44d/js44d.es5.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__browseTable_component__ = __webpack_require__("../../../../../src/app/browseTable/browseTable.component.ts");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};




var BrowseTableDialog = /** @class */ (function () {
    function BrowseTableDialog(modal, router, elementRef, viewRef) {
        this.modal = modal;
        this.router = router;
        this.elementRef = elementRef;
        this.viewRef = viewRef;
    }
    /**
     * AFter our view gets initialized, subscribe to various events on the Query band and the Grid
     */
    BrowseTableDialog.prototype.ngAfterContentInit = function () {
        this.router.navigate(['/blank'], { skipLocationChange: true });
        this.modal.openDialog(__WEBPACK_IMPORTED_MODULE_3__browseTable_component__["a" /* BrowseTableComponent */], {});
    };
    BrowseTableDialog = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["n" /* Component */])({
            selector: 'browse-table-dialog',
            template: '<div></div>',
            providers: [__WEBPACK_IMPORTED_MODULE_2_js44d__["g" /* Modal */]]
        }),
        __metadata("design:paramtypes", [__WEBPACK_IMPORTED_MODULE_2_js44d__["g" /* Modal */], __WEBPACK_IMPORTED_MODULE_1__angular_router__["a" /* Router */], __WEBPACK_IMPORTED_MODULE_0__angular_core__["u" /* ElementRef */], __WEBPACK_IMPORTED_MODULE_0__angular_core__["_12" /* ViewContainerRef */]])
    ], BrowseTableDialog);
    return BrowseTableDialog;
}());



/***/ }),

/***/ "../../../../base-64/base64.js":
/***/ (function(module, exports, __webpack_require__) {

/* WEBPACK VAR INJECTION */(function(module, global) {var __WEBPACK_AMD_DEFINE_RESULT__;/*! http://mths.be/base64 v0.1.0 by @mathias | MIT license */
;(function(root) {

	// Detect free variables `exports`.
	var freeExports = typeof exports == 'object' && exports;

	// Detect free variable `module`.
	var freeModule = typeof module == 'object' && module &&
		module.exports == freeExports && module;

	// Detect free variable `global`, from Node.js or Browserified code, and use
	// it as `root`.
	var freeGlobal = typeof global == 'object' && global;
	if (freeGlobal.global === freeGlobal || freeGlobal.window === freeGlobal) {
		root = freeGlobal;
	}

	/*--------------------------------------------------------------------------*/

	var InvalidCharacterError = function(message) {
		this.message = message;
	};
	InvalidCharacterError.prototype = new Error;
	InvalidCharacterError.prototype.name = 'InvalidCharacterError';

	var error = function(message) {
		// Note: the error messages used throughout this file match those used by
		// the native `atob`/`btoa` implementation in Chromium.
		throw new InvalidCharacterError(message);
	};

	var TABLE = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/';
	// http://whatwg.org/html/common-microsyntaxes.html#space-character
	var REGEX_SPACE_CHARACTERS = /[\t\n\f\r ]/g;

	// `decode` is designed to be fully compatible with `atob` as described in the
	// HTML Standard. http://whatwg.org/html/webappapis.html#dom-windowbase64-atob
	// The optimized base64-decoding algorithm used is based on @atk’s excellent
	// implementation. https://gist.github.com/atk/1020396
	var decode = function(input) {
		input = String(input)
			.replace(REGEX_SPACE_CHARACTERS, '');
		var length = input.length;
		if (length % 4 == 0) {
			input = input.replace(/==?$/, '');
			length = input.length;
		}
		if (
			length % 4 == 1 ||
			// http://whatwg.org/C#alphanumeric-ascii-characters
			/[^+a-zA-Z0-9/]/.test(input)
		) {
			error(
				'Invalid character: the string to be decoded is not correctly encoded.'
			);
		}
		var bitCounter = 0;
		var bitStorage;
		var buffer;
		var output = '';
		var position = -1;
		while (++position < length) {
			buffer = TABLE.indexOf(input.charAt(position));
			bitStorage = bitCounter % 4 ? bitStorage * 64 + buffer : buffer;
			// Unless this is the first of a group of 4 characters…
			if (bitCounter++ % 4) {
				// …convert the first 8 bits to a single ASCII character.
				output += String.fromCharCode(
					0xFF & bitStorage >> (-2 * bitCounter & 6)
				);
			}
		}
		return output;
	};

	// `encode` is designed to be fully compatible with `btoa` as described in the
	// HTML Standard: http://whatwg.org/html/webappapis.html#dom-windowbase64-btoa
	var encode = function(input) {
		input = String(input);
		if (/[^\0-\xFF]/.test(input)) {
			// Note: no need to special-case astral symbols here, as surrogates are
			// matched, and the input is supposed to only contain ASCII anyway.
			error(
				'The string to be encoded contains characters outside of the ' +
				'Latin1 range.'
			);
		}
		var padding = input.length % 3;
		var output = '';
		var position = -1;
		var a;
		var b;
		var c;
		var d;
		var buffer;
		// Make sure any padding is handled outside of the loop.
		var length = input.length - padding;

		while (++position < length) {
			// Read three bytes, i.e. 24 bits.
			a = input.charCodeAt(position) << 16;
			b = input.charCodeAt(++position) << 8;
			c = input.charCodeAt(++position);
			buffer = a + b + c;
			// Turn the 24 bits into four chunks of 6 bits each, and append the
			// matching character for each of them to the output.
			output += (
				TABLE.charAt(buffer >> 18 & 0x3F) +
				TABLE.charAt(buffer >> 12 & 0x3F) +
				TABLE.charAt(buffer >> 6 & 0x3F) +
				TABLE.charAt(buffer & 0x3F)
			);
		}

		if (padding == 2) {
			a = input.charCodeAt(position) << 8;
			b = input.charCodeAt(++position);
			buffer = a + b;
			output += (
				TABLE.charAt(buffer >> 10) +
				TABLE.charAt((buffer >> 4) & 0x3F) +
				TABLE.charAt((buffer << 2) & 0x3F) +
				'='
			);
		} else if (padding == 1) {
			buffer = input.charCodeAt(position);
			output += (
				TABLE.charAt(buffer >> 2) +
				TABLE.charAt((buffer << 4) & 0x3F) +
				'=='
			);
		}

		return output;
	};

	var base64 = {
		'encode': encode,
		'decode': decode,
		'version': '0.1.0'
	};

	// Some AMD build optimizers, like r.js, check for specific condition patterns
	// like the following:
	if (
		true
	) {
		!(__WEBPACK_AMD_DEFINE_RESULT__ = function() {
			return base64;
		}.call(exports, __webpack_require__, exports, module),
				__WEBPACK_AMD_DEFINE_RESULT__ !== undefined && (module.exports = __WEBPACK_AMD_DEFINE_RESULT__));
	}	else if (freeExports && !freeExports.nodeType) {
		if (freeModule) { // in Node.js or RingoJS v0.8.0+
			freeModule.exports = base64;
		} else { // in Narwhal or RingoJS v0.7.0-
			for (var key in base64) {
				base64.hasOwnProperty(key) && (freeExports[key] = base64[key]);
			}
		}
	} else { // in Rhino or a web browser
		root.base64 = base64;
	}

}(this));

/* WEBPACK VAR INJECTION */}.call(exports, __webpack_require__("../../../../webpack/buildin/module.js")(module), __webpack_require__("../../../../webpack/buildin/global.js")))

/***/ }),

/***/ "../../../../utf8/utf8.js":
/***/ (function(module, exports, __webpack_require__) {

/*! https://mths.be/utf8js v3.0.0 by @mathias */
;(function(root) {

	var stringFromCharCode = String.fromCharCode;

	// Taken from https://mths.be/punycode
	function ucs2decode(string) {
		var output = [];
		var counter = 0;
		var length = string.length;
		var value;
		var extra;
		while (counter < length) {
			value = string.charCodeAt(counter++);
			if (value >= 0xD800 && value <= 0xDBFF && counter < length) {
				// high surrogate, and there is a next character
				extra = string.charCodeAt(counter++);
				if ((extra & 0xFC00) == 0xDC00) { // low surrogate
					output.push(((value & 0x3FF) << 10) + (extra & 0x3FF) + 0x10000);
				} else {
					// unmatched surrogate; only append this code unit, in case the next
					// code unit is the high surrogate of a surrogate pair
					output.push(value);
					counter--;
				}
			} else {
				output.push(value);
			}
		}
		return output;
	}

	// Taken from https://mths.be/punycode
	function ucs2encode(array) {
		var length = array.length;
		var index = -1;
		var value;
		var output = '';
		while (++index < length) {
			value = array[index];
			if (value > 0xFFFF) {
				value -= 0x10000;
				output += stringFromCharCode(value >>> 10 & 0x3FF | 0xD800);
				value = 0xDC00 | value & 0x3FF;
			}
			output += stringFromCharCode(value);
		}
		return output;
	}

	function checkScalarValue(codePoint) {
		if (codePoint >= 0xD800 && codePoint <= 0xDFFF) {
			throw Error(
				'Lone surrogate U+' + codePoint.toString(16).toUpperCase() +
				' is not a scalar value'
			);
		}
	}
	/*--------------------------------------------------------------------------*/

	function createByte(codePoint, shift) {
		return stringFromCharCode(((codePoint >> shift) & 0x3F) | 0x80);
	}

	function encodeCodePoint(codePoint) {
		if ((codePoint & 0xFFFFFF80) == 0) { // 1-byte sequence
			return stringFromCharCode(codePoint);
		}
		var symbol = '';
		if ((codePoint & 0xFFFFF800) == 0) { // 2-byte sequence
			symbol = stringFromCharCode(((codePoint >> 6) & 0x1F) | 0xC0);
		}
		else if ((codePoint & 0xFFFF0000) == 0) { // 3-byte sequence
			checkScalarValue(codePoint);
			symbol = stringFromCharCode(((codePoint >> 12) & 0x0F) | 0xE0);
			symbol += createByte(codePoint, 6);
		}
		else if ((codePoint & 0xFFE00000) == 0) { // 4-byte sequence
			symbol = stringFromCharCode(((codePoint >> 18) & 0x07) | 0xF0);
			symbol += createByte(codePoint, 12);
			symbol += createByte(codePoint, 6);
		}
		symbol += stringFromCharCode((codePoint & 0x3F) | 0x80);
		return symbol;
	}

	function utf8encode(string) {
		var codePoints = ucs2decode(string);
		var length = codePoints.length;
		var index = -1;
		var codePoint;
		var byteString = '';
		while (++index < length) {
			codePoint = codePoints[index];
			byteString += encodeCodePoint(codePoint);
		}
		return byteString;
	}

	/*--------------------------------------------------------------------------*/

	function readContinuationByte() {
		if (byteIndex >= byteCount) {
			throw Error('Invalid byte index');
		}

		var continuationByte = byteArray[byteIndex] & 0xFF;
		byteIndex++;

		if ((continuationByte & 0xC0) == 0x80) {
			return continuationByte & 0x3F;
		}

		// If we end up here, it’s not a continuation byte
		throw Error('Invalid continuation byte');
	}

	function decodeSymbol() {
		var byte1;
		var byte2;
		var byte3;
		var byte4;
		var codePoint;

		if (byteIndex > byteCount) {
			throw Error('Invalid byte index');
		}

		if (byteIndex == byteCount) {
			return false;
		}

		// Read first byte
		byte1 = byteArray[byteIndex] & 0xFF;
		byteIndex++;

		// 1-byte sequence (no continuation bytes)
		if ((byte1 & 0x80) == 0) {
			return byte1;
		}

		// 2-byte sequence
		if ((byte1 & 0xE0) == 0xC0) {
			byte2 = readContinuationByte();
			codePoint = ((byte1 & 0x1F) << 6) | byte2;
			if (codePoint >= 0x80) {
				return codePoint;
			} else {
				throw Error('Invalid continuation byte');
			}
		}

		// 3-byte sequence (may include unpaired surrogates)
		if ((byte1 & 0xF0) == 0xE0) {
			byte2 = readContinuationByte();
			byte3 = readContinuationByte();
			codePoint = ((byte1 & 0x0F) << 12) | (byte2 << 6) | byte3;
			if (codePoint >= 0x0800) {
				checkScalarValue(codePoint);
				return codePoint;
			} else {
				throw Error('Invalid continuation byte');
			}
		}

		// 4-byte sequence
		if ((byte1 & 0xF8) == 0xF0) {
			byte2 = readContinuationByte();
			byte3 = readContinuationByte();
			byte4 = readContinuationByte();
			codePoint = ((byte1 & 0x07) << 0x12) | (byte2 << 0x0C) |
				(byte3 << 0x06) | byte4;
			if (codePoint >= 0x010000 && codePoint <= 0x10FFFF) {
				return codePoint;
			}
		}

		throw Error('Invalid UTF-8 detected');
	}

	var byteArray;
	var byteCount;
	var byteIndex;
	function utf8decode(byteString) {
		byteArray = ucs2decode(byteString);
		byteCount = byteArray.length;
		byteIndex = 0;
		var codePoints = [];
		var tmp;
		while ((tmp = decodeSymbol()) !== false) {
			codePoints.push(tmp);
		}
		return ucs2encode(codePoints);
	}

	/*--------------------------------------------------------------------------*/

	root.version = '3.0.0';
	root.encode = utf8encode;
	root.decode = utf8decode;

}( false ? this.utf8 = {} : exports));


/***/ }),

/***/ "../../../../webpack/buildin/module.js":
/***/ (function(module, exports) {

module.exports = function(module) {
	if(!module.webpackPolyfill) {
		module.deprecate = function() {};
		module.paths = [];
		// module.parent = undefined by default
		if(!module.children) module.children = [];
		Object.defineProperty(module, "loaded", {
			enumerable: true,
			get: function() {
				return module.l;
			}
		});
		Object.defineProperty(module, "id", {
			enumerable: true,
			get: function() {
				return module.i;
			}
		});
		module.webpackPolyfill = 1;
	}
	return module;
};


/***/ })

});
//# sourceMappingURL=browseTable.module.chunk.js.map