(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["main"],{

/***/ "./src/$$_lazy_route_resource lazy recursive":
/*!**********************************************************!*\
  !*** ./src/$$_lazy_route_resource lazy namespace object ***!
  \**********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var map = {
	"app/browseTable/browseTable.module": [
		"./src/app/browseTable/browseTable.module.ts",
		"app-browseTable-browseTable-module"
	],
	"app/listEditor/listEditor.module": [
		"./src/app/listEditor/listEditor.module.ts",
		"app-listEditor-listEditor-module"
	]
};
function webpackAsyncContext(req) {
	var ids = map[req];
	if(!ids) {
		return Promise.resolve().then(function() {
			var e = new Error('Cannot find module "' + req + '".');
			e.code = 'MODULE_NOT_FOUND';
			throw e;
		});
	}
	return __webpack_require__.e(ids[1]).then(function() {
		var module = __webpack_require__(ids[0]);
		return module;
	});
}
webpackAsyncContext.keys = function webpackAsyncContextKeys() {
	return Object.keys(map);
};
webpackAsyncContext.id = "./src/$$_lazy_route_resource lazy recursive";
module.exports = webpackAsyncContext;

/***/ }),

/***/ "./src/app/common/index.ts":
/*!*********************************!*\
  !*** ./src/app/common/index.ts ***!
  \*********************************/
/*! exports provided: Config, RouterModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _utils_index__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./utils/index */ "./src/app/common/utils/index.ts");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "Config", function() { return _utils_index__WEBPACK_IMPORTED_MODULE_0__["Config"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "RouterModule", function() { return _utils_index__WEBPACK_IMPORTED_MODULE_0__["RouterModule"]; });




/***/ }),

/***/ "./src/app/common/utils/Config.ts":
/*!****************************************!*\
  !*** ./src/app/common/utils/Config.ts ***!
  \****************************************/
/*! exports provided: Config */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Config", function() { return Config; });
var Config = /** @class */ (function () {
    function Config() {
    }
    Object.defineProperty(Config, "IS_WEB", {
        get: function () {
            return Config.PLATFORM_TARGET === Config.PLATFORMS.WEB;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(Config, "IS_MOBILE_NATIVE", {
        get: function () {
            return Config.PLATFORM_TARGET === Config.PLATFORMS.MOBILE_NATIVE;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(Config, "APP_VERSION", {
        get: function () {
            return '1.18.02.22a';
        },
        enumerable: true,
        configurable: true
    });
    // supported platforms
    Config.PLATFORMS = {
        WEB: 'web',
        MOBILE_NATIVE: 'mobile_native'
    };
    // current target (defaults to web)
    Config.PLATFORM_TARGET = Config.PLATFORMS.WEB;
    return Config;
}());



/***/ }),

/***/ "./src/app/common/utils/index.ts":
/*!***************************************!*\
  !*** ./src/app/common/utils/index.ts ***!
  \***************************************/
/*! exports provided: Config, RouterModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _Config__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./Config */ "./src/app/common/utils/Config.ts");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "Config", function() { return _Config__WEBPACK_IMPORTED_MODULE_0__["Config"]; });

/* harmony import */ var _router_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./router-module */ "./src/app/common/utils/router-module.ts");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "RouterModule", function() { return _router_module__WEBPACK_IMPORTED_MODULE_1__["RouterModule"]; });





/***/ }),

/***/ "./src/app/common/utils/router-module.ts":
/*!***********************************************!*\
  !*** ./src/app/common/utils/router-module.ts ***!
  \***********************************************/
/*! exports provided: RouterModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "RouterModule", function() { return _angular_router__WEBPACK_IMPORTED_MODULE_0__["RouterModule"]; });




/***/ }),

/***/ "./src/app/fourDAdmin.web.module.ts":
/*!******************************************!*\
  !*** ./src/app/fourDAdmin.web.module.ts ***!
  \******************************************/
/*! exports provided: WebModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "WebModule", function() { return WebModule; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/platform-browser */ "./node_modules/@angular/platform-browser/fesm5/platform-browser.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
/* harmony import */ var _fourDAdmin_fourDAdmin_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./fourDAdmin/fourDAdmin.component */ "./src/app/fourDAdmin/fourDAdmin.component.ts");
/* harmony import */ var _fourDAdmin_blankPage__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./fourDAdmin/blankPage */ "./src/app/fourDAdmin/blankPage.ts");
/* harmony import */ var _login_login_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./login/login.component */ "./src/app/login/login.component.ts");
/* harmony import */ var js44d__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! js44d */ "./node_modules/js44d/fesm5/js44d.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
// angular






// app


// applets


// feature modules

var routerModule = _angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forRoot(_fourDAdmin_fourDAdmin_component__WEBPACK_IMPORTED_MODULE_6__["routes"]);
var WebModule = /** @class */ (function () {
    function WebModule() {
    }
    WebModule = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["NgModule"])({
            imports: [
                _angular_platform_browser__WEBPACK_IMPORTED_MODULE_1__["BrowserModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
                _angular_common__WEBPACK_IMPORTED_MODULE_4__["CommonModule"],
                _angular_common_http__WEBPACK_IMPORTED_MODULE_5__["HttpClientModule"],
                routerModule,
                js44d__WEBPACK_IMPORTED_MODULE_9__["FourDModule"], js44d__WEBPACK_IMPORTED_MODULE_9__["JS44DModule"], js44d__WEBPACK_IMPORTED_MODULE_9__["ModalModule"]
            ],
            declarations: [_fourDAdmin_fourDAdmin_component__WEBPACK_IMPORTED_MODULE_6__["FourDAdminComponent"], _fourDAdmin_blankPage__WEBPACK_IMPORTED_MODULE_7__["BlankPage"], _login_login_component__WEBPACK_IMPORTED_MODULE_8__["LoginComponent"]
            ],
            exports: [js44d__WEBPACK_IMPORTED_MODULE_9__["FourDModule"], js44d__WEBPACK_IMPORTED_MODULE_9__["JS44DModule"], js44d__WEBPACK_IMPORTED_MODULE_9__["ModalModule"]],
            entryComponents: [_login_login_component__WEBPACK_IMPORTED_MODULE_8__["LoginComponent"]],
            bootstrap: [_fourDAdmin_fourDAdmin_component__WEBPACK_IMPORTED_MODULE_6__["FourDAdminComponent"]]
        })
    ], WebModule);
    return WebModule;
}());



/***/ }),

/***/ "./src/app/fourDAdmin/blankPage.ts":
/*!*****************************************!*\
  !*** ./src/app/fourDAdmin/blankPage.ts ***!
  \*****************************************/
/*! exports provided: BlankPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "BlankPage", function() { return BlankPage; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};

var BlankPage = /** @class */ (function () {
    function BlankPage() {
    }
    BlankPage = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            moduleId: module.i,
            selector: 'sd-blank',
            template: '<div></div>'
        })
    ], BlankPage);
    return BlankPage;
}());



/***/ }),

/***/ "./src/app/fourDAdmin/fourDAdmin.component.css":
/*!*****************************************************!*\
  !*** ./src/app/fourDAdmin/fourDAdmin.component.css ***!
  \*****************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "nav a {\n  color: #106cc8;\n  font-size: 14px;\n  font-weight: 500;\n  line-height: 48px;\n  margin-right: 20px;\n  text-decoration: none;\n  vertical-align: middle;\n}\n\nnav a:hover,\nnav a:focus {\n    color: #23527c;\n    font-size: 15px;\n    font-weight: 900;\n}\n"

/***/ }),

/***/ "./src/app/fourDAdmin/fourDAdmin.component.html":
/*!******************************************************!*\
  !*** ./src/app/fourDAdmin/fourDAdmin.component.html ***!
  \******************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div platform>\n\n    <!-- This is our Header, with the web apps drop down -->\n    <header [hidden]=\"!userIsLoggedIn\">\n        <div style=\"height: 100px;\">\n                <img src=\"./assets/icons/LogoPascal.png\" style=\"display: inline-block;vertical-align: top; margin-right:20px; height: 100%;\"/>\n                <span style=\"display:inline-block; padding-left:40px; height:100% \">\n                    <label class=\"fieldPromptBold\" style=\"font-size:32pt;\">Welcome {{currentUser}}</label>\n                    <nav style=\"margin:-5px;\">\n                        <a *ngFor=\"let menuItem of menuList\" (click)=\"openApp(menuItem)\">{{menuItem.title}}</a>\n                        <a (click)=\"doLogin();\" style=\"padding-left:50px;\">Logout</a>\n                    </nav>\n                </span>\n\n        </div>\n\n    </header>\n \n  <router-outlet></router-outlet>\n\n</div>\n"

/***/ }),

/***/ "./src/app/fourDAdmin/fourDAdmin.component.ts":
/*!****************************************************!*\
  !*** ./src/app/fourDAdmin/fourDAdmin.component.ts ***!
  \****************************************************/
/*! exports provided: routes, FourDAdminComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "routes", function() { return routes; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "FourDAdminComponent", function() { return FourDAdminComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _common_index__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../common/index */ "./src/app/common/index.ts");
/* harmony import */ var _login_login_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../login/login.component */ "./src/app/login/login.component.ts");
/* harmony import */ var js44d__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! js44d */ "./node_modules/js44d/fesm5/js44d.js");
/* harmony import */ var _blankPage__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./blankPage */ "./src/app/fourDAdmin/blankPage.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};







var routes = [
    { path: 'login', component: _blankPage__WEBPACK_IMPORTED_MODULE_5__["BlankPage"] },
    { path: 'browseTable', loadChildren: 'app/browseTable/browseTable.module#BrowseTableModule' },
    { path: 'listEditor', loadChildren: 'app/listEditor/listEditor.module#ListEditorModule' },
    { path: '**', component: _blankPage__WEBPACK_IMPORTED_MODULE_5__["BlankPage"] }
];
var FourDAdminComponent = /** @class */ (function () {
    function FourDAdminComponent(router, modal, viewref) {
        this.router = router;
        this.modal = modal;
        this.viewref = viewref;
        this.menuList = [
            {
                routePath: '/browseTable',
                title: 'Browse Table'
            },
            {
                routePath: '/listEditor',
                title: 'List Editor'
            },
        ];
        if (window.location.hostname === 'localhost' && window.location.port === '4200') {
            js44d__WEBPACK_IMPORTED_MODULE_4__["FourDInterface"].fourDUrl = 'http://www.vakeano.com';
            // FourDInterface.fourDUrl = 'http://localhost:8080';   
            //FourDInterface.fourDUrl = 'http://10.211.55.8:8181';   
        }
        else {
            js44d__WEBPACK_IMPORTED_MODULE_4__["FourDInterface"].fourDUrl = window.location.origin;
        }
        js44d__WEBPACK_IMPORTED_MODULE_4__["Modal"].hostViewRef = this.viewref;
    }
    Object.defineProperty(FourDAdminComponent.prototype, "currentUser", {
        get: function () {
            return (js44d__WEBPACK_IMPORTED_MODULE_4__["FourDInterface"].authentication) ? js44d__WEBPACK_IMPORTED_MODULE_4__["FourDInterface"].currentUser : '?';
        },
        enumerable: true,
        configurable: true
    });
    FourDAdminComponent.prototype.ngAfterContentInit = function () {
        // no predefined user, login...
        if (_common_index__WEBPACK_IMPORTED_MODULE_2__["Config"].PLATFORM_TARGET === _common_index__WEBPACK_IMPORTED_MODULE_2__["Config"].PLATFORMS.WEB) {
            this.showLoginDialog();
        }
    };
    FourDAdminComponent.prototype.userHasLoggedIn = function () {
        // load current profile user functions
        if (this.userIsLoggedIn) {
            js44d__WEBPACK_IMPORTED_MODULE_4__["FourDInterface"].runningInsideWorkspace = true; // we are indeed running inside the workspace
        }
    };
    Object.defineProperty(FourDAdminComponent.prototype, "userIsLoggedIn", {
        get: function () { return js44d__WEBPACK_IMPORTED_MODULE_4__["FourDInterface"].authentication !== undefined && js44d__WEBPACK_IMPORTED_MODULE_4__["FourDInterface"].authentication !== null; },
        enumerable: true,
        configurable: true
    });
    FourDAdminComponent.prototype.doLogin = function () {
        js44d__WEBPACK_IMPORTED_MODULE_4__["FourDInterface"].authentication = null;
        this.router.navigate(['/login'], { skipLocationChange: true });
        if (_common_index__WEBPACK_IMPORTED_MODULE_2__["Config"].PLATFORM_TARGET === _common_index__WEBPACK_IMPORTED_MODULE_2__["Config"].PLATFORMS.WEB) {
            this.showLoginDialog();
        }
    };
    FourDAdminComponent.prototype.showLoginDialog = function () {
        var _this = this;
        this.modal.openInside(_login_login_component__WEBPACK_IMPORTED_MODULE_3__["LoginComponent"], this.viewref, null, _login_login_component__WEBPACK_IMPORTED_MODULE_3__["LoginComponent"]['dialogConfig'])
            .then(function (result) {
            _this.userHasLoggedIn();
        });
    };
    FourDAdminComponent.prototype.openApp = function (menu) {
        if (js44d__WEBPACK_IMPORTED_MODULE_4__["FourDInterface"].authentication) {
            this.router.navigate([menu.routePath], { skipLocationChange: true });
        }
    };
    FourDAdminComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            moduleId: module.i,
            selector: 'sd-fourdadmin',
            providers: [js44d__WEBPACK_IMPORTED_MODULE_4__["Modal"], js44d__WEBPACK_IMPORTED_MODULE_4__["FourDInterface"]],
            template: __webpack_require__(/*! ./fourDAdmin.component.html */ "./src/app/fourDAdmin/fourDAdmin.component.html"),
            styles: [__webpack_require__(/*! ./fourDAdmin.component.css */ "./src/app/fourDAdmin/fourDAdmin.component.css")]
        }),
        __metadata("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_1__["Router"], js44d__WEBPACK_IMPORTED_MODULE_4__["Modal"], _angular_core__WEBPACK_IMPORTED_MODULE_0__["ViewContainerRef"]])
    ], FourDAdminComponent);
    return FourDAdminComponent;
}());



/***/ }),

/***/ "./src/app/login/login.component.css":
/*!*******************************************!*\
  !*** ./src/app/login/login.component.css ***!
  \*******************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".login {\n    width: 1070px !important;\n    background: url('login_splash.png');\n    background-repeat: no-repeat;\n    height: 670px !important;\n    padding-left: 200px;\n    padding-top: 200px;\n}\n"

/***/ }),

/***/ "./src/app/login/login.component.html":
/*!********************************************!*\
  !*** ./src/app/login/login.component.html ***!
  \********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "    <div class=\"login container\">\n        <form class=\"form-vertical\" role=\"form\" (submit)=\"login()\">\n            <label style=\"padding-bottom:40px;font-size:32pt;font-weight:bold;color:#7F7F6F;\">Welcome to FourD Admin</label>\n            <div class=\"form-group\" style=\"margin-left: 20px;\">\n                <label class=\"fieldPrompt\" style=\"font-weight:bold;width:90px;\" for=\"username\">User Name</label>\n                <input type=\"text\" class=\"fieldEntry\" style=\"width:300px;\" id=\"username\" name=\"username\" placeholder=\"Username\" [(ngModel)]=\"username\" (focus)=\"showError = false;\">\n            </div>\n            <div class=\"form-group\" style=\"margin-left: 20px;\">\n                <label class=\"fieldPrompt\" style=\"font-weight:bold;width:90px;\" for=\"password\">Password</label>\n                <input type=\"password\" class=\"fieldEntry\" style=\"width:300px;\" id=\"password\" name=\"password\" placeholder=\"Password\" [(ngModel)]=\"password\">\n            </div>\n            <button type=\"submit\" class=\"regularButton\" style=\"width:100px;margin-left: 30px;\">Login</button>\n        </form>\n        <div class=\"alert alert-warning\" style=\"width: 500px;\" [hidden]=\"!showError\">Sorry, the username and/or password was incorrect</div>\n\n        <div style=\"color:green;margin-top:100px;\">4D: {{fourDVersion}}, web: {{webAppVersion}}</div>\n    </div>\n\n"

/***/ }),

/***/ "./src/app/login/login.component.ts":
/*!******************************************!*\
  !*** ./src/app/login/login.component.ts ***!
  \******************************************/
/*! exports provided: LoginComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LoginComponent", function() { return LoginComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _common_index__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../common/index */ "./src/app/common/index.ts");
/* harmony import */ var js44d__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! js44d */ "./node_modules/js44d/fesm5/js44d.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};




var LoginComponent = /** @class */ (function () {
    function LoginComponent(dialog, fourD) {
        var _this = this;
        this.dialog = dialog;
        this.fourD = fourD;
        this.username = '';
        this.password = '';
        this.showError = false;
        this.fourDVersion = '';
        this.webAppVersion = _common_index__WEBPACK_IMPORTED_MODULE_1__["Config"].APP_VERSION;
        this.fourD.call4DRESTMethod('REST_GetApplicationVersion', {}, { responseType: 'text' })
            .subscribe(function (v) { _this.fourDVersion = v; });
    }
    LoginComponent.prototype.login = function () {
        var _this = this;
        var md5pwd = js44d__WEBPACK_IMPORTED_MODULE_2__["MD5"].md5(this.password);
        this.fourD.signIn(this.username, md5pwd.toUpperCase())
            .then(function (authentication) {
            if (js44d__WEBPACK_IMPORTED_MODULE_2__["FourDInterface"].authentication) {
                _this.showError = false;
                _this.dialog.close('loggedin');
            }
            else {
                console.log('oops');
                _this.showError = true;
            }
        })
            .catch(function (e) {
            console.log(e);
            _this.showError = true;
        });
    };
    LoginComponent.dialogConfig = {
        size: 'sm',
        selfCentered: true,
        isResizable: false,
        isModal: true,
        isBlocking: true,
        title: 'Login',
        width: 1063, height: 667
    };
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"])(),
        __metadata("design:type", Object)
    ], LoginComponent.prototype, "username", void 0);
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"])(),
        __metadata("design:type", Object)
    ], LoginComponent.prototype, "password", void 0);
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"])(),
        __metadata("design:type", Object)
    ], LoginComponent.prototype, "showError", void 0);
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"])(),
        __metadata("design:type", Object)
    ], LoginComponent.prototype, "fourDVersion", void 0);
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"])(),
        __metadata("design:type", Object)
    ], LoginComponent.prototype, "webAppVersion", void 0);
    LoginComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'log-in',
            moduleId: module.i,
            template: __webpack_require__(/*! ./login.component.html */ "./src/app/login/login.component.html"),
            styles: [__webpack_require__(/*! ./login.component.css */ "./src/app/login/login.component.css")]
        }),
        __metadata("design:paramtypes", [js44d__WEBPACK_IMPORTED_MODULE_2__["ModalDialogInstance"], js44d__WEBPACK_IMPORTED_MODULE_2__["FourDInterface"]])
    ], LoginComponent);
    return LoginComponent;
}());



/***/ }),

/***/ "./src/environments/environment.ts":
/*!*****************************************!*\
  !*** ./src/environments/environment.ts ***!
  \*****************************************/
/*! exports provided: environment */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "environment", function() { return environment; });
// The file contents for the current environment will overwrite these during build.
// The build system defaults to the dev environment which uses `environment.ts`, but if you do
// `ng build --env=prod` then `environment.prod.ts` will be used instead.
// The list of which env maps to which file can be found in `.angular-cli.json`.
var environment = {
    production: false
};


/***/ }),

/***/ "./src/main.ts":
/*!*********************!*\
  !*** ./src/main.ts ***!
  \*********************/
/*! no exports provided */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/platform-browser-dynamic */ "./node_modules/@angular/platform-browser-dynamic/fesm5/platform-browser-dynamic.js");
/* harmony import */ var _app_fourDAdmin_web_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./app/fourDAdmin.web.module */ "./src/app/fourDAdmin.web.module.ts");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./environments/environment */ "./src/environments/environment.ts");




if (_environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].production) {
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["enableProdMode"])();
}
Object(_angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_1__["platformBrowserDynamic"])().bootstrapModule(_app_fourDAdmin_web_module__WEBPACK_IMPORTED_MODULE_2__["WebModule"]);


/***/ }),

/***/ 0:
/*!***************************!*\
  !*** multi ./src/main.ts ***!
  \***************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(/*! /FourDAdmin/src/main.ts */"./src/main.ts");


/***/ })

},[[0,"runtime","vendor"]]]);
//# sourceMappingURL=main.js.map