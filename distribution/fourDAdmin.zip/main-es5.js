(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["main"],{

/***/ "./node_modules/raw-loader/index.js!./src/app/fourDAdmin/fourDAdmin.component.html":
/*!********************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/fourDAdmin/fourDAdmin.component.html ***!
  \********************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div platform>\n\n    <!-- This is our Header, with the web apps drop down -->\n    <header [hidden]=\"!userIsLoggedIn\">\n        <div style=\"height: 100px;\">\n                <img src=\"./assets/icons/LogoPascal.png\" style=\"display: inline-block;vertical-align: top; margin-right:20px; height: 100%;\"/>\n                <span style=\"display:inline-block; padding-left:40px; height:100% \">\n                    <label class=\"fieldPromptBold\" style=\"font-size:32pt;\">Welcome {{currentUser}}</label>\n                    <nav style=\"margin:-5px;\">\n                        <a *ngFor=\"let menuItem of menuList\" (click)=\"openApp(menuItem)\">{{menuItem.title}}</a>\n                        <a (click)=\"doLogin();\" style=\"padding-left:50px;\">Logout</a>\n                    </nav>\n                </span>\n\n        </div>\n\n    </header>\n \n  <router-outlet></router-outlet>\n\n</div>\n"

/***/ }),

/***/ "./node_modules/raw-loader/index.js!./src/app/login/login.component.html":
/*!**********************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/login/login.component.html ***!
  \**********************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "    <div class=\"login container\">\n        <form class=\"form-vertical\" role=\"form\" (submit)=\"login()\">\n            <label style=\"padding-bottom:40px;font-size:32pt;font-weight:bold;color:#7F7F6F;\">Welcome to FourD Admin</label>\n            <div class=\"form-group\" style=\"margin-left: 20px;\">\n                <label class=\"fieldPrompt\" style=\"font-weight:bold;width:90px;\" for=\"username\">User Name</label>\n                <input type=\"text\" class=\"fieldEntry\" style=\"width:300px;\" id=\"username\" name=\"username\" placeholder=\"Username\" [(ngModel)]=\"username\" (focus)=\"showError = false;\">\n            </div>\n            <div class=\"form-group\" style=\"margin-left: 20px;\">\n                <label class=\"fieldPrompt\" style=\"font-weight:bold;width:90px;\" for=\"password\">Password</label>\n                <input type=\"password\" class=\"fieldEntry\" style=\"width:300px;\" id=\"password\" name=\"password\" placeholder=\"Password\" [(ngModel)]=\"password\">\n            </div>\n            <button type=\"submit\" class=\"regularButton\" style=\"width:100px;margin-left: 30px;\">Login</button>\n        </form>\n        <div class=\"alert alert-warning\" style=\"width: 500px;\" [hidden]=\"!showError\">Sorry, the username and/or password was incorrect</div>\n\n        <div style=\"color:green;margin-top:100px;\">4D: {{fourDVersion}}, web: {{webAppVersion}}</div>\n    </div>\n\n"

/***/ }),

/***/ "./src/$$_lazy_route_resource lazy recursive":
/*!**********************************************************!*\
  !*** ./src/$$_lazy_route_resource lazy namespace object ***!
  \**********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

function webpackEmptyAsyncContext(req) {
	// Here Promise.resolve().then() is used instead of new Promise() to prevent
	// uncaught exception popping up in devtools
	return Promise.resolve().then(function() {
		var e = new Error("Cannot find module '" + req + "'");
		e.code = 'MODULE_NOT_FOUND';
		throw e;
	});
}
webpackEmptyAsyncContext.keys = function() { return []; };
webpackEmptyAsyncContext.resolve = webpackEmptyAsyncContext;
module.exports = webpackEmptyAsyncContext;
webpackEmptyAsyncContext.id = "./src/$$_lazy_route_resource lazy recursive";

/***/ }),

/***/ "./src/app/common/index.ts":
/*!*********************************!*\
  !*** ./src/app/common/index.ts ***!
  \*********************************/
/*! exports provided: Config, RouterModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _utils_index__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./utils/index */ "./src/app/common/utils/index.ts");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "Config", function() { return _utils_index__WEBPACK_IMPORTED_MODULE_0__["Config"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "RouterModule", function() { return _utils_index__WEBPACK_IMPORTED_MODULE_0__["RouterModule"]; });




/***/ }),

/***/ "./src/app/common/utils/Config.ts":
/*!****************************************!*\
  !*** ./src/app/common/utils/Config.ts ***!
  \****************************************/
/*! exports provided: Config */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Config", function() { return Config; });
var Config = /** @class */ (function () {
    function Config() {
    }
    Object.defineProperty(Config, "IS_WEB", {
        get: function () {
            return Config.PLATFORM_TARGET === Config.PLATFORMS.WEB;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(Config, "IS_MOBILE_NATIVE", {
        get: function () {
            return Config.PLATFORM_TARGET === Config.PLATFORMS.MOBILE_NATIVE;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(Config, "APP_VERSION", {
        get: function () {
            return '1.19.08.02a';
        },
        enumerable: true,
        configurable: true
    });
    // supported platforms
    Config.PLATFORMS = {
        WEB: 'web',
        MOBILE_NATIVE: 'mobile_native'
    };
    // current target (defaults to web)
    Config.PLATFORM_TARGET = Config.PLATFORMS.WEB;
    return Config;
}());



/***/ }),

/***/ "./src/app/common/utils/index.ts":
/*!***************************************!*\
  !*** ./src/app/common/utils/index.ts ***!
  \***************************************/
/*! exports provided: Config, RouterModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _Config__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./Config */ "./src/app/common/utils/Config.ts");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "Config", function() { return _Config__WEBPACK_IMPORTED_MODULE_0__["Config"]; });

/* harmony import */ var _router_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./router-module */ "./src/app/common/utils/router-module.ts");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "RouterModule", function() { return _router_module__WEBPACK_IMPORTED_MODULE_1__["RouterModule"]; });





/***/ }),

/***/ "./src/app/common/utils/router-module.ts":
/*!***********************************************!*\
  !*** ./src/app/common/utils/router-module.ts ***!
  \***********************************************/
/*! exports provided: RouterModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "RouterModule", function() { return _angular_router__WEBPACK_IMPORTED_MODULE_0__["RouterModule"]; });




/***/ }),

/***/ "./src/app/fourDAdmin.web.module.ts":
/*!******************************************!*\
  !*** ./src/app/fourDAdmin.web.module.ts ***!
  \******************************************/
/*! exports provided: WebModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "WebModule", function() { return WebModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/platform-browser */ "./node_modules/@angular/platform-browser/fesm5/platform-browser.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
/* harmony import */ var _fourDAdmin_fourDAdmin_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./fourDAdmin/fourDAdmin.component */ "./src/app/fourDAdmin/fourDAdmin.component.ts");
/* harmony import */ var _fourDAdmin_blankPage__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./fourDAdmin/blankPage */ "./src/app/fourDAdmin/blankPage.ts");
/* harmony import */ var _login_login_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./login/login.component */ "./src/app/login/login.component.ts");
/* harmony import */ var js44d__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! js44d */ "./node_modules/js44d/fesm5/js44d.js");

// angular






// app


// applets


// feature modules

var routerModule = _angular_router__WEBPACK_IMPORTED_MODULE_3__["RouterModule"].forRoot(_fourDAdmin_fourDAdmin_component__WEBPACK_IMPORTED_MODULE_7__["routes"]);
var WebModule = /** @class */ (function () {
    function WebModule() {
    }
    WebModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [
                _angular_platform_browser__WEBPACK_IMPORTED_MODULE_2__["BrowserModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormsModule"],
                _angular_common__WEBPACK_IMPORTED_MODULE_5__["CommonModule"],
                _angular_common_http__WEBPACK_IMPORTED_MODULE_6__["HttpClientModule"],
                routerModule,
                js44d__WEBPACK_IMPORTED_MODULE_10__["FourDModule"], js44d__WEBPACK_IMPORTED_MODULE_10__["JS44DModule"], js44d__WEBPACK_IMPORTED_MODULE_10__["ModalModule"]
            ],
            declarations: [_fourDAdmin_fourDAdmin_component__WEBPACK_IMPORTED_MODULE_7__["FourDAdminComponent"], _fourDAdmin_blankPage__WEBPACK_IMPORTED_MODULE_8__["BlankPage"], _login_login_component__WEBPACK_IMPORTED_MODULE_9__["LoginComponent"]
            ],
            exports: [js44d__WEBPACK_IMPORTED_MODULE_10__["FourDModule"], js44d__WEBPACK_IMPORTED_MODULE_10__["JS44DModule"], js44d__WEBPACK_IMPORTED_MODULE_10__["ModalModule"]],
            entryComponents: [_login_login_component__WEBPACK_IMPORTED_MODULE_9__["LoginComponent"]],
            bootstrap: [_fourDAdmin_fourDAdmin_component__WEBPACK_IMPORTED_MODULE_7__["FourDAdminComponent"]]
        })
    ], WebModule);
    return WebModule;
}());



/***/ }),

/***/ "./src/app/fourDAdmin/blankPage.ts":
/*!*****************************************!*\
  !*** ./src/app/fourDAdmin/blankPage.ts ***!
  \*****************************************/
/*! exports provided: BlankPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "BlankPage", function() { return BlankPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");


var BlankPage = /** @class */ (function () {
    function BlankPage() {
    }
    BlankPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'sd-blank',
            template: '<div></div>'
        })
    ], BlankPage);
    return BlankPage;
}());



/***/ }),

/***/ "./src/app/fourDAdmin/fourDAdmin.component.css":
/*!*****************************************************!*\
  !*** ./src/app/fourDAdmin/fourDAdmin.component.css ***!
  \*****************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "nav a {\n  color: #106cc8;\n  font-size: 14px;\n  font-weight: 500;\n  line-height: 48px;\n  margin-right: 20px;\n  text-decoration: none;\n  vertical-align: middle;\n}\n\nnav a:hover,\nnav a:focus {\n    color: #23527c;\n    font-size: 15px;\n    font-weight: 900;\n}\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvZm91ckRBZG1pbi9mb3VyREFkbWluLmNvbXBvbmVudC5jc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSxjQUFjO0VBQ2QsZUFBZTtFQUNmLGdCQUFnQjtFQUNoQixpQkFBaUI7RUFDakIsa0JBQWtCO0VBQ2xCLHFCQUFxQjtFQUNyQixzQkFBc0I7QUFDeEI7O0FBRUE7O0lBRUksY0FBYztJQUNkLGVBQWU7SUFDZixnQkFBZ0I7QUFDcEIiLCJmaWxlIjoic3JjL2FwcC9mb3VyREFkbWluL2ZvdXJEQWRtaW4uY29tcG9uZW50LmNzcyIsInNvdXJjZXNDb250ZW50IjpbIm5hdiBhIHtcbiAgY29sb3I6ICMxMDZjYzg7XG4gIGZvbnQtc2l6ZTogMTRweDtcbiAgZm9udC13ZWlnaHQ6IDUwMDtcbiAgbGluZS1oZWlnaHQ6IDQ4cHg7XG4gIG1hcmdpbi1yaWdodDogMjBweDtcbiAgdGV4dC1kZWNvcmF0aW9uOiBub25lO1xuICB2ZXJ0aWNhbC1hbGlnbjogbWlkZGxlO1xufVxuXG5uYXYgYTpob3Zlcixcbm5hdiBhOmZvY3VzIHtcbiAgICBjb2xvcjogIzIzNTI3YztcbiAgICBmb250LXNpemU6IDE1cHg7XG4gICAgZm9udC13ZWlnaHQ6IDkwMDtcbn1cbiJdfQ== */"

/***/ }),

/***/ "./src/app/fourDAdmin/fourDAdmin.component.ts":
/*!****************************************************!*\
  !*** ./src/app/fourDAdmin/fourDAdmin.component.ts ***!
  \****************************************************/
/*! exports provided: routes, FourDAdminComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "routes", function() { return routes; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "FourDAdminComponent", function() { return FourDAdminComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _common_index__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../common/index */ "./src/app/common/index.ts");
/* harmony import */ var _login_login_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../login/login.component */ "./src/app/login/login.component.ts");
/* harmony import */ var js44d__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! js44d */ "./node_modules/js44d/fesm5/js44d.js");
/* harmony import */ var _blankPage__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./blankPage */ "./src/app/fourDAdmin/blankPage.ts");








var routes = [
    { path: 'login', component: _blankPage__WEBPACK_IMPORTED_MODULE_6__["BlankPage"] },
    { path: 'browseTable', loadChildren: function () { return __webpack_require__.e(/*! import() | app-browseTable-browseTable-module */ "app-browseTable-browseTable-module").then(__webpack_require__.bind(null, /*! app/browseTable/browseTable.module */ "./src/app/browseTable/browseTable.module.ts")).then(function (m) { return m.BrowseTableModule; }); } },
    { path: 'listEditor', loadChildren: function () { return __webpack_require__.e(/*! import() | app-listEditor-listEditor-module */ "app-listEditor-listEditor-module").then(__webpack_require__.bind(null, /*! app/listEditor/listEditor.module */ "./src/app/listEditor/listEditor.module.ts")).then(function (m) { return m.ListEditorModule; }); } },
    { path: '**', component: _blankPage__WEBPACK_IMPORTED_MODULE_6__["BlankPage"] }
];
var FourDAdminComponent = /** @class */ (function () {
    function FourDAdminComponent(router, modal, viewref) {
        this.router = router;
        this.modal = modal;
        this.viewref = viewref;
        this.menuList = [
            {
                routePath: '/browseTable',
                title: 'Browse Table'
            },
            {
                routePath: '/listEditor',
                title: 'List Editor'
            },
        ];
        if (window.location.hostname === 'localhost' && window.location.port === '4200') {
            // FourDInterface.fourDUrl = 'http://www.vakeano.com';
            js44d__WEBPACK_IMPORTED_MODULE_5__["FourDInterface"].fourDUrl = 'http://localhost:8080';
            // FourDInterface.fourDUrl = 'http://10.211.55.8:8181';
        }
        else {
            js44d__WEBPACK_IMPORTED_MODULE_5__["FourDInterface"].fourDUrl = window.location.origin;
        }
        js44d__WEBPACK_IMPORTED_MODULE_5__["Modal"].hostViewRef = this.viewref;
    }
    Object.defineProperty(FourDAdminComponent.prototype, "currentUser", {
        get: function () {
            return (js44d__WEBPACK_IMPORTED_MODULE_5__["FourDInterface"].authentication) ? js44d__WEBPACK_IMPORTED_MODULE_5__["FourDInterface"].currentUser : '?';
        },
        enumerable: true,
        configurable: true
    });
    FourDAdminComponent.prototype.ngAfterContentInit = function () {
        // no predefined user, login...
        if (_common_index__WEBPACK_IMPORTED_MODULE_3__["Config"].PLATFORM_TARGET === _common_index__WEBPACK_IMPORTED_MODULE_3__["Config"].PLATFORMS.WEB) {
            this.showLoginDialog();
        }
    };
    FourDAdminComponent.prototype.userHasLoggedIn = function () {
        // load current profile user functions
        if (this.userIsLoggedIn) {
            js44d__WEBPACK_IMPORTED_MODULE_5__["FourDInterface"].runningInsideWorkspace = true; // we are indeed running inside the workspace
        }
    };
    Object.defineProperty(FourDAdminComponent.prototype, "userIsLoggedIn", {
        get: function () { return js44d__WEBPACK_IMPORTED_MODULE_5__["FourDInterface"].authentication !== undefined && js44d__WEBPACK_IMPORTED_MODULE_5__["FourDInterface"].authentication !== null; },
        enumerable: true,
        configurable: true
    });
    FourDAdminComponent.prototype.doLogin = function () {
        js44d__WEBPACK_IMPORTED_MODULE_5__["FourDInterface"].authentication = null;
        this.router.navigate(['/login'], { skipLocationChange: true });
        if (_common_index__WEBPACK_IMPORTED_MODULE_3__["Config"].PLATFORM_TARGET === _common_index__WEBPACK_IMPORTED_MODULE_3__["Config"].PLATFORMS.WEB) {
            this.showLoginDialog();
        }
    };
    FourDAdminComponent.prototype.showLoginDialog = function () {
        var _this = this;
        this.modal.openInside(_login_login_component__WEBPACK_IMPORTED_MODULE_4__["LoginComponent"], this.viewref, null, _login_login_component__WEBPACK_IMPORTED_MODULE_4__["LoginComponent"]['dialogConfig'])
            .then(function (result) {
            _this.userHasLoggedIn();
        });
    };
    FourDAdminComponent.prototype.openApp = function (menu) {
        if (js44d__WEBPACK_IMPORTED_MODULE_5__["FourDInterface"].authentication) {
            this.router.navigate([menu.routePath], { skipLocationChange: true });
        }
    };
    FourDAdminComponent.ctorParameters = function () { return [
        { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"] },
        { type: js44d__WEBPACK_IMPORTED_MODULE_5__["Modal"] },
        { type: _angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewContainerRef"] }
    ]; };
    FourDAdminComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'sd-fourdadmin',
            providers: [js44d__WEBPACK_IMPORTED_MODULE_5__["Modal"], js44d__WEBPACK_IMPORTED_MODULE_5__["FourDInterface"]],
            template: __webpack_require__(/*! raw-loader!./fourDAdmin.component.html */ "./node_modules/raw-loader/index.js!./src/app/fourDAdmin/fourDAdmin.component.html"),
            styles: [__webpack_require__(/*! ./fourDAdmin.component.css */ "./src/app/fourDAdmin/fourDAdmin.component.css")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"], js44d__WEBPACK_IMPORTED_MODULE_5__["Modal"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewContainerRef"]])
    ], FourDAdminComponent);
    return FourDAdminComponent;
}());



/***/ }),

/***/ "./src/app/login/login.component.css":
/*!*******************************************!*\
  !*** ./src/app/login/login.component.css ***!
  \*******************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".login {\n    width: 1070px !important;\n    background: url('login_splash.png');\n    background-repeat: no-repeat;\n    height: 670px !important;\n    padding-left: 200px;\n    padding-top: 200px;\n}\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvbG9naW4vbG9naW4uY29tcG9uZW50LmNzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtJQUNJLHdCQUF3QjtJQUN4QixtQ0FBc0Q7SUFDdEQsNEJBQTRCO0lBQzVCLHdCQUF3QjtJQUN4QixtQkFBbUI7SUFDbkIsa0JBQWtCO0FBQ3RCIiwiZmlsZSI6InNyYy9hcHAvbG9naW4vbG9naW4uY29tcG9uZW50LmNzcyIsInNvdXJjZXNDb250ZW50IjpbIi5sb2dpbiB7XG4gICAgd2lkdGg6IDEwNzBweCAhaW1wb3J0YW50O1xuICAgIGJhY2tncm91bmQ6IHVybChcIi4uLy4uL2Fzc2V0cy9pY29ucy9sb2dpbl9zcGxhc2gucG5nXCIpO1xuICAgIGJhY2tncm91bmQtcmVwZWF0OiBuby1yZXBlYXQ7XG4gICAgaGVpZ2h0OiA2NzBweCAhaW1wb3J0YW50O1xuICAgIHBhZGRpbmctbGVmdDogMjAwcHg7XG4gICAgcGFkZGluZy10b3A6IDIwMHB4O1xufVxuIl19 */"

/***/ }),

/***/ "./src/app/login/login.component.ts":
/*!******************************************!*\
  !*** ./src/app/login/login.component.ts ***!
  \******************************************/
/*! exports provided: LoginComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LoginComponent", function() { return LoginComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _common_index__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../common/index */ "./src/app/common/index.ts");
/* harmony import */ var js44d__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! js44d */ "./node_modules/js44d/fesm5/js44d.js");





var LoginComponent = /** @class */ (function () {
    function LoginComponent(dialog, fourD) {
        var _this = this;
        this.dialog = dialog;
        this.fourD = fourD;
        this.username = '';
        this.password = '';
        this.showError = false;
        this.fourDVersion = '';
        this.webAppVersion = _common_index__WEBPACK_IMPORTED_MODULE_2__["Config"].APP_VERSION;
        this.fourD.call4DRESTMethod('REST_GetApplicationVersion', {}, { responseType: 'text' })
            .subscribe(function (v) { _this.fourDVersion = v; });
    }
    LoginComponent.prototype.login = function () {
        var _this = this;
        var md5pwd = js44d__WEBPACK_IMPORTED_MODULE_3__["MD5"].md5(this.password);
        this.fourD.signIn(this.username, md5pwd.toUpperCase())
            .then(function (authentication) {
            if (js44d__WEBPACK_IMPORTED_MODULE_3__["FourDInterface"].authentication) {
                _this.showError = false;
                _this.dialog.close('loggedin');
            }
            else {
                console.log('oops');
                _this.showError = true;
            }
        })
            .catch(function (e) {
            console.log(e);
            _this.showError = true;
        });
    };
    LoginComponent.dialogConfig = {
        size: 'sm',
        selfCentered: true,
        isResizable: false,
        isModal: true,
        isBlocking: true,
        title: 'Login',
        width: 1063, height: 667
    };
    LoginComponent.ctorParameters = function () { return [
        { type: js44d__WEBPACK_IMPORTED_MODULE_3__["ModalDialogInstance"] },
        { type: js44d__WEBPACK_IMPORTED_MODULE_3__["FourDInterface"] }
    ]; };
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
    ], LoginComponent.prototype, "username", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
    ], LoginComponent.prototype, "password", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
    ], LoginComponent.prototype, "showError", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
    ], LoginComponent.prototype, "fourDVersion", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
    ], LoginComponent.prototype, "webAppVersion", void 0);
    LoginComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'log-in',
            template: __webpack_require__(/*! raw-loader!./login.component.html */ "./node_modules/raw-loader/index.js!./src/app/login/login.component.html"),
            styles: [__webpack_require__(/*! ./login.component.css */ "./src/app/login/login.component.css")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [js44d__WEBPACK_IMPORTED_MODULE_3__["ModalDialogInstance"], js44d__WEBPACK_IMPORTED_MODULE_3__["FourDInterface"]])
    ], LoginComponent);
    return LoginComponent;
}());



/***/ }),

/***/ "./src/environments/environment.ts":
/*!*****************************************!*\
  !*** ./src/environments/environment.ts ***!
  \*****************************************/
/*! exports provided: environment */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "environment", function() { return environment; });
// The file contents for the current environment will overwrite these during build.
// The build system defaults to the dev environment which uses `environment.ts`, but if you do
// `ng build --env=prod` then `environment.prod.ts` will be used instead.
// The list of which env maps to which file can be found in `.angular-cli.json`.
var environment = {
    production: false
};


/***/ }),

/***/ "./src/main.ts":
/*!*********************!*\
  !*** ./src/main.ts ***!
  \*********************/
/*! no exports provided */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/platform-browser-dynamic */ "./node_modules/@angular/platform-browser-dynamic/fesm5/platform-browser-dynamic.js");
/* harmony import */ var _app_fourDAdmin_web_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./app/fourDAdmin.web.module */ "./src/app/fourDAdmin.web.module.ts");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./environments/environment */ "./src/environments/environment.ts");




if (_environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].production) {
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["enableProdMode"])();
}
Object(_angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_1__["platformBrowserDynamic"])().bootstrapModule(_app_fourDAdmin_web_module__WEBPACK_IMPORTED_MODULE_2__["WebModule"]);


/***/ }),

/***/ 0:
/*!***************************!*\
  !*** multi ./src/main.ts ***!
  \***************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(/*! /FourDAdmin/src/main.ts */"./src/main.ts");


/***/ })

},[[0,"runtime","vendor"]]]);
//# sourceMappingURL=main-es5.js.map