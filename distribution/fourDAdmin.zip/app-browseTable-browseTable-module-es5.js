function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _possibleConstructorReturn(self, call) { if (call && (typeof call === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function _getPrototypeOf(o) { _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return _getPrototypeOf(o); }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); if (superClass) _setPrototypeOf(subClass, superClass); }

function _setPrototypeOf(o, p) { _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _setPrototypeOf(o, p); }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["app-browseTable-browseTable-module"], {
  /***/
  "./src/app/browseTable/browseFieldDialog.component.ts":
  /*!************************************************************!*\
    !*** ./src/app/browseTable/browseFieldDialog.component.ts ***!
    \************************************************************/

  /*! exports provided: BrowseFieldDialog */

  /***/
  function srcAppBrowseTableBrowseFieldDialogComponentTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "BrowseFieldDialog", function () {
      return BrowseFieldDialog;
    });
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");

    var BrowseFieldDialog = function BrowseFieldDialog() {
      _classCallCheck(this, BrowseFieldDialog);
    };

    BrowseFieldDialog.ɵfac = function BrowseFieldDialog_Factory(t) {
      return new (t || BrowseFieldDialog)();
    };

    BrowseFieldDialog.ɵcmp = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({
      type: BrowseFieldDialog,
      selectors: [["field-content"]],
      decls: 0,
      vars: 0,
      template: function BrowseFieldDialog_Template(rf, ctx) {},
      encapsulation: 2
    });
    /*@__PURE__*/

    (function () {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](BrowseFieldDialog, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"],
        args: [{
          moduleId: module.i,
          selector: 'field-content',
          template: ""
        }]
      }], null, null);
    })();
    /***/

  },

  /***/
  "./src/app/browseTable/browseFormDialog.component.ts":
  /*!***********************************************************!*\
    !*** ./src/app/browseTable/browseFormDialog.component.ts ***!
    \***********************************************************/

  /*! exports provided: BrowseFormDialog */

  /***/
  function srcAppBrowseTableBrowseFormDialogComponentTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "BrowseFormDialog", function () {
      return BrowseFormDialog;
    });
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var js44d__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! js44d */
    "./node_modules/js44d/__ivy_ngcc__/fesm2015/js44d.js");

    function BrowseFormDialog_browse_inputfield_2_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](0, "browse-inputfield", 6);
      }

      if (rf & 2) {
        var field_r1 = ctx.$implicit;

        var ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("inputField", field_r1)("currentRecord", ctx_r0.currentRecord);
      }
    }

    var BrowseFormDialog = /*#__PURE__*/function (_js44d__WEBPACK_IMPOR) {
      _inherits(BrowseFormDialog, _js44d__WEBPACK_IMPOR);

      function BrowseFormDialog() {
        _classCallCheck(this, BrowseFormDialog);

        return _possibleConstructorReturn(this, _getPrototypeOf(BrowseFormDialog).apply(this, arguments));
      }

      _createClass(BrowseFormDialog, [{
        key: "ngAfterViewInit",
        value: function ngAfterViewInit() {
          var _this = this;

          this.dialog.setTitle('Edit Record: ' + this.currentRecord.tableName);
          /**
           * as I'm dealing with a fake FourDModel instance, I need to populate
           * the model's attributes so data modification gets properly flagged
           */

          this.currentRecord.fields.forEach(function (element) {
            _this.currentRecord.set(element.name, _this.currentRecord[element.name]);
          });
          this.currentRecord.clearRecordDirtyFlag();
        }
      }]);

      return BrowseFormDialog;
    }(js44d__WEBPACK_IMPORTED_MODULE_1__["RecordEditWindow"]);

    BrowseFormDialog.dialogConfig = {
      actions: ['Maximize', 'Minimize', 'Close'],
      position: {
        top: 100,
        left: 100
      },
      selfCentered: true,
      title: 'Record Details',
      isResizable: true,
      width: 950,
      height: 500
    };

    BrowseFormDialog.ɵfac = function BrowseFormDialog_Factory(t) {
      return ɵBrowseFormDialog_BaseFactory(t || BrowseFormDialog);
    };

    BrowseFormDialog.ɵcmp = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({
      type: BrowseFormDialog,
      selectors: [["modal-content"]],
      features: [_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵInheritDefinitionFeature"]],
      decls: 8,
      vars: 1,
      consts: [[2, "display", "flex", "flex-direction", "column", "height", "calc(100% - 20px)"], [2, "display", "grid", "overflow", "scroll", "margin", "20px 20px 5px 20px", "padding-left", "10px", "border-style", "outset"], [3, "inputField", "currentRecord", 4, "ngFor", "ngForOf"], [1, "buttonBar", 2, "align-self", "flex-end"], [1, "regularButton", 2, "width", "90px", 3, "click"], [1, "regularButton", 2, "margin-left", "20px", "width", "90px", 3, "click"], [3, "inputField", "currentRecord"]],
      template: function BrowseFormDialog_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 0);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "form", 1);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](2, BrowseFormDialog_browse_inputfield_2_Template, 1, 2, "browse-inputfield", 2);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](3, "div", 3);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](4, "button", 4);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function BrowseFormDialog_Template_button_click_4_listener() {
            return ctx.dialog.close("cancel");
          });

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](5, "Cancel");

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](6, "button", 5);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function BrowseFormDialog_Template_button_click_6_listener() {
            return ctx.saveRecord();
          });

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](7, "SAVE");

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        }

        if (rf & 2) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngForOf", ctx.currentRecord.fields);
        }
      },
      encapsulation: 2
    });

    var ɵBrowseFormDialog_BaseFactory = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetInheritedFactory"](BrowseFormDialog);
    /*@__PURE__*/


    (function () {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](BrowseFormDialog, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"],
        args: [{
          moduleId: module.i,
          selector: 'modal-content',
          template: "\n    <div style=\"display:flex;flex-direction:column;height:calc(100% - 20px);\">\n                <form style=\"display:grid;overflow:scroll;margin:20px 20px 5px 20px;padding-left:10px;border-style:outset\">\n                    <browse-inputfield *ngFor='let field of currentRecord.fields' [inputField]= \"field\" [currentRecord]=\"currentRecord\"></browse-inputfield>                    \n                </form>\n                <div class=\"buttonBar\" style=\"align-self:flex-end\">\n                    <button class=\"regularButton\" style=\"width:90px;\" (click)=\"dialog.close('cancel')\">Cancel</button>\n                    <button class=\"regularButton\" style=\"margin-left:20px;width:90px;\" (click)=\"saveRecord()\">SAVE</button>\n                </div>\n    </div>\n            "
        }]
      }], null, null);
    })();
    /***/

  },

  /***/
  "./src/app/browseTable/browseInputField.component.ts":
  /*!***********************************************************!*\
    !*** ./src/app/browseTable/browseInputField.component.ts ***!
    \***********************************************************/

  /*! exports provided: BrowseInputField */

  /***/
  function srcAppBrowseTableBrowseInputFieldComponentTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "BrowseInputField", function () {
      return BrowseInputField;
    });
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _browseTable_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! ./browseTable.component */
    "./src/app/browseTable/browseTable.component.ts");
    /* harmony import */


    var js44d__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! js44d */
    "./node_modules/js44d/__ivy_ngcc__/fesm2015/js44d.js");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");

    function BrowseInputField_span_4_fourd_dropdown_1_Template(rf, ctx) {
      if (rf & 1) {
        var _r61 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "fourd-dropdown", 14);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("selectedValueChange", function BrowseInputField_span_4_fourd_dropdown_1_Template_fourd_dropdown_selectedValueChange_0_listener($event) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r61);

          var ctx_r60 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](2);

          return ctx_r60.stringField = $event;
        })("change", function BrowseInputField_span_4_fourd_dropdown_1_Template_fourd_dropdown_change_0_listener($event) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r61);

          var ctx_r62 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](2);

          return ctx_r62.stringField = $event.target.value;
        });

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
      }

      if (rf & 2) {
        var ctx_r57 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](2);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpropertyInterpolate"]("listName", ctx_r57.inputField.choiceList);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("selectedValue", ctx_r57.stringField);
      }
    }

    function BrowseInputField_span_4_textarea_2_Template(rf, ctx) {
      if (rf & 1) {
        var _r64 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "textarea", 15);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("ngModelChange", function BrowseInputField_span_4_textarea_2_Template_textarea_ngModelChange_0_listener($event) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r64);

          var ctx_r63 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](2);

          return ctx_r63.stringField = $event;
        });

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
      }

      if (rf & 2) {
        var ctx_r58 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](2);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("maxlength", ctx_r58.inputField.length)("name", ctx_r58.inputField.name)("ngModel", ctx_r58.stringField);
      }
    }

    function BrowseInputField_span_4_textarea_3_Template(rf, ctx) {
      if (rf & 1) {
        var _r66 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "textarea", 16);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("ngModelChange", function BrowseInputField_span_4_textarea_3_Template_textarea_ngModelChange_0_listener($event) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r66);

          var ctx_r65 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](2);

          return ctx_r65.stringField = $event;
        });

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
      }

      if (rf & 2) {
        var ctx_r59 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](2);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("name", ctx_r59.inputField.name)("ngModel", ctx_r59.stringField)("disabled", ctx_r59.inputField.readonly);
      }
    }

    function BrowseInputField_span_4_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "span");

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](1, BrowseInputField_span_4_fourd_dropdown_1_Template, 1, 2, "fourd-dropdown", 11);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](2, BrowseInputField_span_4_textarea_2_Template, 1, 3, "textarea", 12);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](3, BrowseInputField_span_4_textarea_3_Template, 1, 3, "textarea", 13);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
      }

      if (rf & 2) {
        var ctx_r48 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx_r48.inputField.choiceList != "");

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx_r48.inputField.length > 0 && ctx_r48.inputField.choiceList == "");

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", !ctx_r48.inputField.length && ctx_r48.inputField.choiceList == "");
      }
    }

    function BrowseInputField_input_5_Template(rf, ctx) {
      if (rf & 1) {
        var _r68 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "input", 17);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("ngModelChange", function BrowseInputField_input_5_Template_input_ngModelChange_0_listener($event) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r68);

          var ctx_r67 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();

          return ctx_r67.dateField = $event;
        });

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
      }

      if (rf & 2) {
        var ctx_r49 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("name", ctx_r49.inputField.name)("ngModel", ctx_r49.dateField)("disabled", ctx_r49.inputField.readonly);
      }
    }

    function BrowseInputField_input_6_Template(rf, ctx) {
      if (rf & 1) {
        var _r70 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "input", 18);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("ngModelChange", function BrowseInputField_input_6_Template_input_ngModelChange_0_listener($event) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r70);

          var ctx_r69 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();

          return ctx_r69.timeField = $event;
        });

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
      }

      if (rf & 2) {
        var ctx_r50 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("name", ctx_r50.inputField.name)("ngModel", ctx_r50.timeField)("disabled", ctx_r50.inputField.readonly);
      }
    }

    function BrowseInputField_input_7_Template(rf, ctx) {
      if (rf & 1) {
        var _r72 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "input", 19);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("ngModelChange", function BrowseInputField_input_7_Template_input_ngModelChange_0_listener($event) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r72);

          var ctx_r71 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();

          return ctx_r71.numberField = $event;
        });

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
      }

      if (rf & 2) {
        var ctx_r51 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("name", ctx_r51.inputField.name)("ngModel", ctx_r51.numberField)("disabled", ctx_r51.inputField.readonly);
      }
    }

    function BrowseInputField_input_8_Template(rf, ctx) {
      if (rf & 1) {
        var _r74 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "input", 20);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("ngModelChange", function BrowseInputField_input_8_Template_input_ngModelChange_0_listener($event) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r74);

          var ctx_r73 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();

          return ctx_r73.numberField = $event;
        });

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
      }

      if (rf & 2) {
        var ctx_r52 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("name", ctx_r52.inputField.name)("ngModel", ctx_r52.numberField)("disabled", ctx_r52.inputField.readonly);
      }
    }

    function BrowseInputField_input_9_Template(rf, ctx) {
      if (rf & 1) {
        var _r76 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "input", 20);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("ngModelChange", function BrowseInputField_input_9_Template_input_ngModelChange_0_listener($event) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r76);

          var ctx_r75 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();

          return ctx_r75.numberField = $event;
        });

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
      }

      if (rf & 2) {
        var ctx_r53 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("name", ctx_r53.inputField.name)("ngModel", ctx_r53.numberField)("disabled", ctx_r53.inputField.readonly);
      }
    }

    function BrowseInputField_input_10_Template(rf, ctx) {
      if (rf & 1) {
        var _r78 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "input", 21);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("ngModelChange", function BrowseInputField_input_10_Template_input_ngModelChange_0_listener($event) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r78);

          var ctx_r77 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();

          return ctx_r77.booleanField = $event;
        });

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
      }

      if (rf & 2) {
        var ctx_r54 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("name", ctx_r54.inputField.name)("ngModel", ctx_r54.booleanField)("disabled", ctx_r54.inputField.readonly);
      }
    }

    function BrowseInputField_textarea_11_Template(rf, ctx) {
      if (rf & 1) {
        var _r80 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "textarea", 22);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("ngModelChange", function BrowseInputField_textarea_11_Template_textarea_ngModelChange_0_listener($event) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r80);

          var ctx_r79 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();

          return ctx_r79.objectField = $event;
        });

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
      }

      if (rf & 2) {
        var ctx_r55 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("name", ctx_r55.inputField.name)("ngModel", ctx_r55.objectField);
      }
    }

    function BrowseInputField_img_12_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](0, "img", 23);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipe"](1, "base64ImageRef");
      }

      if (rf & 2) {
        var ctx_r56 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("src", _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipeBind1"](1, 1, ctx_r56.stringField), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵsanitizeUrl"]);
      }
    }
    /* tslint:disable */

    /* tslint:denable */


    var BrowseInputField = /*#__PURE__*/function () {
      function BrowseInputField(fourD) {
        _classCallCheck(this, BrowseInputField);

        this.fourD = fourD;
      }
      /**
       * Here I have to use a trick to deal with the fact that I'm using a fake FourDModel
       * which has not get/set methods for each property
       * so I'm using generic typed variables that do the get/set functions I need
       */


      _createClass(BrowseInputField, [{
        key: "stringField",
        get: function get() {
          return this.currentRecord.get(this.inputField.name);
        },
        set: function set(v) {
          this.currentRecord.set(this.inputField.name, v);
          this.currentRecord[this.inputField.name] = v;
        }
      }, {
        key: "numberField",
        get: function get() {
          return this.currentRecord.get(this.inputField.name);
        },
        set: function set(v) {
          this.currentRecord.set(this.inputField.name, v);
          this.currentRecord[this.inputField.name] = v;
        }
      }, {
        key: "booleanField",
        get: function get() {
          return this.currentRecord.get(this.inputField.name);
        },
        set: function set(v) {
          this.currentRecord.set(this.inputField.name, v);
          this.currentRecord[this.inputField.name] = v;
        }
      }, {
        key: "dateField",
        get: function get() {
          // need to deal with how browsers handle 'date' input fields, which is not really supported, so we treat it as a string input for now
          var value;
          var dateValue = this.currentRecord[this.inputField.name];

          if (typeof dateValue === 'string') {
            value = dateValue.replace(/\//g, '-');
          } else if (dateValue) {
            value = dateValue.getFullYear().toString() + '-';
            if (dateValue.getMonth() < 9) value += '0';
            value += (dateValue.getMonth() + 1).toString() + '-';
            if (dateValue.getDate() < 10) value += '0';
            value += dateValue.getDate().toString();
          }

          return value;
        },
        set: function set(v) {
          this.currentRecord.set(this.inputField.name, new Date(v.replace(/-/g, '\/')));
          this.currentRecord[this.inputField.name] = this.currentRecord.get(this.inputField.name);
        }
      }, {
        key: "timeField",
        get: function get() {
          // need to deal with how browsers handle 'date' input fields, which is not really supported, so we treat it as a string input for now
          var value;
          var timeValue = this.currentRecord[this.inputField.name];

          if (typeof timeValue === 'string') {
            value = timeValue;
          } else if (timeValue) {
            value = this.fourD.timeTo4DFormat(timeValue);
          }

          return value;
        },
        set: function set(v) {
          this.currentRecord.set(this.inputField.name, v);
          this.currentRecord[this.inputField.name] = this.currentRecord.get(this.inputField.name);
        }
      }, {
        key: "objectField",
        get: function get() {
          return JSON.stringify(this.currentRecord.get(this.inputField.name));
        },
        set: function set(v) {
          this.currentRecord.set(this.inputField.name, JSON.parse(v));
          this.currentRecord[this.inputField.name] = JSON.parse(v);
        }
      }]);

      return BrowseInputField;
    }();

    BrowseInputField.ɵfac = function BrowseInputField_Factory(t) {
      return new (t || BrowseInputField)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](js44d__WEBPACK_IMPORTED_MODULE_2__["FourDInterface"]));
    };

    BrowseInputField.ɵcmp = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({
      type: BrowseInputField,
      selectors: [["browse-inputfield"]],
      inputs: {
        inputField: "inputField",
        currentRecord: "currentRecord",
        stringField: "stringField",
        numberField: "numberField",
        booleanField: "booleanField",
        dateField: "dateField",
        timeField: "timeField",
        objectField: "objectField"
      },
      decls: 13,
      vars: 12,
      consts: [[2, "display", "inline-block", "margin", "15px", "width", "calc(100% - 30px)"], [1, "formHeaderSmall", 2, "margin-right", "10px", "width", "180px", "vertical-align", "top"], [3, "ngSwitch"], [4, "ngSwitchCase"], ["type", "date", "class", "fieldEntry", "style", "width:125px;height:20px;", 3, "name", "ngModel", "disabled", "ngModelChange", 4, "ngSwitchCase"], ["type", "time", "class", "fieldEntry", "style", "width:125px;height:20px;", 3, "name", "ngModel", "disabled", "ngModelChange", 4, "ngSwitchCase"], ["type", "number", "class", "fieldEntry", "style", "width:80px;height:20px;text-align:right;", 3, "name", "ngModel", "disabled", "ngModelChange", 4, "ngSwitchCase"], ["type", "number", "class", "fieldEntry", "style", "width:80px;height:20px;", 3, "name", "ngModel", "disabled", "ngModelChange", 4, "ngSwitchCase"], ["type", "checkbox", "class", "fieldEntry", "style", "height:30px;width:50px;margin-top:-6px;", 3, "name", "ngModel", "disabled", "ngModelChange", 4, "ngSwitchCase"], ["type", "text", "class", "fieldEntry", "cols", "90", "style", "resize:vertical;width:75%", "disabled", "", 3, "name", "ngModel", "ngModelChange", 4, "ngSwitchCase"], ["style", "height:300px;", 3, "src", 4, "ngSwitchCase"], [3, "listName", "selectedValue", "selectedValueChange", "change", 4, "ngIf"], ["type", "text", "class", "fieldEntry", "cols", "90", "style", "resize:vertical;width:75%", 3, "maxlength", "name", "ngModel", "ngModelChange", 4, "ngIf"], ["type", "text", "class", "fieldEntry", "cols", "90", "style", "resize:vertical;width:75%", 3, "name", "ngModel", "disabled", "ngModelChange", 4, "ngIf"], [3, "listName", "selectedValue", "selectedValueChange", "change"], ["type", "text", "cols", "90", 1, "fieldEntry", 2, "resize", "vertical", "width", "75%", 3, "maxlength", "name", "ngModel", "ngModelChange"], ["type", "text", "cols", "90", 1, "fieldEntry", 2, "resize", "vertical", "width", "75%", 3, "name", "ngModel", "disabled", "ngModelChange"], ["type", "date", 1, "fieldEntry", 2, "width", "125px", "height", "20px", 3, "name", "ngModel", "disabled", "ngModelChange"], ["type", "time", 1, "fieldEntry", 2, "width", "125px", "height", "20px", 3, "name", "ngModel", "disabled", "ngModelChange"], ["type", "number", 1, "fieldEntry", 2, "width", "80px", "height", "20px", "text-align", "right", 3, "name", "ngModel", "disabled", "ngModelChange"], ["type", "number", 1, "fieldEntry", 2, "width", "80px", "height", "20px", 3, "name", "ngModel", "disabled", "ngModelChange"], ["type", "checkbox", 1, "fieldEntry", 2, "height", "30px", "width", "50px", "margin-top", "-6px", 3, "name", "ngModel", "disabled", "ngModelChange"], ["type", "text", "cols", "90", "disabled", "", 1, "fieldEntry", 2, "resize", "vertical", "width", "75%", 3, "name", "ngModel", "ngModelChange"], [2, "height", "300px", 3, "src"]],
      template: function BrowseInputField_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 0);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "label", 1);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](2);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](3, "span", 2);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](4, BrowseInputField_span_4_Template, 4, 3, "span", 3);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](5, BrowseInputField_input_5_Template, 1, 3, "input", 4);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](6, BrowseInputField_input_6_Template, 1, 3, "input", 5);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](7, BrowseInputField_input_7_Template, 1, 3, "input", 6);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](8, BrowseInputField_input_8_Template, 1, 3, "input", 7);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](9, BrowseInputField_input_9_Template, 1, 3, "input", 7);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](10, BrowseInputField_input_10_Template, 1, 3, "input", 8);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](11, BrowseInputField_textarea_11_Template, 1, 2, "textarea", 9);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](12, BrowseInputField_img_12_Template, 2, 3, "img", 10);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        }

        if (rf & 2) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵattribute"]("for", ctx.inputField.name);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate1"]("", ctx.inputField.title, ":\xA0\xA0");

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngSwitch", ctx.inputField.type);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngSwitchCase", "string");

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngSwitchCase", "Date");

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngSwitchCase", "Time");

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngSwitchCase", "number");

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngSwitchCase", "Number");

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngSwitchCase", "float");

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngSwitchCase", "boolean");

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngSwitchCase", "json");

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngSwitchCase", "picture");
        }
      },
      directives: [_angular_common__WEBPACK_IMPORTED_MODULE_3__["NgSwitch"], _angular_common__WEBPACK_IMPORTED_MODULE_3__["NgSwitchCase"], _angular_common__WEBPACK_IMPORTED_MODULE_3__["NgIf"], js44d__WEBPACK_IMPORTED_MODULE_2__["FourDDropDown"], _angular_forms__WEBPACK_IMPORTED_MODULE_4__["DefaultValueAccessor"], _angular_forms__WEBPACK_IMPORTED_MODULE_4__["MaxLengthValidator"], _angular_forms__WEBPACK_IMPORTED_MODULE_4__["NgControlStatus"], _angular_forms__WEBPACK_IMPORTED_MODULE_4__["NgModel"], _angular_forms__WEBPACK_IMPORTED_MODULE_4__["NumberValueAccessor"], _angular_forms__WEBPACK_IMPORTED_MODULE_4__["CheckboxControlValueAccessor"]],
      pipes: [js44d__WEBPACK_IMPORTED_MODULE_2__["Base64ImageRef"]],
      encapsulation: 2
    });
    /*@__PURE__*/

    (function () {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](BrowseInputField, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"],
        args: [{
          moduleId: module.i,
          selector: 'browse-inputfield',
          template: "<div style=\"display:inline-block;margin:15px;width:calc(100% - 30px)\">\n                <label class=\"formHeaderSmall\" [attr.for]=\"inputField.name\" style=\"margin-right:10px;width:180px;vertical-align:top\">{{inputField.title}}:&nbsp;&nbsp;</label>\n                    <span [ngSwitch]=\"inputField.type\">\n                        <span *ngSwitchCase=\"'string'\">\n                            <fourd-dropdown *ngIf=\"inputField.choiceList != ''\" listName=\"{{inputField.choiceList}}\" [(selectedValue)]=\"stringField\" (change)=\"stringField = $event.target.value\"></fourd-dropdown>\n                            <textarea *ngIf=\"inputField.length > 0 && inputField.choiceList == ''\" [maxlength]=\"inputField.length\" [name]=\"inputField.name\" type=\"text\" class=\"fieldEntry\"  cols=\"90\" style=\"resize:vertical;width:75%\" [(ngModel)]=\"stringField\"></textarea>\n                            <textarea *ngIf=\"!inputField.length && inputField.choiceList == ''\"  [name]=\"inputField.name\" type=\"text\" class=\"fieldEntry\"  cols=\"90\" style=\"resize:vertical;width:75%\" [(ngModel)]=\"stringField\" [disabled]=\"inputField.readonly\"></textarea>\n                        </span>\n                        <input *ngSwitchCase=\"'Date'\"  [name]=\"inputField.name\" type=\"date\" class=\"fieldEntry\"  style=\"width:125px;height:20px;\" [(ngModel)]=\"dateField\" [disabled]=\"inputField.readonly\"/>\n                        <input *ngSwitchCase=\"'Time'\"  [name]=\"inputField.name\" type=\"time\" class=\"fieldEntry\"  style=\"width:125px;height:20px;\" [(ngModel)]=\"timeField\" [disabled]=\"inputField.readonly\"/>\n                        <input *ngSwitchCase=\"'number'\"  [name]=\"inputField.name\" type=\"number\" class=\"fieldEntry\"  style=\"width:80px;height:20px;text-align:right;\" [(ngModel)]=\"numberField\" [disabled]=\"inputField.readonly\"/>\n                        <input *ngSwitchCase=\"'Number'\"  [name]=\"inputField.name\" type=\"number\" class=\"fieldEntry\"  style=\"width:80px;height:20px;\" [(ngModel)]=\"numberField\" [disabled]=\"inputField.readonly\"/>\n                        <input *ngSwitchCase=\"'float'\"  [name]=\"inputField.name\" type=\"number\" class=\"fieldEntry\"  style=\"width:80px;height:20px;\" [(ngModel)]=\"numberField\" [disabled]=\"inputField.readonly\"/>\n                        <input *ngSwitchCase=\"'boolean'\"  [name]=\"inputField.name\" type=\"checkbox\" class=\"fieldEntry\" style=\"height:30px;width:50px;margin-top:-6px;\" [(ngModel)]=\"booleanField\" [disabled]=\"inputField.readonly\"/>\n                        <textarea *ngSwitchCase=\"'json'\"  [name]=\"inputField.name\" type=\"text\" class=\"fieldEntry\"  cols=\"90\" style=\"resize:vertical;width:75%\" [(ngModel)]=\"objectField\" disabled></textarea>\n                        <img *ngSwitchCase=\"'picture'\" [src]=\"stringField | base64ImageRef\" style=\"height:300px;\"/>\n                     </span>    \n               \n                </div>\n \n            "
        }]
      }], function () {
        return [{
          type: js44d__WEBPACK_IMPORTED_MODULE_2__["FourDInterface"]
        }];
      }, {
        inputField: [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }],
        currentRecord: [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }],
        stringField: [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }],
        numberField: [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }],
        booleanField: [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }],
        dateField: [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }],
        timeField: [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }],
        objectField: [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }]
      });
    })();
    /***/

  },

  /***/
  "./src/app/browseTable/browseQuery.component.ts":
  /*!******************************************************!*\
    !*** ./src/app/browseTable/browseQuery.component.ts ***!
    \******************************************************/

  /*! exports provided: BrowseQueryBand */

  /***/
  function srcAppBrowseTableBrowseQueryComponentTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "BrowseQueryBand", function () {
      return BrowseQueryBand;
    });
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
    /* harmony import */


    var _browseQueryField_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./browseQueryField.component */
    "./src/app/browseTable/browseQueryField.component.ts");

    function BrowseQueryBand_div_1_browse_queryfield_1_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](0, "browse-queryfield", 4);
      }

      if (rf & 2) {
        var field_r24 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]().$implicit;

        var ctx_r25 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("queryField", field_r24)("queryData", ctx_r25.queryData);
      }
    }

    function BrowseQueryBand_div_1_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 2);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](1, BrowseQueryBand_div_1_browse_queryfield_1_Template, 1, 2, "browse-queryfield", 3);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
      }

      if (rf & 2) {
        var field_r24 = ctx.$implicit;

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", field_r24.quickQuery);
      }
    }

    var BrowseQueryBand = /*#__PURE__*/function () {
      function BrowseQueryBand() {
        _classCallCheck(this, BrowseQueryBand);

        this.queryData = {};
      } //
      // build 4C-TV query based on items from query band
      //


      _createClass(BrowseQueryBand, [{
        key: "currentQuery",
        get: function get() {
          var _this2 = this;

          var currQuery = [];
          this.queryFields.forEach(function (field) {
            if (field.quickQuery) {
              switch (field.type) {
                case 'string':
                  if (_this2.queryData[field.name] && _this2.queryData[field.name] !== '') {
                    currQuery.push(field.field + ';contains;' + _this2.queryData[field.name] + ';AND');
                  }

                  break;

                case 'number':
                case 'Number':
                case 'float':
                case 'boolean':
                case 'Time':
                  if (_this2.queryData[field.name] && _this2.queryData[field.name] !== '') {
                    currQuery.push(field.field + ';=;' + _this2.queryData[field.name] + ';AND');
                  }

                  break;

                case 'Date':
                  if (_this2.queryData[field.name] && _this2.queryData[field.name] !== '') {
                    currQuery.push(field.field + ';=;' + _this2.queryData[field.name].replace(/-/g, '') + ';AND');
                  }

                  break;
              }
            }
          });
          return currQuery.length > 0 ? {
            query: currQuery
          } : null; // {query:['all']};
        }
      }]);

      return BrowseQueryBand;
    }();

    BrowseQueryBand.ɵfac = function BrowseQueryBand_Factory(t) {
      return new (t || BrowseQueryBand)();
    };

    BrowseQueryBand.ɵcmp = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({
      type: BrowseQueryBand,
      selectors: [["browse-queryband"]],
      inputs: {
        queryFields: "queryFields",
        queryData: "queryData"
      },
      decls: 2,
      vars: 1,
      consts: [[2, "display", "flex", "overflow", "auto"], ["style", "float: left;height: 100%; margin-right: 10px;", 4, "ngFor", "ngForOf"], [2, "float", "left", "height", "100%", "margin-right", "10px"], [3, "queryField", "queryData", 4, "ngIf"], [3, "queryField", "queryData"]],
      template: function BrowseQueryBand_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "form", 0);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](1, BrowseQueryBand_div_1_Template, 2, 1, "div", 1);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        }

        if (rf & 2) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngForOf", ctx.queryFields);
        }
      },
      directives: [_angular_forms__WEBPACK_IMPORTED_MODULE_1__["ɵangular_packages_forms_forms_y"], _angular_forms__WEBPACK_IMPORTED_MODULE_1__["NgControlStatusGroup"], _angular_forms__WEBPACK_IMPORTED_MODULE_1__["NgForm"], _angular_common__WEBPACK_IMPORTED_MODULE_2__["NgForOf"], _angular_common__WEBPACK_IMPORTED_MODULE_2__["NgIf"], _browseQueryField_component__WEBPACK_IMPORTED_MODULE_3__["BrowseQueryField"]],
      encapsulation: 2
    });
    /*@__PURE__*/

    (function () {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](BrowseQueryBand, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"],
        args: [{
          moduleId: module.i,
          selector: 'browse-queryband',
          template: "\n                <form style=\"display:flex;overflow:auto\">\n                    <div *ngFor='let field of queryFields'  style=\"float: left;height: 100%; margin-right: 10px;\">\n                        <browse-queryfield *ngIf='field.quickQuery' [queryField]= \"field\" [queryData]=\"queryData\"></browse-queryfield>\n                    </div>\n                </form>\n            "
        }]
      }], null, {
        queryFields: [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }],
        queryData: [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }]
      });
    })();
    /***/

  },

  /***/
  "./src/app/browseTable/browseQueryField.component.ts":
  /*!***********************************************************!*\
    !*** ./src/app/browseTable/browseQueryField.component.ts ***!
    \***********************************************************/

  /*! exports provided: BrowseQueryField */

  /***/
  function srcAppBrowseTableBrowseQueryFieldComponentTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "BrowseQueryField", function () {
      return BrowseQueryField;
    });
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _browseTable_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! ./browseTable.component */
    "./src/app/browseTable/browseTable.component.ts");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");

    function BrowseQueryField_input_3_Template(rf, ctx) {
      if (rf & 1) {
        var _r35 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "input", 7);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("ngModelChange", function BrowseQueryField_input_3_Template_input_ngModelChange_0_listener($event) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r35);

          var ctx_r34 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();

          return ctx_r34.queryData[ctx_r34.queryField.name] = $event;
        });

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
      }

      if (rf & 2) {
        var ctx_r27 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("name", ctx_r27.queryField.name)("ngModel", ctx_r27.queryData[ctx_r27.queryField.name]);
      }
    }

    function BrowseQueryField_input_4_Template(rf, ctx) {
      if (rf & 1) {
        var _r37 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "input", 8);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("ngModelChange", function BrowseQueryField_input_4_Template_input_ngModelChange_0_listener($event) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r37);

          var ctx_r36 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();

          return ctx_r36.queryData[ctx_r36.queryField.name] = $event;
        });

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
      }

      if (rf & 2) {
        var ctx_r28 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("name", ctx_r28.queryField.name)("ngModel", ctx_r28.queryData[ctx_r28.queryField.name]);
      }
    }

    function BrowseQueryField_input_5_Template(rf, ctx) {
      if (rf & 1) {
        var _r39 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "input", 9);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("ngModelChange", function BrowseQueryField_input_5_Template_input_ngModelChange_0_listener($event) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r39);

          var ctx_r38 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();

          return ctx_r38.queryData[ctx_r38.queryField.name] = $event;
        });

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
      }

      if (rf & 2) {
        var ctx_r29 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("name", ctx_r29.queryField.name)("ngModel", ctx_r29.queryData[ctx_r29.queryField.name]);
      }
    }

    function BrowseQueryField_input_6_Template(rf, ctx) {
      if (rf & 1) {
        var _r41 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "input", 10);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("ngModelChange", function BrowseQueryField_input_6_Template_input_ngModelChange_0_listener($event) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r41);

          var ctx_r40 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();

          return ctx_r40.queryData[ctx_r40.queryField.name] = $event;
        });

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
      }

      if (rf & 2) {
        var ctx_r30 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("name", ctx_r30.queryField.name)("ngModel", ctx_r30.queryData[ctx_r30.queryField.name]);
      }
    }

    function BrowseQueryField_input_7_Template(rf, ctx) {
      if (rf & 1) {
        var _r43 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "input", 10);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("ngModelChange", function BrowseQueryField_input_7_Template_input_ngModelChange_0_listener($event) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r43);

          var ctx_r42 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();

          return ctx_r42.queryData[ctx_r42.queryField.name] = $event;
        });

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
      }

      if (rf & 2) {
        var ctx_r31 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("name", ctx_r31.queryField.name)("ngModel", ctx_r31.queryData[ctx_r31.queryField.name]);
      }
    }

    function BrowseQueryField_input_8_Template(rf, ctx) {
      if (rf & 1) {
        var _r45 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "input", 10);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("ngModelChange", function BrowseQueryField_input_8_Template_input_ngModelChange_0_listener($event) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r45);

          var ctx_r44 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();

          return ctx_r44.queryData[ctx_r44.queryField.name] = $event;
        });

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
      }

      if (rf & 2) {
        var ctx_r32 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("name", ctx_r32.queryField.name)("ngModel", ctx_r32.queryData[ctx_r32.queryField.name]);
      }
    }

    function BrowseQueryField_input_9_Template(rf, ctx) {
      if (rf & 1) {
        var _r47 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "input", 11);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("ngModelChange", function BrowseQueryField_input_9_Template_input_ngModelChange_0_listener($event) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r47);

          var ctx_r46 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();

          return ctx_r46.queryData[ctx_r46.queryField.name] = $event;
        });

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
      }

      if (rf & 2) {
        var ctx_r33 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("name", ctx_r33.queryField.name)("ngModel", ctx_r33.queryData[ctx_r33.queryField.name]);
      }
    }

    var BrowseQueryField = function BrowseQueryField() {
      _classCallCheck(this, BrowseQueryField);

      this.queryData = {};
    };

    BrowseQueryField.ɵfac = function BrowseQueryField_Factory(t) {
      return new (t || BrowseQueryField)();
    };

    BrowseQueryField.ɵcmp = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({
      type: BrowseQueryField,
      selectors: [["browse-queryfield"]],
      inputs: {
        queryField: "queryField",
        queryData: "queryData"
      },
      decls: 10,
      vars: 10,
      consts: [[1, "fieldPrompt", 2, "margin-right", "10px"], [3, "ngSwitch"], ["type", "text", "class", "fieldEntry", "style", "width:180px;height:20px;", 3, "name", "ngModel", "ngModelChange", 4, "ngSwitchCase"], ["type", "date", "class", "fieldEntry", "style", "width:125px;height:20px;", 3, "name", "ngModel", "ngModelChange", 4, "ngSwitchCase"], ["type", "time", "class", "fieldEntry", "style", "width:100px;height:20px;", 3, "name", "ngModel", "ngModelChange", 4, "ngSwitchCase"], ["type", "number", "class", "fieldEntry", "style", "width:80px;height:20px;", 3, "name", "ngModel", "ngModelChange", 4, "ngSwitchCase"], ["type", "checkbox", "class", "fieldEntry", "style", "width:80px;height:20px;", 3, "name", "ngModel", "ngModelChange", 4, "ngSwitchCase"], ["type", "text", 1, "fieldEntry", 2, "width", "180px", "height", "20px", 3, "name", "ngModel", "ngModelChange"], ["type", "date", 1, "fieldEntry", 2, "width", "125px", "height", "20px", 3, "name", "ngModel", "ngModelChange"], ["type", "time", 1, "fieldEntry", 2, "width", "100px", "height", "20px", 3, "name", "ngModel", "ngModelChange"], ["type", "number", 1, "fieldEntry", 2, "width", "80px", "height", "20px", 3, "name", "ngModel", "ngModelChange"], ["type", "checkbox", 1, "fieldEntry", 2, "width", "80px", "height", "20px", 3, "name", "ngModel", "ngModelChange"]],
      template: function BrowseQueryField_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "label", 0);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](2, "div", 1);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](3, BrowseQueryField_input_3_Template, 1, 2, "input", 2);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](4, BrowseQueryField_input_4_Template, 1, 2, "input", 3);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](5, BrowseQueryField_input_5_Template, 1, 2, "input", 4);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](6, BrowseQueryField_input_6_Template, 1, 2, "input", 5);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](7, BrowseQueryField_input_7_Template, 1, 2, "input", 5);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](8, BrowseQueryField_input_8_Template, 1, 2, "input", 5);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](9, BrowseQueryField_input_9_Template, 1, 2, "input", 6);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        }

        if (rf & 2) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵattribute"]("for", ctx.queryField.name);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate1"]("", ctx.queryField.title, ":\xA0\xA0 ");

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngSwitch", ctx.queryField.type);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngSwitchCase", "string");

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngSwitchCase", "Date");

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngSwitchCase", "Time");

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngSwitchCase", "number");

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngSwitchCase", "Number");

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngSwitchCase", "float");

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngSwitchCase", "boolean");
        }
      },
      directives: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["NgSwitch"], _angular_common__WEBPACK_IMPORTED_MODULE_2__["NgSwitchCase"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["DefaultValueAccessor"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["NgControlStatus"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["NgModel"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["NumberValueAccessor"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["CheckboxControlValueAccessor"]],
      encapsulation: 2
    });
    /*@__PURE__*/

    (function () {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](BrowseQueryField, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"],
        args: [{
          moduleId: module.i,
          selector: 'browse-queryfield',
          template: "\n                <label class=\"fieldPrompt\" [attr.for]=\"queryField.name\" style=\"margin-right:10px;\">{{queryField.title}}:&nbsp;&nbsp;\n                    <div [ngSwitch]=\"queryField.type\">\n                        <input *ngSwitchCase=\"'string'\"  [name]=\"queryField.name\" type=\"text\" class=\"fieldEntry\"  style=\"width:180px;height:20px;\" [(ngModel)]=\"queryData[queryField.name]\"/>\n                        <input *ngSwitchCase=\"'Date'\"  [name]=\"queryField.name\" type=\"date\" class=\"fieldEntry\"  style=\"width:125px;height:20px;\" [(ngModel)]=\"queryData[queryField.name]\"/>\n                        <input *ngSwitchCase=\"'Time'\"  [name]=\"queryField.name\" type=\"time\" class=\"fieldEntry\"  style=\"width:100px;height:20px;\" [(ngModel)]=\"queryData[queryField.name]\"/>\n                        <input *ngSwitchCase=\"'number'\"  [name]=\"queryField.name\" type=\"number\" class=\"fieldEntry\"  style=\"width:80px;height:20px;\" [(ngModel)]=\"queryData[queryField.name]\"/>\n                        <input *ngSwitchCase=\"'Number'\"  [name]=\"queryField.name\" type=\"number\" class=\"fieldEntry\"  style=\"width:80px;height:20px;\" [(ngModel)]=\"queryData[queryField.name]\"/>\n                        <input *ngSwitchCase=\"'float'\"  [name]=\"queryField.name\" type=\"number\" class=\"fieldEntry\"  style=\"width:80px;height:20px;\" [(ngModel)]=\"queryData[queryField.name]\"/>\n                        <input *ngSwitchCase=\"'boolean'\"  [name]=\"queryField.name\" type=\"checkbox\" class=\"fieldEntry\"  style=\"width:80px;height:20px;\" [(ngModel)]=\"queryData[queryField.name]\"/>\n                     </div>    \n                </label>\n \n            "
        }]
      }], null, {
        queryField: [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }],
        queryData: [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }]
      });
    })();
    /***/

  },

  /***/
  "./src/app/browseTable/browseTable.component.ts":
  /*!******************************************************!*\
    !*** ./src/app/browseTable/browseTable.component.ts ***!
    \******************************************************/

  /*! exports provided: FieldDescription, BrowseTableComponent */

  /***/
  function srcAppBrowseTableBrowseTableComponentTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "FieldDescription", function () {
      return FieldDescription;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "BrowseTableComponent", function () {
      return BrowseTableComponent;
    });
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/common/http */
    "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/http.js");
    /* harmony import */


    var js44d__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! js44d */
    "./node_modules/js44d/__ivy_ngcc__/fesm2015/js44d.js");
    /* harmony import */


    var _browseFormDialog_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./browseFormDialog.component */
    "./src/app/browseTable/browseFormDialog.component.ts");

    function BrowseTableComponent_tr_17_Template(rf, ctx) {
      if (rf & 1) {
        var _r10 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "tr", 33);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function BrowseTableComponent_tr_17_Template_tr_click_0_listener($event) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r10);

          var ctx_r9 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();

          return ctx_r9.selectTable($event);
        });

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "td", 41);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](2);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
      }

      if (rf & 2) {
        var table_r8 = ctx.$implicit;

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](table_r8);
      }
    }

    function BrowseTableComponent_span_24_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "span");

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1, "\xBB");

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
      }
    }

    function BrowseTableComponent_li_26_Template(rf, ctx) {
      if (rf & 1) {
        var _r13 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "li", 33);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function BrowseTableComponent_li_26_Template_li_click_0_listener($event) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r13);

          var ctx_r12 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();

          return ctx_r12.showRelatedTable($event);
        });

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "h5");

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](2);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
      }

      if (rf & 2) {
        var relatedTable_r11 = ctx.$implicit;

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](relatedTable_r11);
      }
    }

    function BrowseTableComponent_tr_29_Template(rf, ctx) {
      if (rf & 1) {
        var _r16 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "tr", 42);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("dragstart", function BrowseTableComponent_tr_29_Template_tr_dragstart_0_listener($event) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r16);

          var ctx_r15 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();

          return ctx_r15.startDrag($event, "field");
        });

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "td", 41);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](2);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
      }

      if (rf & 2) {
        var field_r14 = ctx.$implicit;

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](field_r14.name);
      }
    }

    function BrowseTableComponent_tr_35_Template(rf, ctx) {
      if (rf & 1) {
        var _r19 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "tr", 43);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function BrowseTableComponent_tr_35_Template_tr_click_0_listener($event) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r19);

          var ctx_r18 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();

          return ctx_r18.selectColumn($event);
        })("drop", function BrowseTableComponent_tr_35_Template_tr_drop_0_listener($event) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r19);

          var ctx_r20 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();

          return ctx_r20.handleDrop($event);
        })("dragstart", function BrowseTableComponent_tr_35_Template_tr_dragstart_0_listener($event) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r19);

          var ctx_r21 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();

          return ctx_r21.startDrag($event, "column");
        })("dragleave", function BrowseTableComponent_tr_35_Template_tr_dragleave_0_listener($event) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r19);

          var ctx_r22 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();

          return ctx_r22.disableDrop($event);
        });

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "td", 41);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](2);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
      }

      if (rf & 2) {
        var column_r17 = ctx.$implicit;

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);

        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](column_r17.name);
      }
    }

    var FieldDescription = function FieldDescription() {
      _classCallCheck(this, FieldDescription);
    };

    var BrowseTableComponent = /*#__PURE__*/function () {
      function BrowseTableComponent(http, fourD, modal, viewref) {
        var _this3 = this;

        _classCallCheck(this, BrowseTableComponent);

        this.http = http;
        this.fourD = fourD;
        this.modal = modal;
        this.viewref = viewref;
        this.numOfTables = 0;
        this.listOfTables = [];
        this.currentTable = '';
        this.listedTable = '';
        this.listOfFields = [];
        this.listOfColumns = [];
        this.relatedOneTables = [];
        this.currentField = new FieldDescription();
        this.queryData = {};
        this.hideBrowseConfig = false;
        this.currentGridHeight = 'calc(100% - 330px)'; // Declare Program edit Window
        //

        this.editWindow = _browseFormDialog_component__WEBPACK_IMPORTED_MODULE_3__["BrowseFormDialog"]; // the columns for the datagrid

        this.columnDefs = [{
          title: 'Record ID',
          field: 'RecordID',
          width: ''
        }]; //
        // Declare Datagrid properties
        //

        this.model = js44d__WEBPACK_IMPORTED_MODULE_2__["FourDModel"]; // the record datamodel to use 

        this.selectedRow = null;
        this.selectedColumn = null;
        this.selectedColumnIndex = -1;
        this.totalRecordCount = 0;
        this.models = [];
        /* tslint:disable */
        // need to disable lint here otw if'll flag variable before method rule, but I'm puting this at the button
        // on purpose, to have it out of the way
        //
        // define the dataSource used to populate/handle the grid's interface to 4D
        //

        this.dataSource = new kendo.data.DataSource({
          /* tslint:enabe */
          transport: {
            read: function read(options) {
              // console.log(options);
              var newModel = new js44d__WEBPACK_IMPORTED_MODULE_2__["FourDModel"]();
              newModel.tableName = _this3.currentTable;
              var start = options.data.pageSize && options.data.pageSize > 0 ? options.data.skip : 0;
              var numrecs = options.data.pageSize && options.data.pageSize > 0 ? options.data.pageSize : -1; // now build filter if set

              var filter = [];

              if (options.data.filter) {
                options.data.filter.filters.forEach(function (item) {
                  var comparator = '=';

                  switch (item.operator) {
                    case 'eq':
                      comparator = '=';
                      break;

                    case 'neq':
                      comparator = '#';
                      break;

                    case 'startswith':
                      comparator = 'begins with';
                      break;

                    case 'endswith':
                      comparator = 'ends with';
                      break;

                    case 'isempty':
                      comparator = '=';
                      item.value = '';
                      break;

                    case 'isnotempty':
                      comparator = '#';
                      item.value = '';
                      break;

                    default:
                      comparator = item.operator;
                      break;
                  }

                  filter.push(newModel.tableName + '.' + item.field + ';' + comparator + ';' + item.value + ';' + options.data.filter.logic);
                });
              }

              var orderby = '';

              if (options.data.sort && options.data.sort.length > 0) {
                options.data.sort.forEach(function (item) {
                  orderby += item.dir === 'asc' ? '>' : '<';
                  orderby += newModel.tableName + '.' + item.field + '%';
                });
              }

              var query = _this3.theGrid.getDataProvider().queryString;

              var body = {
                Username: js44d__WEBPACK_IMPORTED_MODULE_2__["FourDInterface"].currentUser
              };
              body.TableName = newModel.tableName;
              body.StartRec = start;
              body.NumRecs = numrecs;
              body.QueryString = JSON.stringify(query);
              body.Columns = js44d__WEBPACK_IMPORTED_MODULE_2__["Base64"].encode(js44d__WEBPACK_IMPORTED_MODULE_2__["Utf8"].utf8encode(JSON.stringify(_this3.listOfColumns)));

              if (filter.length > 0) {
                body.FilterOptions = JSON.stringify({
                  query: filter
                });
              }

              if (orderby) {
                body.OrderBy = orderby;
              }

              _this3.fourD.call4DRESTMethod('REST_GetRecords', body).subscribe(function (resultJSON) {
                _this3.totalRecordCount = 0;
                _this3.models = [];
                var data = [];

                if (resultJSON && resultJSON['selected'] && resultJSON['records']) {
                  _this3.totalRecordCount = resultJSON['selected'];
                  var recList = resultJSON['records'];
                  recList.forEach(function (record) {
                    var theModel = new js44d__WEBPACK_IMPORTED_MODULE_2__["FourDModel"]();
                    theModel.recordNumber = record['_recnum'];

                    _this3.models.push(theModel);

                    data.push(record);
                  });
                }

                _this3.theGrid.getDataProvider().models = _this3.models;
                options.success(data);
              }, function (error) {
                console.log('error:' + JSON.stringify(error));
              });
            },
            destroy: function destroy(options) {
              console.log('delete', options);
            },
            update: function update(options) {
              console.log('update', options);
            },
            create: function create(options) {
              console.log('create', options);
            },
            parameterMap: function parameterMap(options, operation) {
              console.log('map', options);

              if (operation !== 'read' && options.models) {
                return {
                  models: kendo.stringify(options.models)
                };
              } else {
                return options;
              }
            }
          },
          schema: {
            total: function total(response) {
              // console.log('total');
              return _this3.totalRecordCount;
            }
          },
          serverPaging: true,
          serverSorting: true,
          serverFiltering: true,
          serverGrouping: true,
          pageSize: 50
        });
      }

      _createClass(BrowseTableComponent, [{
        key: "ngAfterContentInit",
        value: function ngAfterContentInit() {
          var _this4 = this;

          this.fourD.call4DRESTMethod('REST_GetListOfTables', {}).subscribe(function (resultJSON) {
            _this4.numOfTables = resultJSON.tableCount;
            _this4.listOfTables = resultJSON.tableList;

            _this4.listOfTables.sort();

            _this4.recordList.queryBand.switchState();
          });
        }
      }, {
        key: "hideConfig",
        value: function hideConfig() {
          this.hideBrowseConfig = true;
          this.currentGridHeight = 'calc(100% - 30px)';
          this.recordList.theGrid.resize();
          this.recordList.refreshGrid();
        }
      }, {
        key: "showConfig",
        value: function showConfig() {
          this.hideBrowseConfig = false;
          this.currentGridHeight = 'calc(100% - 330px)';
          this.recordList.theGrid.resize();
          this.recordList.refreshGrid();
        }
      }, {
        key: "saveConfig",
        value: function saveConfig() {
          if (this.currentTable !== '') {
            localStorage.setItem('4Dbrowse' + this.currentTable, JSON.stringify(this.listOfColumns));
          }
        }
      }, {
        key: "loadConfig",
        value: function loadConfig() {
          if (this.currentTable !== '') {
            var config = localStorage.getItem('4Dbrowse' + this.currentTable);

            if (config && config !== '') {
              // we have a saved configuration, use it...
              this.listOfColumns = JSON.parse(config);
              this.mapColumnsToGrid(); // update grid then
            }
          }
        }
      }, {
        key: "selectTable",
        value: function selectTable(event) {
          var _this5 = this;

          if (this.selectedRow) {
            this.selectedRow.classList.remove('selectedItem');
          }

          var selectRow = event.currentTarget.rowIndex;

          if (selectRow < this.numOfTables) {
            this.selectedRow = event.target;
            this.currentTable = this.listOfTables[selectRow];
            this.listedTable = this.currentTable;
            this.fourD.call4DRESTMethod('REST_GetFieldsInTable', {
              TableName: this.listOfTables[selectRow]
            }).subscribe(function (resultJSON) {
              _this5.listOfFields = resultJSON.fieldList;

              _this5.selectedRow.classList.add('selectedItem');

              _this5.model.prototype.tableName = _this5.currentTable;
              _this5.model.prototype.fields = _this5.listOfFields;
              _this5.model.prototype.primaryKey_ = resultJSON.primaryKey; // set default columns

              _this5.listOfColumns = [];
              _this5.relatedOneTables = [_this5.currentTable];
              _this5.queryData = {};

              for (var index = 0; index < _this5.listOfFields.length; index++) {
                var element = _this5.listOfFields[index];
                element.field = element.longname;
                element.title = element.name;

                if (element.indexed) {
                  element.quickQuery = true;

                  _this5.listOfColumns.push(element);
                } else {
                  element.quickQuery = false;
                }

                if (element.relatesTo && element.relatesTo !== '') {
                  _this5.relatedOneTables.push(element.relatesTo.split('.')[0]);
                }
              }

              _this5.mapColumnsToGrid(); // update datagrid columns

            });
          }
        }
      }, {
        key: "selectColumn",
        value: function selectColumn(event) {
          if (this.selectedColumn) {
            this.selectedColumn.classList.remove('selectedItem');
          }

          this.selectedColumnIndex = event.currentTarget.rowIndex;

          if (this.selectedColumnIndex < this.listOfColumns.length) {
            this.selectedColumn = event.target;
            this.selectedColumn.classList.add('selectedItem');
            this.currentField = this.listOfColumns[this.selectedColumnIndex];
          } else {
            this.selectedColumnIndex = -1;
          }
        }
      }, {
        key: "startDrag",
        value: function startDrag(event, type) {
          event.effectAllowed = 'copy';
          event.dataTransfer.setData('type', type);
          event.dataTransfer.setData('row', event.currentTarget.rowIndex);
        }
      }, {
        key: "allowDrop",
        value: function allowDrop(event) {
          if (event.preventDefault) {
            event.preventDefault();
          } // Necessary. Allows us to drop.


          if (event.stopPropagation) {
            event.stopPropagation();
          }

          if (event.type === 'dragenter') {
            event.target.classList.add('droppable');
            event.dataTransfer.dropEffect = 'copy'; // See the section on the DataTransfer object.
          }

          return false;
        }
      }, {
        key: "disableDrop",
        value: function disableDrop(event) {
          if (event.stopPropagation) {
            event.stopPropagation();
          }

          event.target.classList.remove('droppable');
        }
      }, {
        key: "handleDrop",
        value: function handleDrop(event) {
          if (event.stopPropagation) {
            event.stopPropagation();
          }

          this.disableDrop(event);
          var source = event.dataTransfer.getData('type');
          var row = event.dataTransfer.getData('row');
          var element = this.listOfFields[row];
          element.quickQuery = false;

          if (event.currentTarget.localName === 'tbody') {
            if (source === 'field') {
              this.listOfColumns.push(element);
            } else {
              this.listOfColumns.push(element);
              this.listOfColumns.splice(row, 1);
            }
          } else {
            if (source === 'field') {
              this.listOfColumns.splice(event.currentTarget.rowIndex, 0, element);
            } else {
              var moveToIndex = event.currentTarget.rowIndex;
              var item = this.listOfColumns.splice(row, 1);

              if (row < moveToIndex) {
                // moving up...
                this.listOfColumns.splice(event.currentTarget.rowIndex - 1, 0, item[0]);
              } else {
                // moving down
                this.listOfColumns.splice(event.currentTarget.rowIndex, 0, item[0]);
              }
            }
          }

          this.mapColumnsToGrid(); // update datagrid columns
        }
      }, {
        key: "deleteField",
        value: function deleteField() {
          if (this.selectedColumnIndex >= 0) {
            this.listOfColumns.splice(this.selectedColumnIndex, 1);
            this.selectedColumnIndex = -1;
            this.selectedColumn = null;
            this.currentField = new FieldDescription();
            this.mapColumnsToGrid();
          }
        }
      }, {
        key: "mapColumnsToGrid",
        value: function mapColumnsToGrid() {
          var _this6 = this;

          this.columnDefs = [];

          for (var index = 0; index < this.listOfColumns.length; index++) {
            var element = this.listOfColumns[index];
            this.columnDefs.push({
              title: element.title,
              field: element.name,
              width: element['width'] ? element['width'] : ''
            });
          } // this.theGrid.setColumnConfig(this.columnDefs);


          this.theGrid.setExternalDataSource(this.dataSource, this.columnDefs);
          this.recordList.clearQuery(); // clear any previous query

          this.theGrid.loadData(); // and clear the grid

          this.theGrid.gridObject.bind('columnResize', function () {
            _this6.saveColumnConfig();
          });
        }
      }, {
        key: "showRelatedTable",
        value: function showRelatedTable(event) {
          var _this7 = this;

          this.listedTable = event.target.textContent;
          this.fourD.call4DRESTMethod('REST_GetFieldsInTable', {
            TableName: this.listedTable
          }).subscribe(function (resultJSON) {
            _this7.listOfFields = resultJSON.fieldList;

            for (var index = 0; index < _this7.listOfFields.length; index++) {
              var element = _this7.listOfFields[index];
              element.field = element.longname;
              element.title = element.name;
              element.quickQuery = false;
            }
          });
        }
      }, {
        key: "addRecord",
        value: function addRecord() {
          var newModel = new js44d__WEBPACK_IMPORTED_MODULE_2__["FourDModel"]();
          newModel.tableName = this.currentTable;
          newModel.fields = this.listOfFields;
          newModel.clearRecord();
          this.modal.openInside(this.editWindow, this.viewref, newModel, this.editWindow['dialogConfig']); // open edit dialog
        }
      }, {
        key: "noTableSelected",
        value: function noTableSelected() {
          return this.currentTable === '';
        }
      }, {
        key: "saveColumnConfig",
        value: function saveColumnConfig() {
          if (this.currentTable !== '') {
            for (var i = 0; i < this.listOfColumns.length; i++) {
              if (this.theGrid.gridObject.columns[i]['width'] && this.theGrid.gridObject.columns[i]['width'] > 0) {
                this.listOfColumns[i]['width'] = this.theGrid.gridObject.columns[i]['width'];
              }
            }
          }
        }
      }]);

      return BrowseTableComponent;
    }();

    BrowseTableComponent.dialogConfig = {
      actions: ['Maximize', 'Minimize', 'Close'],
      position: {
        top: 100,
        left: 50
      },
      selfCentered: true,
      title: 'Browse Table',
      isResizable: true,
      width: 1200,
      height: 800,
      minWidth: 1200,
      minHeight: 700
    };

    BrowseTableComponent.ɵfac = function BrowseTableComponent_Factory(t) {
      return new (t || BrowseTableComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpClient"]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](js44d__WEBPACK_IMPORTED_MODULE_2__["FourDInterface"]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](js44d__WEBPACK_IMPORTED_MODULE_2__["Modal"]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_0__["ViewContainerRef"]));
    };

    BrowseTableComponent.ɵcmp = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({
      type: BrowseTableComponent,
      selectors: [["sd-browse-table"]],
      viewQuery: function BrowseTableComponent_Query(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵviewQuery"](js44d__WEBPACK_IMPORTED_MODULE_2__["RecordList"], true);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵviewQuery"](js44d__WEBPACK_IMPORTED_MODULE_2__["DataGrid"], true);
        }

        if (rf & 2) {
          var _t;

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵloadQuery"]()) && (ctx.recordList = _t.first);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵloadQuery"]()) && (ctx.theGrid = _t.first);
        }
      },
      inputs: {
        numOfTables: "numOfTables",
        listOfTables: "listOfTables",
        currentTable: "currentTable",
        listedTable: "listedTable",
        listOfFields: "listOfFields",
        listOfColumns: "listOfColumns",
        relatedOneTables: "relatedOneTables",
        currentField: "currentField",
        queryData: "queryData",
        hideBrowseConfig: "hideBrowseConfig",
        currentGridHeight: "currentGridHeight"
      },
      features: [_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵProvidersFeature"]([_angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpClient"], js44d__WEBPACK_IMPORTED_MODULE_2__["FourDInterface"], js44d__WEBPACK_IMPORTED_MODULE_2__["Modal"]])],
      decls: 75,
      vars: 35,
      consts: [[2, "text-align", "center"], [2, "display", "inline-flex", "width", "100%", "z-index", "5", "position", "absolute", "top", "25px", "padding-left", "10px"], ["title", "collapse browse config"], [2, "background", "#eaeef1", "border-style", "solid", "border-width", "1px", "border-radius", "5px", 3, "hidden", "click"], ["title", "expand browse config"], [1, "container-fluid", 2, "margin-left", "10px", "height", "calc(100% - 65px)", "width", "calc(100% - 40px)"], [1, "row", 3, "hidden"], [1, "col-sm-3", "block"], [1, "listTable"], [1, "listBody"], [3, "click", 4, "ngFor", "ngForOf"], [1, "col-sm-2", "block"], ["id", "nav"], ["id", "navigation"], [2, "margin-left", "-40px"], [4, "ngIf"], ["draggable", "true", "style", "cursor: move;", 3, "dragstart", 4, "ngFor", "ngForOf"], [1, "listTable", 2, "height", "210px"], [1, "listBody", 3, "dragenter", "dragover", "dragend", "dragleave", "drop"], ["draggable", "true", 3, "click", "drop", "dragstart", "dragleave", 4, "ngFor", "ngForOf"], [2, "margin-top", "10px", "margin-bottom", "5px", "display", "flex", "justify-content", "space-around"], [1, "regularButton", 3, "disabled", "click"], [1, "col-sm-4", "block", 2, "border-style", "solid", "border-width", "thin", "padding-bottom", "4px", 3, "hidden"], [1, "form-horizontal", 2, "height", "250px"], [1, "form-group"], ["for", "field", 1, "control-label", "col-sm-2"], [1, "col-sm-6"], ["name", "fieldName", "type", "text", "disabled", "", 1, "form-control", 2, "width", "270px", 3, "ngModel", "ngModelChange"], ["for", "pwd", 1, "control-label", "col-sm-2"], ["name", "title", "type", "text", "id", "title", 1, "form-control", 2, "width", "270px", 3, "ngModel", "ngModelChange", "change"], [1, "col-sm-offset-2", "col-sm-10"], [1, "checkbox"], ["name", "indexed", "type", "checkbox", 3, "ngModel", "ngModelChange", "change"], [3, "click"], [1, "row", 2, "border-style", "solid", "border-width", "thin", "padding-bottom", "4px", 3, "hidden"], [2, "width", "100%", "height", "100%", 3, "editWindow", "dialogInstance"], [3, "enableSort", "enableQBE", "enableButtonBar", "enableAddRecord", "enableDeleteRecord", "enableExportGrid"], [3, "queryFields", "queryData", "queryDataChange"], ["customQueryBand", ""], [1, "regularButton", 2, "width", "70px", 3, "click"], [3, "model", "selectionMode", "columns", "useLazyLoading", "optimizeGridLoading", "pageSize", "excelFilename"], [1, "listItem"], ["draggable", "true", 2, "cursor", "move", 3, "dragstart"], ["draggable", "true", 3, "click", "drop", "dragstart", "dragleave"]],
      template: function BrowseTableComponent_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "web-application");

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "h2", 0);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](2, "Browse Table");

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](3, "div", 1);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](4, "span", 2);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](5, "h6", 3);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function BrowseTableComponent_Template_h6_click_5_listener() {
            return ctx.hideConfig();
          });

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](6, "\u21C8\u21C8\u21C8");

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](7, "span", 4);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](8, "h6", 3);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function BrowseTableComponent_Template_h6_click_8_listener() {
            return ctx.showConfig();
          });

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](9, "\u21CA\u21CA\u21CA");

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](10, "div", 5);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](11, "div", 6);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](12, "div", 7);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](13, "h4");

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](14, "Select Table");

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](15, "table", 8);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](16, "tbody", 9);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](17, BrowseTableComponent_tr_17_Template, 3, 1, "tr", 10);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](18, "div", 11);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](19, "nav", 12);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](20, "ul", 13);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](21, "li", 14);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](22, "h4");

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](23);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](24, BrowseTableComponent_span_24_Template, 2, 0, "span", 15);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](25, "ul");

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](26, BrowseTableComponent_li_26_Template, 3, 1, "li", 10);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](27, "table", 8);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](28, "tbody", 9);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](29, BrowseTableComponent_tr_29_Template, 3, 1, "tr", 16);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](30, "div", 7);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](31, "h4");

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](32, "Columns");

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](33, "table", 17);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](34, "tbody", 18);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("dragenter", function BrowseTableComponent_Template_tbody_dragenter_34_listener($event) {
            return ctx.allowDrop($event);
          })("dragover", function BrowseTableComponent_Template_tbody_dragover_34_listener($event) {
            return ctx.allowDrop($event);
          })("dragend", function BrowseTableComponent_Template_tbody_dragend_34_listener($event) {
            return ctx.disableDrop($event);
          })("dragleave", function BrowseTableComponent_Template_tbody_dragleave_34_listener($event) {
            return ctx.disableDrop($event);
          })("drop", function BrowseTableComponent_Template_tbody_drop_34_listener($event) {
            return ctx.handleDrop($event);
          });

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](35, BrowseTableComponent_tr_35_Template, 3, 1, "tr", 19);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](36, "div", 20);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](37, "button", 21);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function BrowseTableComponent_Template_button_click_37_listener() {
            return ctx.loadConfig();
          });

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](38, "Load Config");

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](39, "button", 21);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function BrowseTableComponent_Template_button_click_39_listener() {
            return ctx.saveConfig();
          });

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](40, "Save Config");

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](41, "div", 22);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](42, "h4");

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](43, "Column Info");

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](44, "form", 23);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](45, "div", 24);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](46, "label", 25);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](47, "Field:");

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](48, "div", 26);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](49, "input", 27);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("ngModelChange", function BrowseTableComponent_Template_input_ngModelChange_49_listener($event) {
            return ctx.currentField.name = $event;
          });

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](50, "div", 24);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](51, "label", 28);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](52, "Title:");

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](53, "div", 26);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](54, "input", 29);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("ngModelChange", function BrowseTableComponent_Template_input_ngModelChange_54_listener($event) {
            return ctx.currentField.title = $event;
          })("change", function BrowseTableComponent_Template_input_change_54_listener() {
            return ctx.mapColumnsToGrid();
          });

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](55, "div", 24);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](56, "div", 30);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](57, "div", 31);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](58, "label");

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](59, "input", 32);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("ngModelChange", function BrowseTableComponent_Template_input_ngModelChange_59_listener($event) {
            return ctx.currentField.quickQuery = $event;
          })("change", function BrowseTableComponent_Template_input_change_59_listener() {
            return ctx.mapColumnsToGrid();
          });

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](60, " is present on Quick Query");

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](61, "div", 24);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](62, "div", 30);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](63, "button", 33);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function BrowseTableComponent_Template_button_click_63_listener() {
            return ctx.deleteField();
          });

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](64, "Delete");

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](65, "div", 34);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](66, "record-list", 35);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](67, "query-band", 36);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](68, "queryband", 24);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](69, "browse-queryband", 37, 38);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("queryDataChange", function BrowseTableComponent_Template_browse_queryband_queryDataChange_69_listener($event) {
            return ctx.queryData = $event;
          });

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](71, "custombuttonbar");

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](72, "button", 39);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function BrowseTableComponent_Template_button_click_72_listener() {
            return ctx.addRecord();
          });

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](73, "Add");

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](74, "datagrid", 40);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        }

        if (rf & 2) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](5);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("hidden", ctx.hideBrowseConfig);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](3);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("hidden", !ctx.hideBrowseConfig);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](3);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("hidden", ctx.hideBrowseConfig);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](6);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngForOf", ctx.listOfTables);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](6);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate1"]("", ctx.listedTable, "\xA0");

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx.listedTable.length > 0);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngForOf", ctx.relatedOneTables);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](3);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngForOf", ctx.listOfFields);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](6);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngForOf", ctx.listOfColumns);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("disabled", ctx.noTableSelected());

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("disabled", ctx.noTableSelected());

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("hidden", !ctx.currentField.name);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](8);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngModel", ctx.currentField.name);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](5);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngModel", ctx.currentField.title);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](5);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngModel", ctx.currentField.quickQuery);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](6);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵstyleProp"]("height", ctx.currentGridHeight);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("hidden", ctx.currentTable === "");

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("editWindow", ctx.editWindow)("dialogInstance", ctx.dialog);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("enableSort", true)("enableQBE", true)("enableButtonBar", true)("enableAddRecord", false)("enableDeleteRecord", true)("enableExportGrid", false);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("queryFields", ctx.listOfColumns)("queryData", ctx.queryData);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](5);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("model", ctx.model)("selectionMode", "multiple,row")("columns", ctx.columnDefs)("useLazyLoading", true)("optimizeGridLoading", true)("pageSize", 50)("excelFilename", "RecordList.xlsx");
        }
      },
      styles: [".block[_ngcontent-%COMP%] {\n    border-style: solid; \n    border-width: thin; \n    padding-bottom: 4px; \n    display:flex; \n    flex-direction: column; \n    height: 289px;\n}\n\n.listTable[_ngcontent-%COMP%] {\n    border: 1px solid black;\n    border-collapse: collapse;\n    width: 100%;\n    height: 250px;;\n}\n\n.listBody[_ngcontent-%COMP%] {\n    overflow: auto;\n    display: block;\n    height: 100%;\n}\n\n.listItem[_ngcontent-%COMP%] {\n    padding-left: 3px;\n    border-style: none;\n}\n\n.selectedItem[_ngcontent-%COMP%] {\n    background: brown;\n    color: white;\n}\n\n.highlight[_ngcontent-%COMP%] {\n    background-color: #00FF00;\n}\n\n.droppable[_ngcontent-%COMP%] {\n    border: 2px dashed gray;\n}\n\n.icon[_ngcontent-%COMP%] {\n    font-family: FontAwesome, fontawesome;\n    font-size: 24;\n }\n\n\n\nul#navigation[_ngcontent-%COMP%] {\n    margin:0px auto;\n    position:relative;\n    float:left;\n}\n\nul#navigation[_ngcontent-%COMP%]   li[_ngcontent-%COMP%] {\n    display:inline;\n    float:left;\n\n}\n\nul#navigation[_ngcontent-%COMP%]   li[_ngcontent-%COMP%]   h5[_ngcontent-%COMP%] {\n    padding:5px 5px 5px 15px;\n    display:inline-block;\n    margin: 5px 0 0 0;\n    width: 100%;\n}\n\nul#navigation[_ngcontent-%COMP%]   li[_ngcontent-%COMP%]   h5[_ngcontent-%COMP%]:hover {\n    background:#f8f8f8;\n    color:#282828;\n}\n\nul#navigation[_ngcontent-%COMP%]   li[_ngcontent-%COMP%]:hover    > a[_ngcontent-%COMP%] {\n    background:#fff;\n}\n\n\n\nul#navigation[_ngcontent-%COMP%]   li[_ngcontent-%COMP%]:hover    > ul[_ngcontent-%COMP%]\n{\n\n    visibility:visible;\n    opacity:1;\n}\n\nul#navigation[_ngcontent-%COMP%]   ul[_ngcontent-%COMP%], ul#navigation[_ngcontent-%COMP%]   ul[_ngcontent-%COMP%]   li[_ngcontent-%COMP%]   ul[_ngcontent-%COMP%] {\n    list-style: none;\n    margin-left: 10px;\n    padding: 0;\n\n    visibility:hidden;\n    opacity:0;\n    position: absolute;\n    z-index: 99999;\n    width:180px;\n    background:#ddd;\n    box-shadow:1px 1px 3px #ccc;\n\n    transition:opacity 0.2s linear, visibility 0.2s linear;\n}\n\nul#navigation[_ngcontent-%COMP%]   ul[_ngcontent-%COMP%] {\n    top: 25px;\n    left: 10px;\n}\n\nul#navigation[_ngcontent-%COMP%]   ul[_ngcontent-%COMP%]   li[_ngcontent-%COMP%]   ul[_ngcontent-%COMP%] {\n    top: 0;\n    left: 181px; \n}\n\nul#navigation[_ngcontent-%COMP%]   ul[_ngcontent-%COMP%]   li[_ngcontent-%COMP%] {\n    clear:both;\n    width:100%;\n    border:0 none;\n    border-bottom:1px solid #c9c9c9;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvYnJvd3NlVGFibGUvYnJvd3NlVGFibGUuY29tcG9uZW50LmNzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtJQUNJLG1CQUFtQjtJQUNuQixrQkFBa0I7SUFDbEIsbUJBQW1CO0lBQ25CLFlBQVk7SUFDWixzQkFBc0I7SUFDdEIsYUFBYTtBQUNqQjs7QUFFQTtJQUNJLHVCQUF1QjtJQUN2Qix5QkFBeUI7SUFDekIsV0FBVztJQUNYLGFBQWE7QUFDakI7O0FBRUE7SUFDSSxjQUFjO0lBQ2QsY0FBYztJQUNkLFlBQVk7QUFDaEI7O0FBRUE7SUFDSSxpQkFBaUI7SUFDakIsa0JBQWtCO0FBQ3RCOztBQUVBO0lBQ0ksaUJBQWlCO0lBQ2pCLFlBQVk7QUFDaEI7O0FBR0E7SUFDSSx5QkFBeUI7QUFDN0I7O0FBRUE7SUFDSSx1QkFBdUI7QUFDM0I7O0FBRUE7SUFDSSxxQ0FBcUM7SUFDckMsYUFBYTtDQUNoQjs7QUFFRCxvQkFBb0I7O0FBR3BCO0lBQ0ksZUFBZTtJQUNmLGlCQUFpQjtJQUNqQixVQUFVO0FBQ2Q7O0FBRUE7SUFDSSxjQUFjO0lBQ2QsVUFBVTs7QUFFZDs7QUFFQTtJQUNJLHdCQUF3QjtJQUN4QixvQkFBb0I7SUFDcEIsaUJBQWlCO0lBQ2pCLFdBQVc7QUFDZjs7QUFFQTtJQUNJLGtCQUFrQjtJQUNsQixhQUFhO0FBQ2pCOztBQUlBO0lBQ0ksZUFBZTtBQUNuQjs7QUFDQSx5QkFBeUI7O0FBQ3pCOztBQUVBOzREQUM0RDtJQUN4RCxrQkFBa0I7SUFDbEIsU0FBUztBQUNiOztBQUVBO0lBQ0ksZ0JBQWdCO0lBQ2hCLGlCQUFpQjtJQUNqQixVQUFVO0FBQ2Q7d0RBQ3dEO0lBQ3BELGlCQUFpQjtJQUNqQixTQUFTO0lBQ1Qsa0JBQWtCO0lBQ2xCLGNBQWM7SUFDZCxXQUFXO0lBQ1gsZUFBZTtJQUNmLDJCQUEyQjtBQUMvQiw2Q0FBNkM7SUFJekMsc0RBQXNEO0FBQzFEOztBQUVBO0lBQ0ksU0FBUztJQUNULFVBQVU7QUFDZDs7QUFFQTtJQUNJLE1BQU07SUFDTixXQUFXLEVBQUUsOENBQThDO0FBQy9EOztBQUVBO0lBQ0ksVUFBVTtJQUNWLFVBQVU7SUFDVixhQUFhO0lBQ2IsK0JBQStCO0FBQ25DIiwiZmlsZSI6InNyYy9hcHAvYnJvd3NlVGFibGUvYnJvd3NlVGFibGUuY29tcG9uZW50LmNzcyIsInNvdXJjZXNDb250ZW50IjpbIi5ibG9jayB7XG4gICAgYm9yZGVyLXN0eWxlOiBzb2xpZDsgXG4gICAgYm9yZGVyLXdpZHRoOiB0aGluOyBcbiAgICBwYWRkaW5nLWJvdHRvbTogNHB4OyBcbiAgICBkaXNwbGF5OmZsZXg7IFxuICAgIGZsZXgtZGlyZWN0aW9uOiBjb2x1bW47IFxuICAgIGhlaWdodDogMjg5cHg7XG59XG5cbi5saXN0VGFibGUge1xuICAgIGJvcmRlcjogMXB4IHNvbGlkIGJsYWNrO1xuICAgIGJvcmRlci1jb2xsYXBzZTogY29sbGFwc2U7XG4gICAgd2lkdGg6IDEwMCU7XG4gICAgaGVpZ2h0OiAyNTBweDs7XG59XG5cbi5saXN0Qm9keSB7XG4gICAgb3ZlcmZsb3c6IGF1dG87XG4gICAgZGlzcGxheTogYmxvY2s7XG4gICAgaGVpZ2h0OiAxMDAlO1xufVxuXG4ubGlzdEl0ZW0ge1xuICAgIHBhZGRpbmctbGVmdDogM3B4O1xuICAgIGJvcmRlci1zdHlsZTogbm9uZTtcbn1cblxuLnNlbGVjdGVkSXRlbSB7XG4gICAgYmFja2dyb3VuZDogYnJvd247XG4gICAgY29sb3I6IHdoaXRlO1xufVxuXG5cbi5oaWdobGlnaHQge1xuICAgIGJhY2tncm91bmQtY29sb3I6ICMwMEZGMDA7XG59XG5cbi5kcm9wcGFibGUge1xuICAgIGJvcmRlcjogMnB4IGRhc2hlZCBncmF5O1xufVxuXG4uaWNvbiB7XG4gICAgZm9udC1mYW1pbHk6IEZvbnRBd2Vzb21lLCBmb250YXdlc29tZTtcbiAgICBmb250LXNpemU6IDI0O1xuIH1cbiBcbi8qIE1haW4gTmF2aWdhdGlvbiAqL1xuXG4gXG51bCNuYXZpZ2F0aW9uIHtcbiAgICBtYXJnaW46MHB4IGF1dG87XG4gICAgcG9zaXRpb246cmVsYXRpdmU7XG4gICAgZmxvYXQ6bGVmdDtcbn1cbiBcbnVsI25hdmlnYXRpb24gbGkge1xuICAgIGRpc3BsYXk6aW5saW5lO1xuICAgIGZsb2F0OmxlZnQ7XG5cbn1cbiBcbnVsI25hdmlnYXRpb24gbGkgaDUge1xuICAgIHBhZGRpbmc6NXB4IDVweCA1cHggMTVweDtcbiAgICBkaXNwbGF5OmlubGluZS1ibG9jaztcbiAgICBtYXJnaW46IDVweCAwIDAgMDtcbiAgICB3aWR0aDogMTAwJTtcbn1cbiBcbnVsI25hdmlnYXRpb24gbGkgaDU6aG92ZXIge1xuICAgIGJhY2tncm91bmQ6I2Y4ZjhmODtcbiAgICBjb2xvcjojMjgyODI4O1xufVxuIFxuXG4gXG51bCNuYXZpZ2F0aW9uIGxpOmhvdmVyID4gYSB7XG4gICAgYmFja2dyb3VuZDojZmZmO1xufVxuLyogRHJvcC1Eb3duIE5hdmlnYXRpb24gKi9cbnVsI25hdmlnYXRpb24gbGk6aG92ZXIgPiB1bFxue1xuLyp0aGVzZSAyIHN0eWxlcyBhcmUgdmVyeSBpbXBvcnRhbnQsXG5iZWluZyB0aGUgb25lcyB3aGljaCBtYWtlIHRoZSBkcm9wLWRvd24gdG8gYXBwZWFyIG9uIGhvdmVyICovXG4gICAgdmlzaWJpbGl0eTp2aXNpYmxlO1xuICAgIG9wYWNpdHk6MTtcbn1cbiBcbnVsI25hdmlnYXRpb24gdWwsIHVsI25hdmlnYXRpb24gdWwgbGkgdWwge1xuICAgIGxpc3Qtc3R5bGU6IG5vbmU7XG4gICAgbWFyZ2luLWxlZnQ6IDEwcHg7XG4gICAgcGFkZGluZzogMDtcbi8qdGhlIG5leHQgMiBzdHlsZXMgYXJlIHZlcnkgaW1wb3J0YW50LFxuYmVpbmcgdGhlIG9uZXMgd2hpY2ggbWFrZSB0aGUgZHJvcC1kb3duIHRvIHN0YXkgaGlkZGVuICovXG4gICAgdmlzaWJpbGl0eTpoaWRkZW47XG4gICAgb3BhY2l0eTowO1xuICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgICB6LWluZGV4OiA5OTk5OTtcbiAgICB3aWR0aDoxODBweDtcbiAgICBiYWNrZ3JvdW5kOiNkZGQ7XG4gICAgYm94LXNoYWRvdzoxcHggMXB4IDNweCAjY2NjO1xuLyogY3NzMyB0cmFuc2l0aW9ucyBmb3Igc21vb3RoIGhvdmVyIGVmZmVjdCAqL1xuICAgIC13ZWJraXQtdHJhbnNpdGlvbjpvcGFjaXR5IDAuMnMgbGluZWFyLCB2aXNpYmlsaXR5IDAuMnMgbGluZWFyO1xuICAgIC1tb3otdHJhbnNpdGlvbjpvcGFjaXR5IDAuMnMgbGluZWFyLCB2aXNpYmlsaXR5IDAuMnMgbGluZWFyO1xuICAgIC1vLXRyYW5zaXRpb246b3BhY2l0eSAwLjJzIGxpbmVhciwgdmlzaWJpbGl0eSAwLjJzIGxpbmVhcjtcbiAgICB0cmFuc2l0aW9uOm9wYWNpdHkgMC4ycyBsaW5lYXIsIHZpc2liaWxpdHkgMC4ycyBsaW5lYXI7XG59XG4gXG51bCNuYXZpZ2F0aW9uIHVsIHtcbiAgICB0b3A6IDI1cHg7XG4gICAgbGVmdDogMTBweDtcbn1cbiBcbnVsI25hdmlnYXRpb24gdWwgbGkgdWwge1xuICAgIHRvcDogMDtcbiAgICBsZWZ0OiAxODFweDsgLyogc3Ryb25nIHJlbGF0ZWQgdG8gd2lkdGg6MTgwcHg7IGZyb20gYWJvdmUgKi9cbn1cbiBcbnVsI25hdmlnYXRpb24gdWwgbGkge1xuICAgIGNsZWFyOmJvdGg7XG4gICAgd2lkdGg6MTAwJTtcbiAgICBib3JkZXI6MCBub25lO1xuICAgIGJvcmRlci1ib3R0b206MXB4IHNvbGlkICNjOWM5Yzk7XG59XG4iXX0= */"]
    });
    /*@__PURE__*/

    (function () {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](BrowseTableComponent, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"],
        args: [{
          moduleId: module.i,
          selector: 'sd-browse-table',
          templateUrl: 'browseTable.component.html',
          styleUrls: ['browseTable.component.css'],
          providers: [_angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpClient"], js44d__WEBPACK_IMPORTED_MODULE_2__["FourDInterface"], js44d__WEBPACK_IMPORTED_MODULE_2__["Modal"]]
        }]
      }], function () {
        return [{
          type: _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpClient"]
        }, {
          type: js44d__WEBPACK_IMPORTED_MODULE_2__["FourDInterface"]
        }, {
          type: js44d__WEBPACK_IMPORTED_MODULE_2__["Modal"]
        }, {
          type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["ViewContainerRef"]
        }];
      }, {
        numOfTables: [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }],
        listOfTables: [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }],
        currentTable: [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }],
        listedTable: [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }],
        listOfFields: [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }],
        listOfColumns: [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }],
        relatedOneTables: [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }],
        currentField: [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }],
        queryData: [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }],
        hideBrowseConfig: [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }],
        currentGridHeight: [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }],
        recordList: [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["ViewChild"],
          args: [js44d__WEBPACK_IMPORTED_MODULE_2__["RecordList"]]
        }],
        theGrid: [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["ViewChild"],
          args: [js44d__WEBPACK_IMPORTED_MODULE_2__["DataGrid"]]
        }]
      });
    })();
    /***/

  },

  /***/
  "./src/app/browseTable/browseTable.module.ts":
  /*!***************************************************!*\
    !*** ./src/app/browseTable/browseTable.module.ts ***!
    \***************************************************/

  /*! exports provided: BrowseRoutes, BrowseTableModule */

  /***/
  function srcAppBrowseTableBrowseTableModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "BrowseRoutes", function () {
      return BrowseRoutes;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "BrowseTableModule", function () {
      return BrowseTableModule;
    });
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
    /* harmony import */


    var _angular_common_http__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @angular/common/http */
    "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/http.js");
    /* harmony import */


    var _browseTableDialog_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ./browseTableDialog.component */
    "./src/app/browseTable/browseTableDialog.component.ts");
    /* harmony import */


    var _browseTable_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ./browseTable.component */
    "./src/app/browseTable/browseTable.component.ts");
    /* harmony import */


    var _browseQuery_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
    /*! ./browseQuery.component */
    "./src/app/browseTable/browseQuery.component.ts");
    /* harmony import */


    var _browseQueryField_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(
    /*! ./browseQueryField.component */
    "./src/app/browseTable/browseQueryField.component.ts");
    /* harmony import */


    var _browseInputField_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(
    /*! ./browseInputField.component */
    "./src/app/browseTable/browseInputField.component.ts");
    /* harmony import */


    var _browseFormDialog_component__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(
    /*! ./browseFormDialog.component */
    "./src/app/browseTable/browseFormDialog.component.ts");
    /* harmony import */


    var _browseFieldDialog_component__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(
    /*! ./browseFieldDialog.component */
    "./src/app/browseTable/browseFieldDialog.component.ts");
    /* harmony import */


    var js44d__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(
    /*! js44d */
    "./node_modules/js44d/__ivy_ngcc__/fesm2015/js44d.js"); // feature modules


    var BrowseRoutes = [{
      path: '',
      component: _browseTableDialog_component__WEBPACK_IMPORTED_MODULE_5__["BrowseTableDialog"]
    }];

    var BrowseTableModule = function BrowseTableModule() {
      _classCallCheck(this, BrowseTableModule);
    };

    BrowseTableModule.ɵmod = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineNgModule"]({
      type: BrowseTableModule
    });
    BrowseTableModule.ɵinj = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineInjector"]({
      factory: function BrowseTableModule_Factory(t) {
        return new (t || BrowseTableModule)();
      },
      providers: [_angular_common_http__WEBPACK_IMPORTED_MODULE_4__["HttpClient"], js44d__WEBPACK_IMPORTED_MODULE_12__["FourDInterface"]],
      imports: [[_angular_common__WEBPACK_IMPORTED_MODULE_1__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormsModule"], _angular_common_http__WEBPACK_IMPORTED_MODULE_4__["HttpClientModule"], _angular_router__WEBPACK_IMPORTED_MODULE_3__["RouterModule"].forChild(BrowseRoutes), js44d__WEBPACK_IMPORTED_MODULE_12__["FourDModule"], js44d__WEBPACK_IMPORTED_MODULE_12__["JS44DModule"], js44d__WEBPACK_IMPORTED_MODULE_12__["ModalModule"]]]
    });

    (function () {
      (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵsetNgModuleScope"](BrowseTableModule, {
        declarations: [_browseTableDialog_component__WEBPACK_IMPORTED_MODULE_5__["BrowseTableDialog"], _browseTable_component__WEBPACK_IMPORTED_MODULE_6__["BrowseTableComponent"], _browseQuery_component__WEBPACK_IMPORTED_MODULE_7__["BrowseQueryBand"], _browseQueryField_component__WEBPACK_IMPORTED_MODULE_8__["BrowseQueryField"], _browseFormDialog_component__WEBPACK_IMPORTED_MODULE_10__["BrowseFormDialog"], _browseInputField_component__WEBPACK_IMPORTED_MODULE_9__["BrowseInputField"], _browseFieldDialog_component__WEBPACK_IMPORTED_MODULE_11__["BrowseFieldDialog"]],
        imports: [_angular_common__WEBPACK_IMPORTED_MODULE_1__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormsModule"], _angular_common_http__WEBPACK_IMPORTED_MODULE_4__["HttpClientModule"], _angular_router__WEBPACK_IMPORTED_MODULE_3__["RouterModule"], js44d__WEBPACK_IMPORTED_MODULE_12__["FourDModule"], js44d__WEBPACK_IMPORTED_MODULE_12__["JS44DModule"], js44d__WEBPACK_IMPORTED_MODULE_12__["ModalModule"]]
      });
    })();
    /*@__PURE__*/


    (function () {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](BrowseTableModule, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["NgModule"],
        args: [{
          imports: [_angular_common__WEBPACK_IMPORTED_MODULE_1__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormsModule"], _angular_common_http__WEBPACK_IMPORTED_MODULE_4__["HttpClientModule"], _angular_router__WEBPACK_IMPORTED_MODULE_3__["RouterModule"].forChild(BrowseRoutes), js44d__WEBPACK_IMPORTED_MODULE_12__["FourDModule"], js44d__WEBPACK_IMPORTED_MODULE_12__["JS44DModule"], js44d__WEBPACK_IMPORTED_MODULE_12__["ModalModule"]],
          providers: [_angular_common_http__WEBPACK_IMPORTED_MODULE_4__["HttpClient"], js44d__WEBPACK_IMPORTED_MODULE_12__["FourDInterface"]],
          declarations: [_browseTableDialog_component__WEBPACK_IMPORTED_MODULE_5__["BrowseTableDialog"], _browseTable_component__WEBPACK_IMPORTED_MODULE_6__["BrowseTableComponent"], _browseQuery_component__WEBPACK_IMPORTED_MODULE_7__["BrowseQueryBand"], _browseQueryField_component__WEBPACK_IMPORTED_MODULE_8__["BrowseQueryField"], _browseFormDialog_component__WEBPACK_IMPORTED_MODULE_10__["BrowseFormDialog"], _browseInputField_component__WEBPACK_IMPORTED_MODULE_9__["BrowseInputField"], _browseFieldDialog_component__WEBPACK_IMPORTED_MODULE_11__["BrowseFieldDialog"]],
          entryComponents: [_browseFormDialog_component__WEBPACK_IMPORTED_MODULE_10__["BrowseFormDialog"], _browseTable_component__WEBPACK_IMPORTED_MODULE_6__["BrowseTableComponent"], _browseFieldDialog_component__WEBPACK_IMPORTED_MODULE_11__["BrowseFieldDialog"]]
        }]
      }], null, null);
    })();

    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵsetComponentScope"](_browseTable_component__WEBPACK_IMPORTED_MODULE_6__["BrowseTableComponent"], [_angular_common__WEBPACK_IMPORTED_MODULE_1__["NgClass"], _angular_common__WEBPACK_IMPORTED_MODULE_1__["NgComponentOutlet"], _angular_common__WEBPACK_IMPORTED_MODULE_1__["NgForOf"], _angular_common__WEBPACK_IMPORTED_MODULE_1__["NgIf"], _angular_common__WEBPACK_IMPORTED_MODULE_1__["NgTemplateOutlet"], _angular_common__WEBPACK_IMPORTED_MODULE_1__["NgStyle"], _angular_common__WEBPACK_IMPORTED_MODULE_1__["NgSwitch"], _angular_common__WEBPACK_IMPORTED_MODULE_1__["NgSwitchCase"], _angular_common__WEBPACK_IMPORTED_MODULE_1__["NgSwitchDefault"], _angular_common__WEBPACK_IMPORTED_MODULE_1__["NgPlural"], _angular_common__WEBPACK_IMPORTED_MODULE_1__["NgPluralCase"], _angular_forms__WEBPACK_IMPORTED_MODULE_2__["ɵangular_packages_forms_forms_y"], _angular_forms__WEBPACK_IMPORTED_MODULE_2__["NgSelectOption"], _angular_forms__WEBPACK_IMPORTED_MODULE_2__["ɵangular_packages_forms_forms_x"], _angular_forms__WEBPACK_IMPORTED_MODULE_2__["DefaultValueAccessor"], _angular_forms__WEBPACK_IMPORTED_MODULE_2__["NumberValueAccessor"], _angular_forms__WEBPACK_IMPORTED_MODULE_2__["RangeValueAccessor"], _angular_forms__WEBPACK_IMPORTED_MODULE_2__["CheckboxControlValueAccessor"], _angular_forms__WEBPACK_IMPORTED_MODULE_2__["SelectControlValueAccessor"], _angular_forms__WEBPACK_IMPORTED_MODULE_2__["SelectMultipleControlValueAccessor"], _angular_forms__WEBPACK_IMPORTED_MODULE_2__["RadioControlValueAccessor"], _angular_forms__WEBPACK_IMPORTED_MODULE_2__["NgControlStatus"], _angular_forms__WEBPACK_IMPORTED_MODULE_2__["NgControlStatusGroup"], _angular_forms__WEBPACK_IMPORTED_MODULE_2__["RequiredValidator"], _angular_forms__WEBPACK_IMPORTED_MODULE_2__["MinLengthValidator"], _angular_forms__WEBPACK_IMPORTED_MODULE_2__["MaxLengthValidator"], _angular_forms__WEBPACK_IMPORTED_MODULE_2__["PatternValidator"], _angular_forms__WEBPACK_IMPORTED_MODULE_2__["CheckboxRequiredValidator"], _angular_forms__WEBPACK_IMPORTED_MODULE_2__["EmailValidator"], _angular_forms__WEBPACK_IMPORTED_MODULE_2__["NgModel"], _angular_forms__WEBPACK_IMPORTED_MODULE_2__["NgModelGroup"], _angular_forms__WEBPACK_IMPORTED_MODULE_2__["NgForm"], _angular_router__WEBPACK_IMPORTED_MODULE_3__["RouterOutlet"], _angular_router__WEBPACK_IMPORTED_MODULE_3__["RouterLink"], _angular_router__WEBPACK_IMPORTED_MODULE_3__["RouterLinkWithHref"], _angular_router__WEBPACK_IMPORTED_MODULE_3__["RouterLinkActive"], _angular_router__WEBPACK_IMPORTED_MODULE_3__["ɵangular_packages_router_router_l"], js44d__WEBPACK_IMPORTED_MODULE_12__["QueryBand"], js44d__WEBPACK_IMPORTED_MODULE_12__["CustomButtonBarDirective"], js44d__WEBPACK_IMPORTED_MODULE_12__["QueryBandDirective"], js44d__WEBPACK_IMPORTED_MODULE_12__["AdvancedQueryComponent"], js44d__WEBPACK_IMPORTED_MODULE_12__["RecordEditWindow"], js44d__WEBPACK_IMPORTED_MODULE_12__["RecordList"], js44d__WEBPACK_IMPORTED_MODULE_12__["Tabs"], js44d__WEBPACK_IMPORTED_MODULE_12__["Tab"], js44d__WEBPACK_IMPORTED_MODULE_12__["WebAppContainer"], js44d__WEBPACK_IMPORTED_MODULE_12__["FourDDropDown"], js44d__WEBPACK_IMPORTED_MODULE_12__["QuickFindInput"], js44d__WEBPACK_IMPORTED_MODULE_12__["FourDRegistryInput"], js44d__WEBPACK_IMPORTED_MODULE_12__["DataGrid"], js44d__WEBPACK_IMPORTED_MODULE_12__["ListSelectorDialog"], js44d__WEBPACK_IMPORTED_MODULE_12__["LoginCmp"], js44d__WEBPACK_IMPORTED_MODULE_12__["OKOnlyModal"], js44d__WEBPACK_IMPORTED_MODULE_12__["YesNoModal"], _browseTableDialog_component__WEBPACK_IMPORTED_MODULE_5__["BrowseTableDialog"], _browseTable_component__WEBPACK_IMPORTED_MODULE_6__["BrowseTableComponent"], _browseQuery_component__WEBPACK_IMPORTED_MODULE_7__["BrowseQueryBand"], _browseQueryField_component__WEBPACK_IMPORTED_MODULE_8__["BrowseQueryField"], _browseFormDialog_component__WEBPACK_IMPORTED_MODULE_10__["BrowseFormDialog"], _browseInputField_component__WEBPACK_IMPORTED_MODULE_9__["BrowseInputField"], _browseFieldDialog_component__WEBPACK_IMPORTED_MODULE_11__["BrowseFieldDialog"]], [_angular_common__WEBPACK_IMPORTED_MODULE_1__["AsyncPipe"], _angular_common__WEBPACK_IMPORTED_MODULE_1__["UpperCasePipe"], _angular_common__WEBPACK_IMPORTED_MODULE_1__["LowerCasePipe"], _angular_common__WEBPACK_IMPORTED_MODULE_1__["JsonPipe"], _angular_common__WEBPACK_IMPORTED_MODULE_1__["SlicePipe"], _angular_common__WEBPACK_IMPORTED_MODULE_1__["DecimalPipe"], _angular_common__WEBPACK_IMPORTED_MODULE_1__["PercentPipe"], _angular_common__WEBPACK_IMPORTED_MODULE_1__["TitleCasePipe"], _angular_common__WEBPACK_IMPORTED_MODULE_1__["CurrencyPipe"], _angular_common__WEBPACK_IMPORTED_MODULE_1__["DatePipe"], _angular_common__WEBPACK_IMPORTED_MODULE_1__["I18nPluralPipe"], _angular_common__WEBPACK_IMPORTED_MODULE_1__["I18nSelectPipe"], _angular_common__WEBPACK_IMPORTED_MODULE_1__["KeyValuePipe"], js44d__WEBPACK_IMPORTED_MODULE_12__["Base64ImageRef"], js44d__WEBPACK_IMPORTED_MODULE_12__["FourDDateToString"]]);

    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵsetComponentScope"](_browseFormDialog_component__WEBPACK_IMPORTED_MODULE_10__["BrowseFormDialog"], [_angular_common__WEBPACK_IMPORTED_MODULE_1__["NgClass"], _angular_common__WEBPACK_IMPORTED_MODULE_1__["NgComponentOutlet"], _angular_common__WEBPACK_IMPORTED_MODULE_1__["NgForOf"], _angular_common__WEBPACK_IMPORTED_MODULE_1__["NgIf"], _angular_common__WEBPACK_IMPORTED_MODULE_1__["NgTemplateOutlet"], _angular_common__WEBPACK_IMPORTED_MODULE_1__["NgStyle"], _angular_common__WEBPACK_IMPORTED_MODULE_1__["NgSwitch"], _angular_common__WEBPACK_IMPORTED_MODULE_1__["NgSwitchCase"], _angular_common__WEBPACK_IMPORTED_MODULE_1__["NgSwitchDefault"], _angular_common__WEBPACK_IMPORTED_MODULE_1__["NgPlural"], _angular_common__WEBPACK_IMPORTED_MODULE_1__["NgPluralCase"], _angular_forms__WEBPACK_IMPORTED_MODULE_2__["ɵangular_packages_forms_forms_y"], _angular_forms__WEBPACK_IMPORTED_MODULE_2__["NgSelectOption"], _angular_forms__WEBPACK_IMPORTED_MODULE_2__["ɵangular_packages_forms_forms_x"], _angular_forms__WEBPACK_IMPORTED_MODULE_2__["DefaultValueAccessor"], _angular_forms__WEBPACK_IMPORTED_MODULE_2__["NumberValueAccessor"], _angular_forms__WEBPACK_IMPORTED_MODULE_2__["RangeValueAccessor"], _angular_forms__WEBPACK_IMPORTED_MODULE_2__["CheckboxControlValueAccessor"], _angular_forms__WEBPACK_IMPORTED_MODULE_2__["SelectControlValueAccessor"], _angular_forms__WEBPACK_IMPORTED_MODULE_2__["SelectMultipleControlValueAccessor"], _angular_forms__WEBPACK_IMPORTED_MODULE_2__["RadioControlValueAccessor"], _angular_forms__WEBPACK_IMPORTED_MODULE_2__["NgControlStatus"], _angular_forms__WEBPACK_IMPORTED_MODULE_2__["NgControlStatusGroup"], _angular_forms__WEBPACK_IMPORTED_MODULE_2__["RequiredValidator"], _angular_forms__WEBPACK_IMPORTED_MODULE_2__["MinLengthValidator"], _angular_forms__WEBPACK_IMPORTED_MODULE_2__["MaxLengthValidator"], _angular_forms__WEBPACK_IMPORTED_MODULE_2__["PatternValidator"], _angular_forms__WEBPACK_IMPORTED_MODULE_2__["CheckboxRequiredValidator"], _angular_forms__WEBPACK_IMPORTED_MODULE_2__["EmailValidator"], _angular_forms__WEBPACK_IMPORTED_MODULE_2__["NgModel"], _angular_forms__WEBPACK_IMPORTED_MODULE_2__["NgModelGroup"], _angular_forms__WEBPACK_IMPORTED_MODULE_2__["NgForm"], _angular_router__WEBPACK_IMPORTED_MODULE_3__["RouterOutlet"], _angular_router__WEBPACK_IMPORTED_MODULE_3__["RouterLink"], _angular_router__WEBPACK_IMPORTED_MODULE_3__["RouterLinkWithHref"], _angular_router__WEBPACK_IMPORTED_MODULE_3__["RouterLinkActive"], _angular_router__WEBPACK_IMPORTED_MODULE_3__["ɵangular_packages_router_router_l"], js44d__WEBPACK_IMPORTED_MODULE_12__["QueryBand"], js44d__WEBPACK_IMPORTED_MODULE_12__["CustomButtonBarDirective"], js44d__WEBPACK_IMPORTED_MODULE_12__["QueryBandDirective"], js44d__WEBPACK_IMPORTED_MODULE_12__["AdvancedQueryComponent"], js44d__WEBPACK_IMPORTED_MODULE_12__["RecordEditWindow"], js44d__WEBPACK_IMPORTED_MODULE_12__["RecordList"], js44d__WEBPACK_IMPORTED_MODULE_12__["Tabs"], js44d__WEBPACK_IMPORTED_MODULE_12__["Tab"], js44d__WEBPACK_IMPORTED_MODULE_12__["WebAppContainer"], js44d__WEBPACK_IMPORTED_MODULE_12__["FourDDropDown"], js44d__WEBPACK_IMPORTED_MODULE_12__["QuickFindInput"], js44d__WEBPACK_IMPORTED_MODULE_12__["FourDRegistryInput"], js44d__WEBPACK_IMPORTED_MODULE_12__["DataGrid"], js44d__WEBPACK_IMPORTED_MODULE_12__["ListSelectorDialog"], js44d__WEBPACK_IMPORTED_MODULE_12__["LoginCmp"], js44d__WEBPACK_IMPORTED_MODULE_12__["OKOnlyModal"], js44d__WEBPACK_IMPORTED_MODULE_12__["YesNoModal"], _browseTableDialog_component__WEBPACK_IMPORTED_MODULE_5__["BrowseTableDialog"], _browseTable_component__WEBPACK_IMPORTED_MODULE_6__["BrowseTableComponent"], _browseQuery_component__WEBPACK_IMPORTED_MODULE_7__["BrowseQueryBand"], _browseQueryField_component__WEBPACK_IMPORTED_MODULE_8__["BrowseQueryField"], _browseFormDialog_component__WEBPACK_IMPORTED_MODULE_10__["BrowseFormDialog"], _browseInputField_component__WEBPACK_IMPORTED_MODULE_9__["BrowseInputField"], _browseFieldDialog_component__WEBPACK_IMPORTED_MODULE_11__["BrowseFieldDialog"]], [_angular_common__WEBPACK_IMPORTED_MODULE_1__["AsyncPipe"], _angular_common__WEBPACK_IMPORTED_MODULE_1__["UpperCasePipe"], _angular_common__WEBPACK_IMPORTED_MODULE_1__["LowerCasePipe"], _angular_common__WEBPACK_IMPORTED_MODULE_1__["JsonPipe"], _angular_common__WEBPACK_IMPORTED_MODULE_1__["SlicePipe"], _angular_common__WEBPACK_IMPORTED_MODULE_1__["DecimalPipe"], _angular_common__WEBPACK_IMPORTED_MODULE_1__["PercentPipe"], _angular_common__WEBPACK_IMPORTED_MODULE_1__["TitleCasePipe"], _angular_common__WEBPACK_IMPORTED_MODULE_1__["CurrencyPipe"], _angular_common__WEBPACK_IMPORTED_MODULE_1__["DatePipe"], _angular_common__WEBPACK_IMPORTED_MODULE_1__["I18nPluralPipe"], _angular_common__WEBPACK_IMPORTED_MODULE_1__["I18nSelectPipe"], _angular_common__WEBPACK_IMPORTED_MODULE_1__["KeyValuePipe"], js44d__WEBPACK_IMPORTED_MODULE_12__["Base64ImageRef"], js44d__WEBPACK_IMPORTED_MODULE_12__["FourDDateToString"]]);
    /***/

  },

  /***/
  "./src/app/browseTable/browseTableDialog.component.ts":
  /*!************************************************************!*\
    !*** ./src/app/browseTable/browseTableDialog.component.ts ***!
    \************************************************************/

  /*! exports provided: BrowseTableDialog */

  /***/
  function srcAppBrowseTableBrowseTableDialogComponentTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "BrowseTableDialog", function () {
      return BrowseTableDialog;
    });
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
    /* harmony import */


    var js44d__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! js44d */
    "./node_modules/js44d/__ivy_ngcc__/fesm2015/js44d.js");
    /* harmony import */


    var _browseTable_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./browseTable.component */
    "./src/app/browseTable/browseTable.component.ts");

    var BrowseTableDialog = /*#__PURE__*/function () {
      function BrowseTableDialog(modal, router, elementRef, viewRef) {
        _classCallCheck(this, BrowseTableDialog);

        this.modal = modal;
        this.router = router;
        this.elementRef = elementRef;
        this.viewRef = viewRef;
      }
      /**
       * AFter our view gets initialized, subscribe to various events on the Query band and the Grid
       */


      _createClass(BrowseTableDialog, [{
        key: "ngAfterContentInit",
        value: function ngAfterContentInit() {
          this.router.navigate(['/blank'], {
            skipLocationChange: true
          });
          this.modal.openDialog(_browseTable_component__WEBPACK_IMPORTED_MODULE_3__["BrowseTableComponent"], {});
        }
      }]);

      return BrowseTableDialog;
    }();

    BrowseTableDialog.ɵfac = function BrowseTableDialog_Factory(t) {
      return new (t || BrowseTableDialog)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](js44d__WEBPACK_IMPORTED_MODULE_2__["Modal"]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_1__["Router"]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_0__["ElementRef"]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_0__["ViewContainerRef"]));
    };

    BrowseTableDialog.ɵcmp = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({
      type: BrowseTableDialog,
      selectors: [["browse-table-dialog"]],
      features: [_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵProvidersFeature"]([js44d__WEBPACK_IMPORTED_MODULE_2__["Modal"]])],
      decls: 1,
      vars: 0,
      template: function BrowseTableDialog_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](0, "div");
        }
      },
      encapsulation: 2
    });
    /*@__PURE__*/

    (function () {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](BrowseTableDialog, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"],
        args: [{
          selector: 'browse-table-dialog',
          template: '<div></div>',
          providers: [js44d__WEBPACK_IMPORTED_MODULE_2__["Modal"]]
        }]
      }], function () {
        return [{
          type: js44d__WEBPACK_IMPORTED_MODULE_2__["Modal"]
        }, {
          type: _angular_router__WEBPACK_IMPORTED_MODULE_1__["Router"]
        }, {
          type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["ElementRef"]
        }, {
          type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["ViewContainerRef"]
        }];
      }, null);
    })();
    /***/

  }
}]);
//# sourceMappingURL=app-browseTable-browseTable-module-es5.js.map