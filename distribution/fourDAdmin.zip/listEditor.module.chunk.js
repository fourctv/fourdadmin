webpackJsonp(["listEditor.module"],{

/***/ "../../../../../src/app/listEditor/listEditor.component.css":
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__("../../../../css-loader/lib/css-base.js")(false);
// imports


// module
exports.push([module.i, ".listTable {\n    border: 1px solid black;\n    border-collapse: collapse;\n    width: 100%;\n    height: 250px;;\n}\n\n.listBody {\n    overflow: auto;\n    display: block;\n    height: 100%;\n}\n\n.listItem {\n    padding-left: 3px;\n    border-style: none;\n}\n\n.selectedItem {\n    background: brown;\n    color: white;\n}\n\n.droppable {\n    border: 2px dashed gray;\n}\n\n/* Main Navigation */\n\n \nul#navigation {\n    margin:0px auto;\n    position:relative;\n    float:left;\n}\n \nul#navigation li {\n    display:inline;\n    float:left;\n\n}\n \nul#navigation li h5 {\n    padding:5px 5px 5px 15px;\n    display:inline-block;\n    margin: 5px 0 0 0;\n    width: 100%;\n}\n \nul#navigation li h5:hover {\n    background:#f8f8f8;\n    color:#282828;\n}\n \n\n \nul#navigation li:hover > a {\n    background:#fff;\n}\n/* Drop-Down Navigation */\nul#navigation li:hover > ul\n{\n/*these 2 styles are very important,\nbeing the ones which make the drop-down to appear on hover */\n    visibility:visible;\n    opacity:1;\n}\n \nul#navigation ul, ul#navigation ul li ul {\n    list-style: none;\n    margin-left: 10px;\n    padding: 0;\n/*the next 2 styles are very important,\nbeing the ones which make the drop-down to stay hidden */\n    visibility:hidden;\n    opacity:0;\n    position: absolute;\n    z-index: 99999;\n    width:180px;\n    background:#ddd;\n    box-shadow:1px 1px 3px #ccc;\n/* css3 transitions for smooth hover effect */\n    transition:opacity 0.2s linear, visibility 0.2s linear;\n}\n \nul#navigation ul {\n    top: 25px;\n    left: 10px;\n}\n \nul#navigation ul li ul {\n    top: 0;\n    left: 181px; /* strong related to width:180px; from above */\n}\n \nul#navigation ul li {\n    clear:both;\n    width:100%;\n    border:0 none;\n    border-bottom:1px solid #c9c9c9;\n}\n", ""]);

// exports


/*** EXPORTS FROM exports-loader ***/
module.exports = module.exports.toString();

/***/ }),

/***/ "../../../../../src/app/listEditor/listEditor.component.html":
/***/ (function(module, exports) {

module.exports = "<web-application>\n    <h2 style=\"padding-left: 10px;\">List Editor</h2>\n\n    <div class=\"container-fluid\" style=\"margin-left:10px; height: calc(100% - 65px)\">\n        <div class=\"row\" >\n            <div class=\"col-sm-2\" style=\"border-style: solid; border-width: thin; padding-bottom: 4px;\">\n                <h4>Select List</h4>\n                <table  class=\"listTable\" style=\"height: 350px;\">\n                    <tbody class=\"listBody\">\n                        <tr *ngFor='let list of listNames' (click)=\"selectList($event,list)\">\n                            <td class=\"listItem\">{{list}}</td>\n                        </tr>\n                    </tbody>\n                </table>\n            </div>\n            <div class=\"col-sm-3\" style=\"border-style: solid; border-width: thin; padding-bottom: 4px;\">\n                <h4>{{selectedListName}} items</h4>\n                <table class=\"listTable\" style=\"height: 350px;\">\n                    <tbody class=\"listBody\" (dragenter)=\"allowDrop($event)\" (dragover)=\"allowDrop($event)\" (dragend)=\"disableDrop($event)\" (dragleave)=\"disableDrop($event)\" (drop)=\"handleDrop($event)\">\n                        <tr *ngFor='let item of listItems' (click)=\"selectItem($event,item)\" draggable=\"true\" (drop)=\"handleDrop($event)\" (dragstart)=\"startDrag($event,'column')\" (dragleave)=\"disableDrop($event)\">\n                            <td class=\"listItem\">{{item}}</td>\n                        </tr>\n                    </tbody>\n                </table>\n            </div>\n\n            <div class=\"col-sm-5\" style=\"border-style: solid; border-width: thin; padding-bottom: 4px;\" [hidden]=\"!selectedList\">\n                <h4>List Item Info</h4>\n                <form  class=\"form-horizontal listTable\" style=\"height: 348px;\">\n                    <div class=\"form-group\" style=\"padding-top: 10px;\">\n                        <label for=\"field\" class=\"control-label col-sm-2\">List Item Value:</label>\n                        <div class=\"col-sm-6\">\n                            <input name=\"listitem\" type=\"text\" class=\"form-control\" [(ngModel)]=\"selectedItemValue\">\n                        </div>\n                    </div>\n \n                     <div class=\"form-group\"> \n                        <div class=\"col-sm-offset-2 col-sm-10\">\n                            <button class=\"regularButton\" style=\"width: 70px;padding-right: 5px;\" (click)=\"addItem()\" [disabled]=\"selectedItemValue === ''\">Add</button>\n                            <button class=\"regularButton\" style=\"width: 70px;padding-right: 5px;\" (click)=\"changeItem()\" [disabled]=\"!selectedItem\">Change</button>\n                            <button class=\"regularButton\" style=\"width: 70px;padding-right: 5px;\" (click)=\"deleteItem()\" [disabled]=\"!selectedItem\">Delete</button>\n                        </div>\n                    </div>\n                 </form>\n            </div>\n\n        </div>        \n\n    </div>\n</web-application>\n"

/***/ }),

/***/ "../../../../../src/app/listEditor/listEditor.component.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return ListEditorComponent; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("../../../core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_js44d__ = __webpack_require__("../../../../js44d/js44d.es5.js");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};


var ListEditorComponent = /** @class */ (function () {
    function ListEditorComponent(fourD /*, private logger: LogService*/) {
        this.fourD = fourD; /*, private logger: LogService*/
        this.listCount = 0;
        this.listNames = [];
        this.selectedListName = '';
        this.listItems = [];
        this.selectedItemIndex = -1;
        this.selectedItemValue = '';
    }
    ListEditorComponent.prototype.ngAfterContentInit = function () {
        var _this = this;
        this.fourD.call4DRESTMethod('REST_GetListOf4DLists', {})
            .subscribe(function (resultJSON) {
            _this.listCount = resultJSON.listCount;
            _this.listNames = resultJSON.listNames;
        });
    };
    ListEditorComponent.prototype.selectList = function (event, list) {
        var _this = this;
        if (this.selectedList) {
            this.selectedList.classList.remove('selectedItem');
        }
        if (this.selectedItem) {
            this.selectedItem.classList.remove('selectedItem');
            this.selectedItemValue = '';
            this.selectedItemIndex = -1;
        }
        this.selectedList = event.target;
        this.selectedListName = list;
        this.fourD.get4DList(this.selectedListName)
            .then(function (values) {
            _this.selectedList.classList.add('selectedItem');
            _this.listItems = values;
            _this.selectedItem = null;
            _this.selectedItemIndex = -1;
        });
    };
    ListEditorComponent.prototype.selectItem = function (event, item) {
        if (this.selectedItem) {
            this.selectedItem.classList.remove('selectedItem');
        }
        this.selectedItemValue = item;
        this.selectedItemIndex = event.currentTarget.rowIndex;
        this.selectedItem = event.target;
        this.selectedItem.classList.add('selectedItem');
    };
    ListEditorComponent.prototype.addItem = function () {
        if (this.selectedItemValue !== '') {
            this.listItems.push(this.selectedItemValue);
            this.update4DList();
        }
    };
    ListEditorComponent.prototype.changeItem = function () {
        if (this.selectedItemIndex >= 0) {
            this.listItems[this.selectedItemIndex] = this.selectedItemValue;
            this.update4DList();
        }
    };
    ListEditorComponent.prototype.deleteItem = function () {
        if (this.selectedItemIndex >= 0) {
            this.listItems.splice(this.selectedItemIndex, 1);
            this.update4DList();
        }
    };
    ListEditorComponent.prototype.update4DList = function () {
        this.fourD.update4DList(this.selectedListName, this.listItems);
    };
    ListEditorComponent.prototype.startDrag = function (event, type) {
        event.effectAllowed = 'copy';
        event.dataTransfer.setData('row', event.currentTarget.rowIndex);
    };
    ListEditorComponent.prototype.allowDrop = function (event) {
        if (event.preventDefault) {
            event.preventDefault();
        } // Necessary. Allows us to drop.
        if (event.stopPropagation) {
            event.stopPropagation();
        }
        if (event.type === 'dragenter') {
            event.target.classList.add('droppable');
            event.dataTransfer.dropEffect = 'copy'; // See the section on the DataTransfer object.
        }
        return false;
    };
    ListEditorComponent.prototype.disableDrop = function (event) {
        if (event.stopPropagation) {
            event.stopPropagation();
        }
        event.target.classList.remove('droppable');
    };
    ListEditorComponent.prototype.handleDrop = function (event) {
        if (event.stopPropagation) {
            event.stopPropagation();
        }
        this.disableDrop(event);
        var row = event.dataTransfer.getData('row');
        var moveToIndex = event.currentTarget.rowIndex;
        var item = this.listItems.splice(row, 1);
        if (row < moveToIndex) {
            // moving up...
            this.listItems.splice(event.currentTarget.rowIndex - 1, 0, item[0]);
        }
        else {
            // moving down
            this.listItems.splice(event.currentTarget.rowIndex, 0, item[0]);
        }
        this.update4DList();
    };
    ListEditorComponent.dialogConfig = {
        actions: ['Maximize', 'Minimize', 'Close'], position: { top: 100, left: 150 }, selfCentered: true,
        title: '4D List Editor',
        isResizable: true,
        width: 1100, height: 510
    };
    ListEditorComponent = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["n" /* Component */])({
            moduleId: module.i,
            selector: 'list-editor',
            template: __webpack_require__("../../../../../src/app/listEditor/listEditor.component.html"),
            styles: [__webpack_require__("../../../../../src/app/listEditor/listEditor.component.css")]
        }),
        __metadata("design:paramtypes", [__WEBPACK_IMPORTED_MODULE_1_js44d__["b" /* FourDInterface */] /*, private logger: LogService*/])
    ], ListEditorComponent);
    return ListEditorComponent;
}());



/***/ }),

/***/ "../../../../../src/app/listEditor/listEditor.module.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ListEditorRoutes", function() { return ListEditorRoutes; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ListEditorModule", function() { return ListEditorModule; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("../../../core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__angular_common__ = __webpack_require__("../../../common/esm5/common.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__angular_forms__ = __webpack_require__("../../../forms/esm5/forms.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__angular_router__ = __webpack_require__("../../../router/esm5/router.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__listEditorDialog_component__ = __webpack_require__("../../../../../src/app/listEditor/listEditorDialog.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__listEditor_component__ = __webpack_require__("../../../../../src/app/listEditor/listEditor.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6_js44d__ = __webpack_require__("../../../../js44d/js44d.es5.js");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};






// feature modules



var ListEditorRoutes = [
    {
        path: '',
        component: __WEBPACK_IMPORTED_MODULE_4__listEditorDialog_component__["a" /* ListEditorDialog */]
    }
];
var ListEditorModule = /** @class */ (function () {
    function ListEditorModule() {
    }
    ListEditorModule = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["J" /* NgModule */])({
            imports: [
                __WEBPACK_IMPORTED_MODULE_1__angular_common__["b" /* CommonModule */],
                __WEBPACK_IMPORTED_MODULE_2__angular_forms__["b" /* FormsModule */],
                __WEBPACK_IMPORTED_MODULE_3__angular_router__["b" /* RouterModule */].forChild(ListEditorRoutes),
                __WEBPACK_IMPORTED_MODULE_6_js44d__["d" /* FourDModule */], __WEBPACK_IMPORTED_MODULE_6_js44d__["e" /* JS44DModule */], __WEBPACK_IMPORTED_MODULE_6_js44d__["i" /* ModalModule */]
            ],
            declarations: [__WEBPACK_IMPORTED_MODULE_4__listEditorDialog_component__["a" /* ListEditorDialog */], __WEBPACK_IMPORTED_MODULE_5__listEditor_component__["a" /* ListEditorComponent */]],
            entryComponents: [__WEBPACK_IMPORTED_MODULE_5__listEditor_component__["a" /* ListEditorComponent */]],
        })
    ], ListEditorModule);
    return ListEditorModule;
}());



/***/ }),

/***/ "../../../../../src/app/listEditor/listEditorDialog.component.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return ListEditorDialog; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("../../../core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__angular_router__ = __webpack_require__("../../../router/esm5/router.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_js44d__ = __webpack_require__("../../../../js44d/js44d.es5.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__listEditor_component__ = __webpack_require__("../../../../../src/app/listEditor/listEditor.component.ts");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};




var ListEditorDialog = /** @class */ (function () {
    function ListEditorDialog(modal, router, elementRef, viewRef) {
        this.modal = modal;
        this.router = router;
        this.elementRef = elementRef;
        this.viewRef = viewRef;
    }
    /**
     * AFter our view gets initialized, subscribe to various events on the Query band and the Grid
     */
    ListEditorDialog.prototype.ngAfterContentInit = function () {
        this.router.navigate(['/blank'], { skipLocationChange: true });
        this.modal.openDialog(__WEBPACK_IMPORTED_MODULE_3__listEditor_component__["a" /* ListEditorComponent */], {}); // open edit dialog
    };
    ListEditorDialog = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["n" /* Component */])({
            selector: 'browse-table-dialog',
            template: '<div></div>',
            providers: [__WEBPACK_IMPORTED_MODULE_2_js44d__["g" /* Modal */]]
        }),
        __metadata("design:paramtypes", [__WEBPACK_IMPORTED_MODULE_2_js44d__["g" /* Modal */], __WEBPACK_IMPORTED_MODULE_1__angular_router__["a" /* Router */], __WEBPACK_IMPORTED_MODULE_0__angular_core__["u" /* ElementRef */], __WEBPACK_IMPORTED_MODULE_0__angular_core__["_12" /* ViewContainerRef */]])
    ], ListEditorDialog);
    return ListEditorDialog;
}());



/***/ })

});
//# sourceMappingURL=listEditor.module.chunk.js.map