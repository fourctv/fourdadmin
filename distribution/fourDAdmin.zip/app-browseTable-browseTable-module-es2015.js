(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["app-browseTable-browseTable-module"],{

/***/ "./node_modules/raw-loader/index.js!./src/app/browseTable/browseTable.component.html":
/*!**********************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/browseTable/browseTable.component.html ***!
  \**********************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<web-application>\n    <h2 style=\"text-align: center\">Browse Table</h2>\n    <div style=\"display: inline-flex; width:100%;z-index:5; position:absolute; top:25px;padding-left:10px;\">\n        <span title=\"collapse browse config\"><h6 style=\"background:#eaeef1;border-style: solid; border-width: 1px; border-radius: 5px;\" (click)=\"hideConfig()\" [hidden]=\"hideBrowseConfig\">&#8648;&#8648;&#8648;</h6></span>\n        <span title=\"expand browse config\"><h6 style=\"background:#eaeef1;border-style: solid; border-width: 1px; border-radius: 5px;\" (click)=\"showConfig()\" [hidden]=\"!hideBrowseConfig\">&#8650;&#8650;&#8650;</h6></span>\n    </div>\n    <div class=\"container-fluid\" style=\"margin-left:10px; height: calc(100% - 65px); width: calc(100% - 40px)\">\n        <div class=\"row\" [hidden]=\"hideBrowseConfig\">\n            <div class=\"col-sm-2 block\">\n                <h4>Select Table</h4>\n                <table  class=\"listTable\">\n                    <tbody class=\"listBody\">\n                        <tr *ngFor='let table of listOfTables' (click)=\"selectTable($event)\">\n                            <td class=\"listItem\">{{table}}</td>\n                        </tr>\n                    </tbody>\n                </table>\n            </div>\n            <div class=\"col-sm-2 block\">\n                <nav id=\"nav\">\n                    <ul id=\"navigation\">\n                        <li style=\"margin-left: -40px;\"><h4>{{listedTable}}&nbsp;<span *ngIf=\"listedTable.length > 0\">&raquo;</span></h4>\n                            <ul>\n                                <li *ngFor='let relatedTable of relatedOneTables' (click)=\"showRelatedTable($event)\"><h5>{{relatedTable}}</h5></li>\n                            </ul>\n                        </li>\n                    </ul>\n                </nav>\n                <table class=\"listTable\">\n                    <tbody class=\"listBody\">\n                        <tr *ngFor='let field of listOfFields' draggable=\"true\" style=\"cursor: move;\" (dragstart)=\"startDrag($event,'field')\">\n                            <td class=\"listItem\">{{field.name}}</td>\n                        </tr>\n                    </tbody>\n                </table>\n            </div>\n            <div class=\"col-sm-2 block\">\n                <h4>Columns</h4>\n                <table class=\"listTable\" style=\"height: 210px;\">\n                    <tbody class=\"listBody\" (dragenter)=\"allowDrop($event)\" (dragover)=\"allowDrop($event)\" (dragend)=\"disableDrop($event)\" (dragleave)=\"disableDrop($event)\" (drop)=\"handleDrop($event)\">\n                        <tr *ngFor='let column of listOfColumns' (click)=\"selectColumn($event)\" draggable=\"true\" (drop)=\"handleDrop($event)\" (dragstart)=\"startDrag($event,'column')\" (dragleave)=\"disableDrop($event)\">\n                            <td class=\"listItem\">{{column.name}}</td>\n                        </tr>\n                    </tbody>\n                </table>\n                <div style=\"margin-top: 10px;margin-bottom: 5px; display: flex; justify-content: space-around;\">\n                    <button class=\"regularButton\" (click)=\"loadConfig()\" [disabled]=\"noTableSelected()\">Load Config</button>\n                    <button class=\"regularButton\" (click)=\"saveConfig()\" [disabled]=\"noTableSelected()\">Save Config</button>\n                </div>\n            </div>\n            <div class=\"col-sm-4\" style=\"border-style: solid; border-width: thin; padding-bottom: 4px;\" [hidden]=\"!currentField.name\">\n                <h4>Column Info</h4>\n                <form  class=\"form-horizontal\" style=\"height: 250px;\">\n                    <div class=\"form-group\">\n                        <label for=\"field\" class=\"control-label col-sm-2\">Field:</label>\n                        <div class=\"col-sm-6\">\n                            <input name=\"fieldName\" type=\"text\" class=\"form-control\" disabled [(ngModel)]=\"currentField.name\">\n                        </div>\n                    </div>\n                    <div class=\"form-group\">\n                        <label for=\"pwd\" class=\"control-label col-sm-2\">Title:</label>\n                        <div class=\"col-sm-6\">\n                            <input name=\"title\" type=\"text\" class=\"form-control\" id=\"title\" [(ngModel)]=\"currentField.title\" (change)=\"mapColumnsToGrid()\">\n                        </div>\n                    </div>\n                    <div class=\"form-group\">\n                        <div class=\"col-sm-offset-2 col-sm-10\">\n                            <div class=\"checkbox\">\n                                <label><input name=\"indexed\" type=\"checkbox\" [(ngModel)]=\"currentField.quickQuery\" (change)=\"mapColumnsToGrid()\">is present on Quick Query</label>\n                            </div>\n                        </div>\n                    </div>\n                    <div class=\"form-group\">\n                        <div class=\"col-sm-offset-2 col-sm-10\">\n                            <button (click)=\"deleteField()\">Delete</button>\n                        </div>\n                    </div>\n                 </form>\n            </div>\n        </div>\n\n        <div class=\"row\" style=\"border-style: solid; border-width: thin; padding-bottom: 4px;\" [style.height]=\"currentGridHeight\" [hidden]=\"currentTable === ''\">\n            <record-list [editWindow]=\"editWindow\" [dialogInstance]=\"dialog\" style=\"width:100%;height:100%\">\n                <query-band [enableSort]=\"true\" [enableQBE]=\"true\" [enableButtonBar]=\"true\" [enableAddRecord]=\"false\" [enableDeleteRecord]=\"true\" [enableExportGrid]=\"false\">\n                    <queryband class=\"form-group\">\n                        <browse-queryband  #customQueryBand [queryFields]=\"listOfColumns\" [(queryData)]=\"queryData\">\n                        </browse-queryband>\n                    </queryband>\n                    <custombuttonbar>\n                        <button class=\"regularButton\" style=\"width:70px;\" (click)=\"addRecord()\">Add</button>\n                    </custombuttonbar>\n                </query-band>\n                <datagrid\n                        [model]=\"model\"\n                        [selectionMode]=\"'multiple,row'\"\n                        [columns]=\"columnDefs\"\n                        [useLazyLoading]=\"true\"\n                        [optimizeGridLoading]=\"true\"\n                        [pageSize]=\"50\"\n                        [excelFilename]=\"'RecordList.xlsx'\"\n                        >\n                </datagrid>\n            </record-list>\n        </div>\n\n    </div>\n</web-application>\n"

/***/ }),

/***/ "./src/app/browseTable/browseFieldDialog.component.ts":
/*!************************************************************!*\
  !*** ./src/app/browseTable/browseFieldDialog.component.ts ***!
  \************************************************************/
/*! exports provided: BrowseFieldDialog */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "BrowseFieldDialog", function() { return BrowseFieldDialog; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");


let BrowseFieldDialog = class BrowseFieldDialog {
};
BrowseFieldDialog = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'field-content',
        template: ``
    })
], BrowseFieldDialog);



/***/ }),

/***/ "./src/app/browseTable/browseFormDialog.component.ts":
/*!***********************************************************!*\
  !*** ./src/app/browseTable/browseFormDialog.component.ts ***!
  \***********************************************************/
/*! exports provided: BrowseFormDialog */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "BrowseFormDialog", function() { return BrowseFormDialog; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var js44d__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! js44d */ "./node_modules/js44d/fesm2015/js44d.js");



let BrowseFormDialog = class BrowseFormDialog extends js44d__WEBPACK_IMPORTED_MODULE_2__["RecordEditWindow"] {
    ngAfterViewInit() {
        this.dialog.setTitle('Edit Record: ' + this.currentRecord.tableName);
        /**
         * as I'm dealing with a fake FourDModel instance, I need to populate
         * the model's attributes so data modification gets properly flagged
         */
        this.currentRecord.fields.forEach(element => {
            this.currentRecord.set(element.name, this.currentRecord[element.name]);
        });
        this.currentRecord.clearRecordDirtyFlag();
    }
};
BrowseFormDialog.dialogConfig = {
    actions: ['Maximize', 'Minimize', 'Close'], position: { top: 100, left: 100 }, selfCentered: true,
    title: 'Record Details',
    isResizable: true,
    width: 950, height: 500
};
BrowseFormDialog = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'modal-content',
        template: `
    <div style="display:flex;flex-direction:column;height:calc(100% - 20px);">
                <form style="display:grid;overflow:scroll;margin:20px 20px 5px 20px;padding-left:10px;border-style:outset">
                    <browse-inputfield *ngFor='let field of currentRecord.fields' [inputField]= "field" [currentRecord]="currentRecord"></browse-inputfield>                    
                </form>
                <div class="buttonBar" style="align-self:flex-end">
                    <button class="regularButton" style="width:90px;" (click)="dialog.close('cancel')">Cancel</button>
                    <button class="regularButton" style="margin-left:20px;width:90px;" (click)="saveRecord()">SAVE</button>
                </div>
    </div>
            `
    })
], BrowseFormDialog);



/***/ }),

/***/ "./src/app/browseTable/browseInputField.component.ts":
/*!***********************************************************!*\
  !*** ./src/app/browseTable/browseInputField.component.ts ***!
  \***********************************************************/
/*! exports provided: BrowseInputField */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "BrowseInputField", function() { return BrowseInputField; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _browseTable_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./browseTable.component */ "./src/app/browseTable/browseTable.component.ts");
/* harmony import */ var js44d__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! js44d */ "./node_modules/js44d/fesm2015/js44d.js");




/* tslint:disable */
let BrowseInputField = 
/* tslint:denable */
class BrowseInputField {
    constructor(fourD) {
        this.fourD = fourD;
    }
    /**
     * Here I have to use a trick to deal with the fact that I'm using a fake FourDModel
     * which has not get/set methods for each property
     * so I'm using generic typed variables that do the get/set functions I need
     */
    get stringField() {
        return this.currentRecord.get(this.inputField.name);
    }
    set stringField(v) {
        this.currentRecord.set(this.inputField.name, v);
        this.currentRecord[this.inputField.name] = v;
    }
    get numberField() {
        return this.currentRecord.get(this.inputField.name);
    }
    set numberField(v) {
        this.currentRecord.set(this.inputField.name, v);
        this.currentRecord[this.inputField.name] = v;
    }
    get booleanField() {
        return this.currentRecord.get(this.inputField.name);
    }
    set booleanField(v) {
        this.currentRecord.set(this.inputField.name, v);
        this.currentRecord[this.inputField.name] = v;
    }
    get dateField() {
        // need to deal with how browsers handle 'date' input fields, which is not really supported, so we treat it as a string input for now
        let value;
        let dateValue = this.currentRecord[this.inputField.name];
        if (typeof (dateValue) === 'string') {
            value = dateValue.replace(/\//g, '-');
        }
        else if (dateValue) {
            value = dateValue.getFullYear().toString() + '-';
            if (dateValue.getMonth() < 9)
                value += '0';
            value += (dateValue.getMonth() + 1).toString() + '-';
            if (dateValue.getDate() < 10)
                value += '0';
            value += dateValue.getDate().toString();
        }
        return value;
    }
    set dateField(v) {
        this.currentRecord.set(this.inputField.name, new Date(v.replace(/-/g, '\/')));
        this.currentRecord[this.inputField.name] = this.currentRecord.get(this.inputField.name);
    }
    get timeField() {
        // need to deal with how browsers handle 'date' input fields, which is not really supported, so we treat it as a string input for now
        let value;
        let timeValue = this.currentRecord[this.inputField.name];
        if (typeof (timeValue) === 'string') {
            value = timeValue;
        }
        else if (timeValue) {
            value = this.fourD.timeTo4DFormat(timeValue);
        }
        return value;
    }
    set timeField(v) {
        this.currentRecord.set(this.inputField.name, v);
        this.currentRecord[this.inputField.name] = this.currentRecord.get(this.inputField.name);
    }
    get objectField() {
        return JSON.stringify(this.currentRecord.get(this.inputField.name));
    }
    set objectField(v) {
        this.currentRecord.set(this.inputField.name, JSON.parse(v));
        this.currentRecord[this.inputField.name] = JSON.parse(v);
    }
};
BrowseInputField.ctorParameters = () => [
    { type: js44d__WEBPACK_IMPORTED_MODULE_3__["FourDInterface"] }
];
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", _browseTable_component__WEBPACK_IMPORTED_MODULE_2__["FieldDescription"])
], BrowseInputField.prototype, "inputField", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", js44d__WEBPACK_IMPORTED_MODULE_3__["FourDModel"])
], BrowseInputField.prototype, "currentRecord", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", String),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [String])
], BrowseInputField.prototype, "stringField", null);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Number),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [Number])
], BrowseInputField.prototype, "numberField", null);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Boolean),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [Boolean])
], BrowseInputField.prototype, "booleanField", null);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", String),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [String])
], BrowseInputField.prototype, "dateField", null);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", String),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [String])
], BrowseInputField.prototype, "timeField", null);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", String),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [String])
], BrowseInputField.prototype, "objectField", null);
BrowseInputField = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'browse-inputfield',
        template: `<div style="display:inline-block;margin:15px;width:calc(100% - 30px)">
                <label class="formHeaderSmall" [attr.for]="inputField.name" style="margin-right:10px;width:180px;vertical-align:top">{{inputField.title}}:&nbsp;&nbsp;</label>
                    <span [ngSwitch]="inputField.type">
                        <span *ngSwitchCase="'string'">
                            <fourd-dropdown *ngIf="inputField.choiceList != ''" listName="{{inputField.choiceList}}" [(selectedValue)]="stringField" (change)="stringField = $event.target.value"></fourd-dropdown>
                            <textarea *ngIf="inputField.length > 0 && inputField.choiceList == ''" [maxlength]="inputField.length" [name]="inputField.name" type="text" class="fieldEntry"  cols="90" style="resize:vertical;width:75%" [(ngModel)]="stringField"></textarea>
                            <textarea *ngIf="!inputField.length && inputField.choiceList == ''"  [name]="inputField.name" type="text" class="fieldEntry"  cols="90" style="resize:vertical;width:75%" [(ngModel)]="stringField" [disabled]="inputField.readonly"></textarea>
                        </span>
                        <input *ngSwitchCase="'Date'"  [name]="inputField.name" type="date" class="fieldEntry"  style="width:125px;height:20px;" [(ngModel)]="dateField" [disabled]="inputField.readonly"/>
                        <input *ngSwitchCase="'Time'"  [name]="inputField.name" type="time" class="fieldEntry"  style="width:125px;height:20px;" [(ngModel)]="timeField" [disabled]="inputField.readonly"/>
                        <input *ngSwitchCase="'number'"  [name]="inputField.name" type="number" class="fieldEntry"  style="width:80px;height:20px;text-align:right;" [(ngModel)]="numberField" [disabled]="inputField.readonly"/>
                        <input *ngSwitchCase="'Number'"  [name]="inputField.name" type="number" class="fieldEntry"  style="width:80px;height:20px;" [(ngModel)]="numberField" [disabled]="inputField.readonly"/>
                        <input *ngSwitchCase="'float'"  [name]="inputField.name" type="number" class="fieldEntry"  style="width:80px;height:20px;" [(ngModel)]="numberField" [disabled]="inputField.readonly"/>
                        <input *ngSwitchCase="'boolean'"  [name]="inputField.name" type="checkbox" class="fieldEntry" style="height:30px;width:50px;margin-top:-6px;" [(ngModel)]="booleanField" [disabled]="inputField.readonly"/>
                        <textarea *ngSwitchCase="'json'"  [name]="inputField.name" type="text" class="fieldEntry"  cols="90" style="resize:vertical;width:75%" [(ngModel)]="objectField" disabled></textarea>
                        <img *ngSwitchCase="'picture'" [src]="stringField | base64ImageRef" style="height:300px;"/>
                     </span>    
               
                </div>
 
            `
    })
    /* tslint:denable */
    ,
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [js44d__WEBPACK_IMPORTED_MODULE_3__["FourDInterface"]])
], BrowseInputField);



/***/ }),

/***/ "./src/app/browseTable/browseQuery.component.ts":
/*!******************************************************!*\
  !*** ./src/app/browseTable/browseQuery.component.ts ***!
  \******************************************************/
/*! exports provided: BrowseQueryBand */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "BrowseQueryBand", function() { return BrowseQueryBand; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");


let BrowseQueryBand = class BrowseQueryBand {
    constructor() {
        this.queryData = {};
    }
    //
    // build 4C-TV query based on items from query band
    //
    get currentQuery() {
        const currQuery = [];
        this.queryFields.forEach(field => {
            if (field.quickQuery) {
                switch (field.type) {
                    case 'string':
                        if (this.queryData[field.name] && this.queryData[field.name] !== '') {
                            currQuery.push(field.field + ';contains;' + this.queryData[field.name] + ';AND');
                        }
                        break;
                    case 'number':
                    case 'Number':
                    case 'float':
                    case 'boolean':
                    case 'Time':
                        if (this.queryData[field.name] && this.queryData[field.name] !== '') {
                            currQuery.push(field.field + ';=;' + this.queryData[field.name] + ';AND');
                        }
                        break;
                    case 'Date':
                        if (this.queryData[field.name] && this.queryData[field.name] !== '') {
                            currQuery.push(field.field + ';=;' + (this.queryData[field.name]).replace(/-/g, '') + ';AND');
                        }
                        break;
                }
            }
        });
        return (currQuery.length > 0) ? { query: currQuery } : null; // {query:['all']};
    }
};
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Array)
], BrowseQueryBand.prototype, "queryFields", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
], BrowseQueryBand.prototype, "queryData", void 0);
BrowseQueryBand = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'browse-queryband',
        template: `
                <form style="display:flex;overflow:auto">
                    <div *ngFor='let field of queryFields'  style="float: left;height: 100%; margin-right: 10px;">
                        <browse-queryfield *ngIf='field.quickQuery' [queryField]= "field" [queryData]="queryData"></browse-queryfield>
                    </div>
                </form>
            `
    })
], BrowseQueryBand);



/***/ }),

/***/ "./src/app/browseTable/browseQueryField.component.ts":
/*!***********************************************************!*\
  !*** ./src/app/browseTable/browseQueryField.component.ts ***!
  \***********************************************************/
/*! exports provided: BrowseQueryField */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "BrowseQueryField", function() { return BrowseQueryField; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _browseTable_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./browseTable.component */ "./src/app/browseTable/browseTable.component.ts");



let BrowseQueryField = class BrowseQueryField {
    constructor() {
        this.queryData = {};
    }
};
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", _browseTable_component__WEBPACK_IMPORTED_MODULE_2__["FieldDescription"])
], BrowseQueryField.prototype, "queryField", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
], BrowseQueryField.prototype, "queryData", void 0);
BrowseQueryField = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'browse-queryfield',
        template: `
                <label class="fieldPrompt" [attr.for]="queryField.name" style="margin-right:10px;">{{queryField.title}}:&nbsp;&nbsp;
                    <div [ngSwitch]="queryField.type">
                        <input *ngSwitchCase="'string'"  [name]="queryField.name" type="text" class="fieldEntry"  style="width:180px;height:20px;" [(ngModel)]="queryData[queryField.name]"/>
                        <input *ngSwitchCase="'Date'"  [name]="queryField.name" type="date" class="fieldEntry"  style="width:125px;height:20px;" [(ngModel)]="queryData[queryField.name]"/>
                        <input *ngSwitchCase="'Time'"  [name]="queryField.name" type="time" class="fieldEntry"  style="width:100px;height:20px;" [(ngModel)]="queryData[queryField.name]"/>
                        <input *ngSwitchCase="'number'"  [name]="queryField.name" type="number" class="fieldEntry"  style="width:80px;height:20px;" [(ngModel)]="queryData[queryField.name]"/>
                        <input *ngSwitchCase="'Number'"  [name]="queryField.name" type="number" class="fieldEntry"  style="width:80px;height:20px;" [(ngModel)]="queryData[queryField.name]"/>
                        <input *ngSwitchCase="'float'"  [name]="queryField.name" type="number" class="fieldEntry"  style="width:80px;height:20px;" [(ngModel)]="queryData[queryField.name]"/>
                        <input *ngSwitchCase="'boolean'"  [name]="queryField.name" type="checkbox" class="fieldEntry"  style="width:80px;height:20px;" [(ngModel)]="queryData[queryField.name]"/>
                     </div>    
                </label>
 
            `
    })
], BrowseQueryField);



/***/ }),

/***/ "./src/app/browseTable/browseTable.component.css":
/*!*******************************************************!*\
  !*** ./src/app/browseTable/browseTable.component.css ***!
  \*******************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".block {\n    border-style: solid; \n    border-width: thin; \n    padding-bottom: 4px; \n    display:-webkit-box; \n    display:flex; \n    -webkit-box-orient: vertical; \n    -webkit-box-direction: normal; \n            flex-direction: column; \n    height: 289px;\n}\n\n.listTable {\n    border: 1px solid black;\n    border-collapse: collapse;\n    width: 100%;\n    height: 250px;;\n}\n\n.listBody {\n    overflow: auto;\n    display: block;\n    height: 100%;\n}\n\n.listItem {\n    padding-left: 3px;\n    border-style: none;\n}\n\n.selectedItem {\n    background: brown;\n    color: white;\n}\n\n.highlight {\n    background-color: #00FF00;\n}\n\n.droppable {\n    border: 2px dashed gray;\n}\n\n.icon {\n    font-family: FontAwesome, fontawesome;\n    font-size: 24;\n }\n\n/* Main Navigation */\n\nul#navigation {\n    margin:0px auto;\n    position:relative;\n    float:left;\n}\n\nul#navigation li {\n    display:inline;\n    float:left;\n\n}\n\nul#navigation li h5 {\n    padding:5px 5px 5px 15px;\n    display:inline-block;\n    margin: 5px 0 0 0;\n    width: 100%;\n}\n\nul#navigation li h5:hover {\n    background:#f8f8f8;\n    color:#282828;\n}\n\nul#navigation li:hover > a {\n    background:#fff;\n}\n\n/* Drop-Down Navigation */\n\nul#navigation li:hover > ul\n{\n/*these 2 styles are very important,\nbeing the ones which make the drop-down to appear on hover */\n    visibility:visible;\n    opacity:1;\n}\n\nul#navigation ul, ul#navigation ul li ul {\n    list-style: none;\n    margin-left: 10px;\n    padding: 0;\n/*the next 2 styles are very important,\nbeing the ones which make the drop-down to stay hidden */\n    visibility:hidden;\n    opacity:0;\n    position: absolute;\n    z-index: 99999;\n    width:180px;\n    background:#ddd;\n    box-shadow:1px 1px 3px #ccc;\n/* css3 transitions for smooth hover effect */\n    -webkit-transition:opacity 0.2s linear, visibility 0.2s linear;\n    transition:opacity 0.2s linear, visibility 0.2s linear;\n}\n\nul#navigation ul {\n    top: 25px;\n    left: 10px;\n}\n\nul#navigation ul li ul {\n    top: 0;\n    left: 181px; /* strong related to width:180px; from above */\n}\n\nul#navigation ul li {\n    clear:both;\n    width:100%;\n    border:0 none;\n    border-bottom:1px solid #c9c9c9;\n}\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvYnJvd3NlVGFibGUvYnJvd3NlVGFibGUuY29tcG9uZW50LmNzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtJQUNJLG1CQUFtQjtJQUNuQixrQkFBa0I7SUFDbEIsbUJBQW1CO0lBQ25CLG1CQUFZO0lBQVosWUFBWTtJQUNaLDRCQUFzQjtJQUF0Qiw2QkFBc0I7WUFBdEIsc0JBQXNCO0lBQ3RCLGFBQWE7QUFDakI7O0FBRUE7SUFDSSx1QkFBdUI7SUFDdkIseUJBQXlCO0lBQ3pCLFdBQVc7SUFDWCxhQUFhO0FBQ2pCOztBQUVBO0lBQ0ksY0FBYztJQUNkLGNBQWM7SUFDZCxZQUFZO0FBQ2hCOztBQUVBO0lBQ0ksaUJBQWlCO0lBQ2pCLGtCQUFrQjtBQUN0Qjs7QUFFQTtJQUNJLGlCQUFpQjtJQUNqQixZQUFZO0FBQ2hCOztBQUdBO0lBQ0kseUJBQXlCO0FBQzdCOztBQUVBO0lBQ0ksdUJBQXVCO0FBQzNCOztBQUVBO0lBQ0kscUNBQXFDO0lBQ3JDLGFBQWE7Q0FDaEI7O0FBRUQsb0JBQW9COztBQUdwQjtJQUNJLGVBQWU7SUFDZixpQkFBaUI7SUFDakIsVUFBVTtBQUNkOztBQUVBO0lBQ0ksY0FBYztJQUNkLFVBQVU7O0FBRWQ7O0FBRUE7SUFDSSx3QkFBd0I7SUFDeEIsb0JBQW9CO0lBQ3BCLGlCQUFpQjtJQUNqQixXQUFXO0FBQ2Y7O0FBRUE7SUFDSSxrQkFBa0I7SUFDbEIsYUFBYTtBQUNqQjs7QUFJQTtJQUNJLGVBQWU7QUFDbkI7O0FBQ0EseUJBQXlCOztBQUN6Qjs7QUFFQTs0REFDNEQ7SUFDeEQsa0JBQWtCO0lBQ2xCLFNBQVM7QUFDYjs7QUFFQTtJQUNJLGdCQUFnQjtJQUNoQixpQkFBaUI7SUFDakIsVUFBVTtBQUNkO3dEQUN3RDtJQUNwRCxpQkFBaUI7SUFDakIsU0FBUztJQUNULGtCQUFrQjtJQUNsQixjQUFjO0lBQ2QsV0FBVztJQUNYLGVBQWU7SUFDZiwyQkFBMkI7QUFDL0IsNkNBQTZDO0lBQ3pDLDhEQUE4RDtJQUc5RCxzREFBc0Q7QUFDMUQ7O0FBRUE7SUFDSSxTQUFTO0lBQ1QsVUFBVTtBQUNkOztBQUVBO0lBQ0ksTUFBTTtJQUNOLFdBQVcsRUFBRSw4Q0FBOEM7QUFDL0Q7O0FBRUE7SUFDSSxVQUFVO0lBQ1YsVUFBVTtJQUNWLGFBQWE7SUFDYiwrQkFBK0I7QUFDbkMiLCJmaWxlIjoic3JjL2FwcC9icm93c2VUYWJsZS9icm93c2VUYWJsZS5jb21wb25lbnQuY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLmJsb2NrIHtcbiAgICBib3JkZXItc3R5bGU6IHNvbGlkOyBcbiAgICBib3JkZXItd2lkdGg6IHRoaW47IFxuICAgIHBhZGRpbmctYm90dG9tOiA0cHg7IFxuICAgIGRpc3BsYXk6ZmxleDsgXG4gICAgZmxleC1kaXJlY3Rpb246IGNvbHVtbjsgXG4gICAgaGVpZ2h0OiAyODlweDtcbn1cblxuLmxpc3RUYWJsZSB7XG4gICAgYm9yZGVyOiAxcHggc29saWQgYmxhY2s7XG4gICAgYm9yZGVyLWNvbGxhcHNlOiBjb2xsYXBzZTtcbiAgICB3aWR0aDogMTAwJTtcbiAgICBoZWlnaHQ6IDI1MHB4Oztcbn1cblxuLmxpc3RCb2R5IHtcbiAgICBvdmVyZmxvdzogYXV0bztcbiAgICBkaXNwbGF5OiBibG9jaztcbiAgICBoZWlnaHQ6IDEwMCU7XG59XG5cbi5saXN0SXRlbSB7XG4gICAgcGFkZGluZy1sZWZ0OiAzcHg7XG4gICAgYm9yZGVyLXN0eWxlOiBub25lO1xufVxuXG4uc2VsZWN0ZWRJdGVtIHtcbiAgICBiYWNrZ3JvdW5kOiBicm93bjtcbiAgICBjb2xvcjogd2hpdGU7XG59XG5cblxuLmhpZ2hsaWdodCB7XG4gICAgYmFja2dyb3VuZC1jb2xvcjogIzAwRkYwMDtcbn1cblxuLmRyb3BwYWJsZSB7XG4gICAgYm9yZGVyOiAycHggZGFzaGVkIGdyYXk7XG59XG5cbi5pY29uIHtcbiAgICBmb250LWZhbWlseTogRm9udEF3ZXNvbWUsIGZvbnRhd2Vzb21lO1xuICAgIGZvbnQtc2l6ZTogMjQ7XG4gfVxuIFxuLyogTWFpbiBOYXZpZ2F0aW9uICovXG5cbiBcbnVsI25hdmlnYXRpb24ge1xuICAgIG1hcmdpbjowcHggYXV0bztcbiAgICBwb3NpdGlvbjpyZWxhdGl2ZTtcbiAgICBmbG9hdDpsZWZ0O1xufVxuIFxudWwjbmF2aWdhdGlvbiBsaSB7XG4gICAgZGlzcGxheTppbmxpbmU7XG4gICAgZmxvYXQ6bGVmdDtcblxufVxuIFxudWwjbmF2aWdhdGlvbiBsaSBoNSB7XG4gICAgcGFkZGluZzo1cHggNXB4IDVweCAxNXB4O1xuICAgIGRpc3BsYXk6aW5saW5lLWJsb2NrO1xuICAgIG1hcmdpbjogNXB4IDAgMCAwO1xuICAgIHdpZHRoOiAxMDAlO1xufVxuIFxudWwjbmF2aWdhdGlvbiBsaSBoNTpob3ZlciB7XG4gICAgYmFja2dyb3VuZDojZjhmOGY4O1xuICAgIGNvbG9yOiMyODI4Mjg7XG59XG4gXG5cbiBcbnVsI25hdmlnYXRpb24gbGk6aG92ZXIgPiBhIHtcbiAgICBiYWNrZ3JvdW5kOiNmZmY7XG59XG4vKiBEcm9wLURvd24gTmF2aWdhdGlvbiAqL1xudWwjbmF2aWdhdGlvbiBsaTpob3ZlciA+IHVsXG57XG4vKnRoZXNlIDIgc3R5bGVzIGFyZSB2ZXJ5IGltcG9ydGFudCxcbmJlaW5nIHRoZSBvbmVzIHdoaWNoIG1ha2UgdGhlIGRyb3AtZG93biB0byBhcHBlYXIgb24gaG92ZXIgKi9cbiAgICB2aXNpYmlsaXR5OnZpc2libGU7XG4gICAgb3BhY2l0eToxO1xufVxuIFxudWwjbmF2aWdhdGlvbiB1bCwgdWwjbmF2aWdhdGlvbiB1bCBsaSB1bCB7XG4gICAgbGlzdC1zdHlsZTogbm9uZTtcbiAgICBtYXJnaW4tbGVmdDogMTBweDtcbiAgICBwYWRkaW5nOiAwO1xuLyp0aGUgbmV4dCAyIHN0eWxlcyBhcmUgdmVyeSBpbXBvcnRhbnQsXG5iZWluZyB0aGUgb25lcyB3aGljaCBtYWtlIHRoZSBkcm9wLWRvd24gdG8gc3RheSBoaWRkZW4gKi9cbiAgICB2aXNpYmlsaXR5OmhpZGRlbjtcbiAgICBvcGFjaXR5OjA7XG4gICAgcG9zaXRpb246IGFic29sdXRlO1xuICAgIHotaW5kZXg6IDk5OTk5O1xuICAgIHdpZHRoOjE4MHB4O1xuICAgIGJhY2tncm91bmQ6I2RkZDtcbiAgICBib3gtc2hhZG93OjFweCAxcHggM3B4ICNjY2M7XG4vKiBjc3MzIHRyYW5zaXRpb25zIGZvciBzbW9vdGggaG92ZXIgZWZmZWN0ICovXG4gICAgLXdlYmtpdC10cmFuc2l0aW9uOm9wYWNpdHkgMC4ycyBsaW5lYXIsIHZpc2liaWxpdHkgMC4ycyBsaW5lYXI7XG4gICAgLW1vei10cmFuc2l0aW9uOm9wYWNpdHkgMC4ycyBsaW5lYXIsIHZpc2liaWxpdHkgMC4ycyBsaW5lYXI7XG4gICAgLW8tdHJhbnNpdGlvbjpvcGFjaXR5IDAuMnMgbGluZWFyLCB2aXNpYmlsaXR5IDAuMnMgbGluZWFyO1xuICAgIHRyYW5zaXRpb246b3BhY2l0eSAwLjJzIGxpbmVhciwgdmlzaWJpbGl0eSAwLjJzIGxpbmVhcjtcbn1cbiBcbnVsI25hdmlnYXRpb24gdWwge1xuICAgIHRvcDogMjVweDtcbiAgICBsZWZ0OiAxMHB4O1xufVxuIFxudWwjbmF2aWdhdGlvbiB1bCBsaSB1bCB7XG4gICAgdG9wOiAwO1xuICAgIGxlZnQ6IDE4MXB4OyAvKiBzdHJvbmcgcmVsYXRlZCB0byB3aWR0aDoxODBweDsgZnJvbSBhYm92ZSAqL1xufVxuIFxudWwjbmF2aWdhdGlvbiB1bCBsaSB7XG4gICAgY2xlYXI6Ym90aDtcbiAgICB3aWR0aDoxMDAlO1xuICAgIGJvcmRlcjowIG5vbmU7XG4gICAgYm9yZGVyLWJvdHRvbToxcHggc29saWQgI2M5YzljOTtcbn1cbiJdfQ== */"

/***/ }),

/***/ "./src/app/browseTable/browseTable.component.ts":
/*!******************************************************!*\
  !*** ./src/app/browseTable/browseTable.component.ts ***!
  \******************************************************/
/*! exports provided: FieldDescription, BrowseTableComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "FieldDescription", function() { return FieldDescription; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "BrowseTableComponent", function() { return BrowseTableComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm2015/http.js");
/* harmony import */ var js44d__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! js44d */ "./node_modules/js44d/fesm2015/js44d.js");
/* harmony import */ var _browseFormDialog_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./browseFormDialog.component */ "./src/app/browseTable/browseFormDialog.component.ts");








class FieldDescription {
}
let BrowseTableComponent = class BrowseTableComponent {
    constructor(http, fourD, modal, viewref) {
        this.http = http;
        this.fourD = fourD;
        this.modal = modal;
        this.viewref = viewref;
        this.numOfTables = 0;
        this.listOfTables = [];
        this.currentTable = '';
        this.listedTable = '';
        this.listOfFields = [];
        this.listOfColumns = [];
        this.relatedOneTables = [];
        this.currentField = new FieldDescription();
        this.queryData = {};
        this.hideBrowseConfig = false;
        this.currentGridHeight = 'calc(100% - 330px)';
        // Declare Program edit Window
        //
        this.editWindow = _browseFormDialog_component__WEBPACK_IMPORTED_MODULE_4__["BrowseFormDialog"];
        // the columns for the datagrid
        this.columnDefs = [
            { title: 'Record ID', field: 'RecordID', width: '' }
        ];
        //
        // Declare Datagrid properties
        //
        this.model = js44d__WEBPACK_IMPORTED_MODULE_3__["FourDModel"]; // the record datamodel to use 
        this.selectedRow = null;
        this.selectedColumn = null;
        this.selectedColumnIndex = -1;
        this.totalRecordCount = 0;
        this.models = [];
        /* tslint:disable */
        // need to disable lint here otw if'll flag variable before method rule, but I'm puting this at the button
        // on purpose, to have it out of the way
        //
        // define the dataSource used to populate/handle the grid's interface to 4D
        //
        this.dataSource = new kendo.data.DataSource({
            /* tslint:enabe */
            transport: {
                read: (options) => {
                    // console.log(options);
                    const newModel = new js44d__WEBPACK_IMPORTED_MODULE_3__["FourDModel"]();
                    newModel.tableName = this.currentTable;
                    const start = (options.data.pageSize && options.data.pageSize > 0) ? options.data.skip : 0;
                    const numrecs = (options.data.pageSize && options.data.pageSize > 0) ? options.data.pageSize : -1;
                    // now build filter if set
                    const filter = [];
                    if (options.data.filter) {
                        options.data.filter.filters.forEach((item) => {
                            let comparator = '=';
                            switch (item.operator) {
                                case 'eq':
                                    comparator = '=';
                                    break;
                                case 'neq':
                                    comparator = '#';
                                    break;
                                case 'startswith':
                                    comparator = 'begins with';
                                    break;
                                case 'endswith':
                                    comparator = 'ends with';
                                    break;
                                case 'isempty':
                                    comparator = '=';
                                    item.value = '';
                                    break;
                                case 'isnotempty':
                                    comparator = '#';
                                    item.value = '';
                                    break;
                                default:
                                    comparator = item.operator;
                                    break;
                            }
                            filter.push(newModel.tableName + '.' + item.field + ';' + comparator + ';' + item.value + ';' + options.data.filter.logic);
                        });
                    }
                    let orderby = '';
                    if (options.data.sort && options.data.sort.length > 0) {
                        options.data.sort.forEach((item) => {
                            orderby += (item.dir === 'asc') ? '>' : '<';
                            orderby += newModel.tableName + '.' + item.field + '%';
                        });
                    }
                    const query = this.theGrid.getDataProvider().queryString;
                    const body = { Username: js44d__WEBPACK_IMPORTED_MODULE_3__["FourDInterface"].currentUser };
                    body.TableName = newModel.tableName;
                    body.StartRec = start;
                    body.NumRecs = numrecs;
                    body.QueryString = JSON.stringify(query);
                    body.Columns = js44d__WEBPACK_IMPORTED_MODULE_3__["Base64"].encode(js44d__WEBPACK_IMPORTED_MODULE_3__["Utf8"].utf8encode(JSON.stringify(this.listOfColumns)));
                    if (filter.length > 0) {
                        body.FilterOptions = JSON.stringify({ query: filter });
                    }
                    if (orderby) {
                        body.OrderBy = orderby;
                    }
                    this.fourD.call4DRESTMethod('REST_GetRecords', body)
                        .subscribe(resultJSON => {
                        this.totalRecordCount = 0;
                        this.models = [];
                        let data = [];
                        if (resultJSON && resultJSON['selected'] && resultJSON['records']) {
                            this.totalRecordCount = resultJSON['selected'];
                            const recList = resultJSON['records'];
                            recList.forEach(record => {
                                const theModel = new js44d__WEBPACK_IMPORTED_MODULE_3__["FourDModel"]();
                                theModel.recordNumber = record['_recnum'];
                                this.models.push(theModel);
                                data.push(record);
                            });
                        }
                        this.theGrid.getDataProvider().models = this.models;
                        options.success(data);
                    }, error => {
                        console.log('error:' + JSON.stringify(error));
                    });
                },
                destroy: (options) => {
                    console.log('delete', options);
                },
                update: (options) => {
                    console.log('update', options);
                },
                create: (options) => {
                    console.log('create', options);
                },
                parameterMap: (options, operation) => {
                    console.log('map', options);
                    if (operation !== 'read' && options.models) {
                        return { models: kendo.stringify(options.models) };
                    }
                    else {
                        return options;
                    }
                }
            },
            schema: {
                total: (response) => {
                    // console.log('total');
                    return this.totalRecordCount;
                }
            },
            serverPaging: true,
            serverSorting: true,
            serverFiltering: true,
            serverGrouping: true,
            pageSize: 50
        });
    }
    ngAfterContentInit() {
        this.fourD.call4DRESTMethod('REST_GetListOfTables', {})
            .subscribe(resultJSON => {
            this.numOfTables = resultJSON.tableCount;
            this.listOfTables = resultJSON.tableList;
            this.listOfTables.sort();
            this.recordList.queryBand.switchState();
        });
    }
    hideConfig() {
        this.hideBrowseConfig = true;
        this.currentGridHeight = 'calc(100% - 30px)';
        this.recordList.theGrid.resize();
        this.recordList.refreshGrid();
    }
    showConfig() {
        this.hideBrowseConfig = false;
        this.currentGridHeight = 'calc(100% - 330px)';
        this.recordList.theGrid.resize();
        this.recordList.refreshGrid();
    }
    saveConfig() {
        if (this.currentTable !== '') {
            localStorage.setItem('4Dbrowse' + this.currentTable, JSON.stringify(this.listOfColumns));
        }
    }
    loadConfig() {
        if (this.currentTable !== '') {
            const config = localStorage.getItem('4Dbrowse' + this.currentTable);
            if (config && config !== '') {
                // we have a saved configuration, use it...
                this.listOfColumns = JSON.parse(config);
                this.mapColumnsToGrid(); // update grid then
            }
        }
    }
    selectTable(event) {
        if (this.selectedRow) {
            this.selectedRow.classList.remove('selectedItem');
        }
        const selectRow = event.currentTarget.rowIndex;
        if (selectRow < this.numOfTables) {
            this.selectedRow = event.target;
            this.currentTable = this.listOfTables[selectRow];
            this.listedTable = this.currentTable;
            this.fourD.call4DRESTMethod('REST_GetFieldsInTable', { TableName: this.listOfTables[selectRow] })
                .subscribe(resultJSON => {
                this.listOfFields = resultJSON.fieldList;
                this.selectedRow.classList.add('selectedItem');
                this.model.prototype.tableName = this.currentTable;
                this.model.prototype.fields = this.listOfFields;
                this.model.prototype.primaryKey_ = resultJSON.primaryKey;
                // set default columns
                this.listOfColumns = [];
                this.relatedOneTables = [this.currentTable];
                this.queryData = {};
                for (let index = 0; index < this.listOfFields.length; index++) {
                    const element = this.listOfFields[index];
                    element.field = element.longname;
                    element.title = element.name;
                    if (element.indexed) {
                        element.quickQuery = true;
                        this.listOfColumns.push(element);
                    }
                    else {
                        element.quickQuery = false;
                    }
                    if (element.relatesTo && element.relatesTo !== '') {
                        this.relatedOneTables.push(element.relatesTo.split('.')[0]);
                    }
                }
                this.mapColumnsToGrid(); // update datagrid columns
            });
        }
    }
    selectColumn(event) {
        if (this.selectedColumn) {
            this.selectedColumn.classList.remove('selectedItem');
        }
        this.selectedColumnIndex = event.currentTarget.rowIndex;
        if (this.selectedColumnIndex < this.listOfColumns.length) {
            this.selectedColumn = event.target;
            this.selectedColumn.classList.add('selectedItem');
            this.currentField = this.listOfColumns[this.selectedColumnIndex];
        }
        else {
            this.selectedColumnIndex = -1;
        }
    }
    startDrag(event, type) {
        event.effectAllowed = 'copy';
        event.dataTransfer.setData('type', type);
        event.dataTransfer.setData('row', event.currentTarget.rowIndex);
    }
    allowDrop(event) {
        if (event.preventDefault) {
            event.preventDefault();
        } // Necessary. Allows us to drop.
        if (event.stopPropagation) {
            event.stopPropagation();
        }
        if (event.type === 'dragenter') {
            event.target.classList.add('droppable');
            event.dataTransfer.dropEffect = 'copy'; // See the section on the DataTransfer object.
        }
        return false;
    }
    disableDrop(event) {
        if (event.stopPropagation) {
            event.stopPropagation();
        }
        event.target.classList.remove('droppable');
    }
    handleDrop(event) {
        if (event.stopPropagation) {
            event.stopPropagation();
        }
        this.disableDrop(event);
        const source = event.dataTransfer.getData('type');
        const row = event.dataTransfer.getData('row');
        const element = this.listOfFields[row];
        element.quickQuery = false;
        if (event.currentTarget.localName === 'tbody') {
            if (source === 'field') {
                this.listOfColumns.push(element);
            }
            else {
                this.listOfColumns.push(element);
                this.listOfColumns.splice(row, 1);
            }
        }
        else {
            if (source === 'field') {
                this.listOfColumns.splice(event.currentTarget.rowIndex, 0, element);
            }
            else {
                const moveToIndex = event.currentTarget.rowIndex;
                const item = this.listOfColumns.splice(row, 1);
                if (row < moveToIndex) {
                    // moving up...
                    this.listOfColumns.splice(event.currentTarget.rowIndex - 1, 0, item[0]);
                }
                else {
                    // moving down
                    this.listOfColumns.splice(event.currentTarget.rowIndex, 0, item[0]);
                }
            }
        }
        this.mapColumnsToGrid(); // update datagrid columns
    }
    deleteField() {
        if (this.selectedColumnIndex >= 0) {
            this.listOfColumns.splice(this.selectedColumnIndex, 1);
            this.selectedColumnIndex = -1;
            this.selectedColumn = null;
            this.currentField = new FieldDescription();
            this.mapColumnsToGrid();
        }
    }
    mapColumnsToGrid() {
        this.columnDefs = [];
        for (let index = 0; index < this.listOfColumns.length; index++) {
            const element = this.listOfColumns[index];
            this.columnDefs.push({ title: element.title, field: element.name, width: (element['width']) ? element['width'] : '' });
        }
        // this.theGrid.setColumnConfig(this.columnDefs);
        this.theGrid.setExternalDataSource(this.dataSource, this.columnDefs);
        this.recordList.clearQuery(); // clear any previous query
        this.theGrid.loadData(); // and clear the grid
        this.theGrid.gridObject.bind('columnResize', () => { this.saveColumnConfig(); });
    }
    showRelatedTable(event) {
        this.listedTable = event.target.textContent;
        this.fourD.call4DRESTMethod('REST_GetFieldsInTable', { TableName: this.listedTable })
            .subscribe(resultJSON => {
            this.listOfFields = resultJSON.fieldList;
            for (let index = 0; index < this.listOfFields.length; index++) {
                const element = this.listOfFields[index];
                element.field = element.longname;
                element.title = element.name;
                element.quickQuery = false;
            }
        });
    }
    addRecord() {
        const newModel = new js44d__WEBPACK_IMPORTED_MODULE_3__["FourDModel"]();
        newModel.tableName = this.currentTable;
        newModel.fields = this.listOfFields;
        newModel.clearRecord();
        this.modal.openInside(this.editWindow, this.viewref, newModel, this.editWindow['dialogConfig']); // open edit dialog
    }
    noTableSelected() { return this.currentTable === ''; }
    saveColumnConfig() {
        if (this.currentTable !== '') {
            for (let i = 0; i < this.listOfColumns.length; i++) {
                if (this.theGrid.gridObject.columns[i]['width'] && this.theGrid.gridObject.columns[i]['width'] > 0) {
                    this.listOfColumns[i]['width'] = this.theGrid.gridObject.columns[i]['width'];
                }
            }
        }
    }
};
BrowseTableComponent.dialogConfig = {
    actions: ['Maximize', 'Minimize', 'Close'], position: { top: 100, left: 50 }, selfCentered: true,
    title: 'Browse Table',
    isResizable: true,
    width: 1200, height: 800, minWidth: 1200, minHeight: 700
};
BrowseTableComponent.ctorParameters = () => [
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"] },
    { type: js44d__WEBPACK_IMPORTED_MODULE_3__["FourDInterface"] },
    { type: js44d__WEBPACK_IMPORTED_MODULE_3__["Modal"] },
    { type: _angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewContainerRef"] }
];
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
], BrowseTableComponent.prototype, "numOfTables", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Array)
], BrowseTableComponent.prototype, "listOfTables", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
], BrowseTableComponent.prototype, "currentTable", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
], BrowseTableComponent.prototype, "listedTable", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Array)
], BrowseTableComponent.prototype, "listOfFields", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Array)
], BrowseTableComponent.prototype, "listOfColumns", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Array)
], BrowseTableComponent.prototype, "relatedOneTables", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", FieldDescription)
], BrowseTableComponent.prototype, "currentField", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
], BrowseTableComponent.prototype, "queryData", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
], BrowseTableComponent.prototype, "hideBrowseConfig", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
], BrowseTableComponent.prototype, "currentGridHeight", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChild"])(js44d__WEBPACK_IMPORTED_MODULE_3__["RecordList"], { static: false }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", js44d__WEBPACK_IMPORTED_MODULE_3__["RecordList"])
], BrowseTableComponent.prototype, "recordList", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChild"])(js44d__WEBPACK_IMPORTED_MODULE_3__["DataGrid"], { static: false }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", js44d__WEBPACK_IMPORTED_MODULE_3__["DataGrid"])
], BrowseTableComponent.prototype, "theGrid", void 0);
BrowseTableComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'sd-browse-table',
        template: __webpack_require__(/*! raw-loader!./browseTable.component.html */ "./node_modules/raw-loader/index.js!./src/app/browseTable/browseTable.component.html"),
        providers: [_angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"], js44d__WEBPACK_IMPORTED_MODULE_3__["FourDInterface"], js44d__WEBPACK_IMPORTED_MODULE_3__["Modal"]],
        styles: [__webpack_require__(/*! ./browseTable.component.css */ "./src/app/browseTable/browseTable.component.css")]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"], js44d__WEBPACK_IMPORTED_MODULE_3__["FourDInterface"], js44d__WEBPACK_IMPORTED_MODULE_3__["Modal"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewContainerRef"]])
], BrowseTableComponent);



/***/ }),

/***/ "./src/app/browseTable/browseTable.module.ts":
/*!***************************************************!*\
  !*** ./src/app/browseTable/browseTable.module.ts ***!
  \***************************************************/
/*! exports provided: BrowseRoutes, BrowseTableModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "BrowseRoutes", function() { return BrowseRoutes; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "BrowseTableModule", function() { return BrowseTableModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm2015/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm2015/http.js");
/* harmony import */ var _browseTableDialog_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./browseTableDialog.component */ "./src/app/browseTable/browseTableDialog.component.ts");
/* harmony import */ var _browseTable_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./browseTable.component */ "./src/app/browseTable/browseTable.component.ts");
/* harmony import */ var _browseQuery_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./browseQuery.component */ "./src/app/browseTable/browseQuery.component.ts");
/* harmony import */ var _browseQueryField_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./browseQueryField.component */ "./src/app/browseTable/browseQueryField.component.ts");
/* harmony import */ var _browseInputField_component__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./browseInputField.component */ "./src/app/browseTable/browseInputField.component.ts");
/* harmony import */ var _browseFormDialog_component__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./browseFormDialog.component */ "./src/app/browseTable/browseFormDialog.component.ts");
/* harmony import */ var _browseFieldDialog_component__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./browseFieldDialog.component */ "./src/app/browseTable/browseFieldDialog.component.ts");
/* harmony import */ var js44d__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! js44d */ "./node_modules/js44d/fesm2015/js44d.js");













// feature modules



const BrowseRoutes = [
    {
        path: '',
        component: _browseTableDialog_component__WEBPACK_IMPORTED_MODULE_6__["BrowseTableDialog"]
    }
];
let BrowseTableModule = class BrowseTableModule {
};
BrowseTableModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _angular_common_http__WEBPACK_IMPORTED_MODULE_5__["HttpClientModule"],
            _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"].forChild(BrowseRoutes),
            js44d__WEBPACK_IMPORTED_MODULE_13__["FourDModule"], js44d__WEBPACK_IMPORTED_MODULE_13__["JS44DModule"], js44d__WEBPACK_IMPORTED_MODULE_13__["ModalModule"]
        ],
        providers: [_angular_common_http__WEBPACK_IMPORTED_MODULE_5__["HttpClient"], js44d__WEBPACK_IMPORTED_MODULE_13__["FourDInterface"]],
        declarations: [_browseTableDialog_component__WEBPACK_IMPORTED_MODULE_6__["BrowseTableDialog"], _browseTable_component__WEBPACK_IMPORTED_MODULE_7__["BrowseTableComponent"], _browseQuery_component__WEBPACK_IMPORTED_MODULE_8__["BrowseQueryBand"], _browseQueryField_component__WEBPACK_IMPORTED_MODULE_9__["BrowseQueryField"],
            _browseFormDialog_component__WEBPACK_IMPORTED_MODULE_11__["BrowseFormDialog"], _browseInputField_component__WEBPACK_IMPORTED_MODULE_10__["BrowseInputField"], _browseFieldDialog_component__WEBPACK_IMPORTED_MODULE_12__["BrowseFieldDialog"]],
        entryComponents: [_browseFormDialog_component__WEBPACK_IMPORTED_MODULE_11__["BrowseFormDialog"], _browseTable_component__WEBPACK_IMPORTED_MODULE_7__["BrowseTableComponent"], _browseFieldDialog_component__WEBPACK_IMPORTED_MODULE_12__["BrowseFieldDialog"]]
    })
], BrowseTableModule);



/***/ }),

/***/ "./src/app/browseTable/browseTableDialog.component.ts":
/*!************************************************************!*\
  !*** ./src/app/browseTable/browseTableDialog.component.ts ***!
  \************************************************************/
/*! exports provided: BrowseTableDialog */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "BrowseTableDialog", function() { return BrowseTableDialog; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var js44d__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! js44d */ "./node_modules/js44d/fesm2015/js44d.js");
/* harmony import */ var _browseTable_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./browseTable.component */ "./src/app/browseTable/browseTable.component.ts");





let BrowseTableDialog = class BrowseTableDialog {
    constructor(modal, router, elementRef, viewRef) {
        this.modal = modal;
        this.router = router;
        this.elementRef = elementRef;
        this.viewRef = viewRef;
    }
    /**
     * AFter our view gets initialized, subscribe to various events on the Query band and the Grid
     */
    ngAfterContentInit() {
        this.router.navigate(['/blank'], { skipLocationChange: true });
        this.modal.openDialog(_browseTable_component__WEBPACK_IMPORTED_MODULE_4__["BrowseTableComponent"], {});
    }
};
BrowseTableDialog.ctorParameters = () => [
    { type: js44d__WEBPACK_IMPORTED_MODULE_3__["Modal"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"] },
    { type: _angular_core__WEBPACK_IMPORTED_MODULE_1__["ElementRef"] },
    { type: _angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewContainerRef"] }
];
BrowseTableDialog = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'browse-table-dialog',
        template: '<div></div>',
        providers: [js44d__WEBPACK_IMPORTED_MODULE_3__["Modal"]]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [js44d__WEBPACK_IMPORTED_MODULE_3__["Modal"], _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["ElementRef"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewContainerRef"]])
], BrowseTableDialog);



/***/ })

}]);
//# sourceMappingURL=app-browseTable-browseTable-module-es2015.js.map